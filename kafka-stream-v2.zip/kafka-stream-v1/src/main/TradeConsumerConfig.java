package com.example.kafkastreamspoc.config;

import com.example.kafkastreamspoc.dto.OrderInput;
import com.example.kafkastreamspoc.dto.OrderResult;
import com.example.kafkastreamspoc.dto.ProcessedResultWrapper;
import com.example.kafkastreamspoc.dto.ProcessingStatus;
import com.example.kafkastreamspoc.serde.JsonSerde;
import com.example.kafkastreamspoc.service.OrderProcessingService;
import lombok.RequiredArgsConstructor;
import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.config.SaslConfigs;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.kstream.Branched;
import org.apache.kafka.streams.kstream.Consumed;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.Produced;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.KafkaStreamsConfiguration;
import org.springframework.kafka.config.StreamsBuilderFactoryBean;

import java.util.HashMap;
import java.util.Map;

@Configuration
@RequiredArgsConstructor
public class TradeConsumerConfig {

    private final OrderProcessingService orderProcessingService;

    @Value("${confluent.bootstrap-servers}")
    private String bootstrapServers;

    @Value("${confluent.api-key}")
    private String apiKey;

    @Value("${confluent.api-secret}")
    private String apiSecret;

    @Bean(name = "tradeStreamsConfig")
    public KafkaStreamsConfiguration tradeStreamsConfig() {
        Map<String, Object> props = new HashMap<>();
        
        // Confluent Cloud Connection
        props.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        props.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, "SASL_SSL");
        props.put(SaslConfigs.SASL_MECHANISM, "PLAIN");
        props.put(SaslConfigs.SASL_JAAS_CONFIG, String.format(
                "org.apache.kafka.common.security.plain.PlainLoginModule required username='%s' password='%s';", 
                apiKey, apiSecret));

        // Application Specifics
        props.put(StreamsConfig.APPLICATION_ID_CONFIG, "trade-processing-group-v1");
        props.put(StreamsConfig.NUM_STREAM_THREADS_CONFIG, 4); 
        props.put(StreamsConfig.COMMIT_INTERVAL_MS_CONFIG, 2000); // 2-second low commit frequency

        // ⏱️ HIGH-VOLUME SAFETY TUNING (Consumer prefixes are required for Kafka Streams props)
        
        

        // 2. Processing Timeout: Give the app up to 10 minutes to finish the database loop before rebalancing
        props.put(StreamsConfig.consumerPrefix(ConsumerConfig.MAX_POLL_INTERVAL_MS_CONFIG), 600000); 

        // 3. Session Timeout: If the node completely drops offline, trigger rebalance after 45 seconds
        props.put(StreamsConfig.consumerPrefix(ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG), 45000);
        // 1. Drop your batch size significantly


// 2. Drastically increase the Max Poll Interval (Processing Timeout)
// Give the consumer plenty of time to process a slow batch before Confluent thinks it's dead.
// 15 minutes (900,000 ms) provides a massive safety buffer for 3-second records.





// Batch Size
props.put(StreamsConfig.consumerPrefix(ConsumerConfig.MAX_POLL_RECORDS_CONFIG), 5);

// Commit Frequency (Aligned with maximum batch processing time)
props.put(StreamsConfig.COMMIT_INTERVAL_MS_CONFIG, 15000); 

// Rebalance Timeout (Gives 3x safety window to finish the 15-second batch)
props.put(StreamsConfig.consumerPrefix(ConsumerConfig.REBALANCE_TIMEOUT_MS_CONFIG), 45000);

// Hard Processing Timeout (Safety net for DB performance degradation)
props.put(StreamsConfig.consumerPrefix(ConsumerConfig.MAX_POLL_INTERVAL_MS_CONFIG), 300000);

        return new KafkaStreamsConfiguration(props);
    }

    @Bean(name = "tradeStreamsBuilderFactoryBean")
    public StreamsBuilderFactoryBean tradeStreamsBuilderFactoryBean() {
        return new StreamsBuilderFactoryBean(tradeStreamsConfig());
    }

    @Bean(name = "tradeKStream")
    public KStream<String, OrderInput> tradeKStream(
            @org.springframework.beans.factory.annotation.Qualifier("tradeStreamsBuilderFactoryBean")
            StreamsBuilderFactoryBean factoryBean) throws Exception {
        
        StreamsBuilder streamsBuilder = factoryBean.getObject();
        
        JsonSerde<OrderInput> orderInputSerde = new JsonSerde<>(OrderInput.class);
        JsonSerde<OrderResult> orderResultSerde = new JsonSerde<>(OrderResult.class);
        JsonSerde<ProcessingStatus> statusSerde = new JsonSerde<>(ProcessingStatus.class);

        KStream<String, OrderInput> sourceStream = streamsBuilder.stream(
                "input-orders", 
                Consumed.with(Serdes.String(), orderInputSerde)
        );

        KStream<String, ProcessedResultWrapper> processedStream = sourceStream.mapValues(
                (key, value) -> orderProcessingService.processAndSave(value)
        );

        Map<String, KStream<String, ProcessedResultWrapper>> branches = processedStream.split()
                .branch((key, wrapper) -> wrapper.isSuccess(), Branched.as("success"))
                .branch((key, wrapper) -> !wrapper.isSuccess(), Branched.as("failure"))
                .noDefaultBranch();

        branches.get("kstream-split-success").mapValues(ProcessedResultWrapper::getOrderResult)
                .to("order-results", Produced.with(Serdes.String(), orderResultSerde));
        
        branches.get("kstream-split-success").mapValues(ProcessedResultWrapper::getProcessingStatus)
                .to("processing-status", Produced.with(Serdes.String(), statusSerde));

        branches.get("kstream-split-failure").mapValues(ProcessedResultWrapper::getProcessingStatus)
                .to("processing-status", Produced.with(Serdes.String(), statusSerde));

        return sourceStream;
    }
}