package com.example.kafkastreamspoc.config;

import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.common.config.SaslConfigs;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.kstream.Consumed;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.Produced;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.KafkaStreamsConfiguration;
import org.springframework.kafka.config.StreamsBuilderFactoryBean;

import java.util.HashMap;
import java.util.Map;

@Configuration
public class AnalyticsConsumerConfig {

    @Value("${confluent.bootstrap-servers}")
    private String bootstrapServers;

    @Value("${confluent.api-key}")
    private String apiKey;

    @Value("${confluent.api-secret}")
    private String apiSecret;

    // 1. Independent Configuration Properties for the SECOND Stream
    @Bean(name = "analyticsStreamsConfig")
    public KafkaStreamsConfiguration analyticsStreamsConfig() {
        Map<String, Object> props = new HashMap<>();
        
        props.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        props.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, "SASL_SSL");
        props.put(SaslConfigs.SASL_MECHANISM, "PLAIN");
        props.put(SaslConfigs.SASL_JAAS_CONFIG, String.format(
                "org.apache.kafka.common.security.plain.PlainLoginModule required username='%s' password='%s';", 
                apiKey, apiSecret));

        // Notice: Entirely separate Application Group ID
        props.put(StreamsConfig.APPLICATION_ID_CONFIG, "analytics-metrics-group-v1");
        props.put(StreamsConfig.NUM_STREAM_THREADS_CONFIG, 2);
        
        // This analytics stream doesn't touch DB, so standard 30-sec commits are fine
        props.put(StreamsConfig.COMMIT_INTERVAL_MS_CONFIG, 30000); 

        return new KafkaStreamsConfiguration(props);
    }

    // 2. Independent FactoryBean for the SECOND Stream
    @Bean(name = "analyticsStreamsBuilderFactoryBean")
    public StreamsBuilderFactoryBean analyticsStreamsBuilderFactoryBean() {
        return new StreamsBuilderFactoryBean(analyticsStreamsConfig());
    }

    // 3. Isolated Topology Definition using the explicit analytics Factory Bean Qualifier
    @Bean(name = "analyticsKStream")
    public KStream<String, String> analyticsKStream(
            @org.springframework.beans.factory.annotation.Qualifier("analyticsStreamsBuilderFactoryBean") 
            StreamsBuilderFactoryBean factoryBean) throws Exception {
        
        StreamsBuilder streamsBuilder = factoryBean.getObject();

        // Simple stateless transformation reading string metrics data
        KStream<String, String> metricStream = streamsBuilder.stream(
                "system-metrics", 
                Consumed.with(Serdes.String(), Serdes.String())
        );

        metricStream.mapValues(value -> value.toUpperCase())
                .to("transformed-metrics", Produced.with(Serdes.String(), Serdes.String()));

        return metricStream;
    }
}