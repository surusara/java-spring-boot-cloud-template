package com.example.kafkastreamspoc.domain;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

@Entity
@Table(name = "processed_orders")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProcessedOrderEntity {
    @Id
    private String orderId;
    private String customerId;
    private Double amount;
    private String status;
    private LocalDateTime processedAt;
}