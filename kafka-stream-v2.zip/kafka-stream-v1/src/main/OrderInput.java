package com.example.kafkastreamspoc.dto;

import lombok.Data;

@Data
public class OrderInput {
    private String orderId;
    private String customerId;
    private Double amount;
}