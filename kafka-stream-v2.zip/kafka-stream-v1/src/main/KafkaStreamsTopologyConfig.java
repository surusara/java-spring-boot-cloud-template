package com.example.kafkastreamspoc.config;

import com.example.kafkastreamspoc.dto.OrderInput;
import com.example.kafkastreamspoc.dto.OrderResult;
import com.example.kafkastreamspoc.dto.ProcessedResultWrapper;
import com.example.kafkastreamspoc.dto.ProcessingStatus;
import com.example.kafkastreamspoc.serde.JsonSerde;
import com.example.kafkastreamspoc.service.OrderProcessingService;
import lombok.RequiredArgsConstructor;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.kstream.Branched;
import org.apache.kafka.streams.kstream.Consumed;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.Produced;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafkaStreams;

import java.util.Map;

@Configuration
@EnableKafkaStreams
@RequiredArgsConstructor
public class KafkaStreamsTopologyConfig {

    private final OrderProcessingService orderProcessingService;

    @Bean
    public KStream<String, OrderInput> kStream(StreamsBuilder streamsBuilder) {
        // Serdes
        JsonSerde<OrderInput> orderInputSerde = new JsonSerde<>(OrderInput.class);
        JsonSerde<OrderResult> orderResultSerde = new JsonSerde<>(OrderResult.class);
        JsonSerde<ProcessingStatus> statusSerde = new JsonSerde<>(ProcessingStatus.class);
        JsonSerde<ProcessedResultWrapper> wrapperSerde = new JsonSerde<>(ProcessedResultWrapper.class);

        // 1. Consume from input topic
        KStream<String, OrderInput> sourceStream = streamsBuilder.stream(
                "input-orders", 
                Consumed.with(Serdes.String(), orderInputSerde)
        );

        // 2. Map values (Stateless Transformation + Database Side Effect)
        KStream<String, ProcessedResultWrapper> processedStream = sourceStream.mapValues(
                (key, value) -> orderProcessingService.processAndSave(value)
        );

        // 3. Dynamic Routing using Branching
        Map<String, KStream<String, ProcessedResultWrapper>> branches = processedStream.split()
                .branch((key, wrapper) -> wrapper.isSuccess(), Branched.as("success"))
                .branch((key, wrapper) -> !wrapper.isSuccess(), Branched.as("failure"))
                .noDefaultBranch();

        // --- SUCCESS BRANCH ACTIONS ---
        KStream<String, ProcessedResultWrapper> successStream = branches.get("kstream-split-success");
        
        // Publish to topic 1: order-results
        successStream.mapValues(ProcessedResultWrapper::getOrderResult)
                .to("order-results", Produced.with(Serdes.String(), orderResultSerde));
        
        // Publish to topic 2: processing-status
        successStream.mapValues(ProcessedResultWrapper::getProcessingStatus)
                .to("processing-status", Produced.with(Serdes.String(), statusSerde));

        // --- FAILURE BRANCH ACTIONS ---
        KStream<String, ProcessedResultWrapper> failureStream = branches.get("kstream-split-failure");
        
        // Publish only to topic 2: processing-status
        failureStream.mapValues(ProcessedResultWrapper::getProcessingStatus)
                .to("processing-status", Produced.with(Serdes.String(), statusSerde));

        return sourceStream;
    }
}