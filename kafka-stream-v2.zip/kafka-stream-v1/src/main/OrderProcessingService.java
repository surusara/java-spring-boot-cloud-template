package com.example.kafkastreamspoc.service;

import com.example.kafkastreamspoc.domain.ProcessedOrderEntity;
import com.example.kafkastreamspoc.dto.OrderInput;
import com.example.kafkastreamspoc.dto.OrderResult;
import com.example.kafkastreamspoc.dto.ProcessedResultWrapper;
import com.example.kafkastreamspoc.dto.ProcessingStatus;
import com.example.kafkastreamspoc.repository.OrderRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
//This component interacts with your local infrastructure (e.g., PostgreSQL). Note that Kafka Streams processing tasks run on internal Kafka client threads. Side-effects (like writing to an external database) should block minimally.
@Service
@RequiredArgsConstructor
@Slf4j
public class OrderProcessingService {

    private final OrderRepository orderRepository;

    @Transactional
    public ProcessedResultWrapper processAndSave(OrderInput input) {
        try {
            // Business Logic Simulation: Fail if amount is negative
            if (input.getAmount() < 0) {
                throw new IllegalArgumentException("Order amount cannot be negative.");
            }

            // Calculate final amount (e.g., 10% tax addition)
            double finalAmount = input.getAmount() * 1.10;
            OrderResult result = new OrderResult(input.getOrderId(), input.getCustomerId(), finalAmount);
            ProcessingStatus status = new ProcessingStatus(input.getOrderId(), "SUCCESS", null);

            // Database Persistence
            ProcessedOrderEntity entity = new ProcessedOrderEntity(
                    input.getOrderId(), input.getCustomerId(), finalAmount, "COMPLETED", LocalDateTime.now()
            );
            orderRepository.save(entity);

            return new ProcessedResultWrapper(input, result, status, true);

        } catch (Exception e) {
            log.error("Failed to process order ID: {}", input.getOrderId(), e);
            ProcessingStatus status = new ProcessingStatus(input.getOrderId(), "FAILED", e.getMessage());
            return new ProcessedResultWrapper(input, null, status, false);
        }
    }
}