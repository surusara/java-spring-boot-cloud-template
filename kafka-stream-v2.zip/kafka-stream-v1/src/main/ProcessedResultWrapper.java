package com.example.kafkastreamspoc.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ProcessedResultWrapper {
    private OrderInput originalInput;
    private OrderResult orderResult;
    private ProcessingStatus processingStatus;
    private boolean isSuccess;
}