# 🚀 Kafka Streams Production Tuning & Concept Guide
> **Focus Case:** Handling High Database Latency (3s+ Processing) with Strict Partition Sequencing.

This guide clarifies core Kafka Streams behaviors, lifecycle execution models, rebalance risks, and optimal tuning configurations derived from troubleshooting a cluster experiencing duplication spikes during horizontal scaling.

---

## 🏗️ 1. Core Architectural Reality Check

When a business rule demands strict sequence validation (e.g., verifying if a `NEW` trade exists in the database before processing an `AMENDED` trade), **processing within a single partition must remain synchronous.** ### 🛑 The Throughput Bottleneck Formula
If your database validation/execution loop takes an average of **3 seconds per trade**, your throughput is mathematically hard-capped based on your partition layout, regardless of hardware resources:

$$\text{Throughput per Partition} = \frac{60\text{ seconds}}{3\text{ seconds}} = 20\text{ trades/minute}$$

* For a cluster capped at **48 partitions**, the absolute cluster-wide limit is:
  $$48 \times 20 = 960\text{ trades/minute}$$

If incoming message traffic permanently exceeds this value, your application will face compounding **consumer lag**. To scale past this without adding partitions, database optimizations (such as shifting logic to an in-memory Kafka State Store or an optimized DB Upsert (`ON CONFLICT`)) are mandatory.

---

## ⏱️ 2. The Mechanics of Commits (`COMMIT_INTERVAL_MS_CONFIG`)

In Kafka Streams, offset commits are **time-driven but execution-blocked**, meaning Kafka cannot commit in the middle of a polling batch.

### 🔍 Scenario Analysis (Batch Size: 100 | Commit Interval: 1000ms)

#### Scenario A: Interrupted Mid-Batch
* **Action:** 100 records are polled. A new pod forces a rebalance exactly after **50 records** have been processed and written to PostgreSQL.
* **Outcome:** **All 100 records will be re-delivered.** * **Why?** Even though the 50 records took much longer than your 1,000ms commit interval, Kafka Streams *only* evaluates the commit timer **between batches** (after the processing loop finishes iterating through the active `poll()` array). Because it was interrupted mid-batch, no commit occurred. The 50 processed trades will result in **duplicates** unless your database layer is strictly idempotent.

#### Scenario B: Interrupted in the Next Batch Cycle
* **Action:** Batch 1 (Records 1–100) finishes processing completely. Batch 2 (Records 101–200) is polled, and a rebalance strikes mid-way through.
* **Outcome:** **Records 1–100 are safely committed and will never be re-delivered.** Records 101–200 will be completely re-delivered.
* **Why?** Once Batch 1 concluded, Kafka Streams noticed the 1,000ms timer had expired and executed a synchronous offset commit up to record 100 before calling the next `.poll()`.

---

## 👥 3. Rebalance Tuning & Safety Parameters

When scaling your cluster up or down (e.g., adding or removing Kubernetes pods), a **Rebalance** is triggered. To prevent massive duplicate spikes caused by threads failing to save their state before the rebalance window closes, configurations must adapt to your 3-second database latency.

### ⚙️ Critical Configuration Parameters

| Property Key | Definition | Impact on Duplicates |
| :--- | :--- | :--- |
| `MAX_POLL_RECORDS_CONFIG` | The maximum size of a single batch pulled into memory per poll. | **High.** Keeping this small (e.g., `5`) shrinks your "indivisible block of work" from minutes to seconds, minimizing uncommitted data if a rebalance strikes. |
| `REBALANCE_TIMEOUT_MS_CONFIG` | The maximum time the Kafka coordinator will wait for an active pod to finish its current batch and commit before stripping its partitions. | **Critical.** Must be larger than your maximum batch processing time ($5 \text{ records} \times 3\text{s} = 15\text{s}$). If it's too low, partitions are forcibly revoked, creating massive duplicates on the new pods. |
| `MAX_POLL_INTERVAL_MS_CONFIG` | The hard processing ceiling. If a thread doesn't call `.poll()` within this window, Confluent Cloud assumes it's dead and kicks it out. | **High.** Acts as a vital safety net. Must be large enough to allow processing during temporary database slowdowns without triggering permanent rebalance loops. |

---

## 🎯 4. Production Calibration Matrix

For an environment with **48 partitions, 6 pods, and 4 threads per pod** ($6 \times 4 = 24 \text{ total threads}$, resulting in **2 partitions per thread**), use these mathematically aligned properties within your explicit manual configurations:

```properties
# Step 1: Limit batch size so a single block of work never exceeds 15 seconds
# 5 records * 3 seconds = 15s max workload block
streams.consumer.max.poll.records=5

# Step 2: Align commit interval with your maximum batch processing block
streams.commit.interval.ms=15000

# Step 3: Allow a 3x safety buffer for the thread to cleanly save and commit during rebalances
# (Gives up to 9 seconds per record if PostgreSQL experiences a transient connection spike)
streams.consumer.rebalance.timeout.ms=45000

# Step 4: Keep a high processing threshold to handle deep database connection queuing
streams.consumer.max.poll.interval.ms=300000



🧠 Prefix Note for Manual Java Configurations
When creating custom KafkaStreamsConfiguration beans manually in Spring Boot, remember to wrap consumer properties using the helper utility to apply parameters across both your Main and Global consumers seamlessly:



props.put(StreamsConfig.consumerPrefix(ConsumerConfig.MAX_POLL_RECORDS_CONFIG), 5);
props.put(StreamsConfig.consumerPrefix(ConsumerConfig.REBALANCE_TIMEOUT_MS_CONFIG), 45000);