# Trade Journey Tracer

Real-time visualization of a trade's journey across microservices. Enter a **Trade ID**,
the React UI calls the Spring Boot trace API, and the journey is replayed live across a
10-stage pipeline (Trade Received → Validation → Enrichment → Event Published → Trade
Consumer → Settlement Order → Clearing & Netting → Funding → Accounting → Payment).

Each microservice reports a status — `RECEIVED`, `PROCESSING`, `SUCCESS`, `PARTIAL`,
`RECOVERED`, `FAILED`. On failure an exception is raised; an **auto-recovery** may recover
the trade (`RECOVERED`) or exhaust and park the message in a DLQ (`FAILED`). On success a
node may be fully `SUCCESS` (trade processed **and** outbox published) or `PARTIAL` (trade
processed, outbox publish still pending). The **Live Event Stream** carries rich, expandable
details (offsets, retry attempts, stack refs, recovery strategy) for investigation.

```
trade-journey-tracer/
├─ backend/    Spring Boot 3 (Java 17) trace API
└─ frontend/   React 18 + Vite UI
```

## Prerequisites

- Java 17+ and Maven (or use the bundled `mvnw` if added)
- Node.js 18+

## Run the backend (port 8080)

```powershell
cd backend
mvn spring-boot:run
```

Quick check:

```powershell
curl http://localhost:8080/api/health
curl http://localhost:8080/api/traces/trades/TRD-9F3A21/versions
curl http://localhost:8080/api/traces/trades/TRD-9F3A21/versions/1
```

## Run the frontend (port 5173)

```powershell
cd frontend
npm install
npm run dev
```

Open http://localhost:5173, enter a Trade ID (e.g. `TRD-9F3A21`) and press **Trace**.
Vite proxies `/api` → `http://localhost:8080`, so no CORS config is needed in dev.

> Tip: different Trade IDs deterministically produce different stories (success,
> exception-with-recovery, or hard failure). A trade may also have multiple **versions** —
> pick them from the Version dropdown.

## API

| Method | Path | Description |
| ------ | ---- | ----------- |
| GET | `/api/health` | Liveness |
| GET | `/api/traces/trades/{tradeId}/versions` | List versions of a trade |
| GET | `/api/traces/trades/{tradeId}/versions/{version}` | Full trace (nodes, edges, timeline) |
| GET | `/api/traces/trades/{tradeId}/versions/{version}/nodes/{nodeId}` | Single node detail |
| GET | `/api/traces/trades/{tradeId}/versions/{version}/timeline` | Event timeline |

### Data model (key fields)

- `NodeView`: `status`, `receivedAt`, `processedAt`, `latencyMs`, `outbox`, `exception`, `metrics`, `relatedIds`
- `OutboxInfo`: `status` (`SUCCESS` | `PENDING` | `FAILED`), `messageId`, `topic`, `partition`, `offset`
- `ExceptionInfo`: `raised`, `type`, `message`, `stackRef`, `recovered`, `recoveryAttempts`, `recoveredAt`, `recoveryStrategy`
- `TimelineEvent`: `level`, `eventType`, `message`, `details` (arbitrary investigation context)

## Replacing the mock with a real backend

`TraceService` deterministically generates traces today. To go live, replace
`generateTrace(...)` with repository / recon-table reads (and a Kafka → WebSocket bridge for
true push updates) while keeping the `TraceView` / `NodeView` contract. The UI already
replays from a full `TraceView`, so only the data source changes.

## Future extensions

- WebSocket/SSE push for true live updates (replace the client-side replay loop).
- Branching / parallel graphs via React Flow.
- Side-by-side version comparison.
- Persisted historical replay.
