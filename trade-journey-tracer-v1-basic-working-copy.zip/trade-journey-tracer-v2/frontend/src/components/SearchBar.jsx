import React from 'react';

export default function SearchBar({
  tradeId, setTradeId,
  versions, version, setVersion,
  scale, setScale,
  onTrace, loading, running
}) {
  return (
    <div className="controls">
      <div className="field grow">
        <label htmlFor="tradeId">Trade ID</label>
        <input
          id="tradeId"
          className="input grow"
          value={tradeId}
          placeholder="e.g. TRD-9F3A21"
          onChange={(e) => setTradeId(e.target.value)}
          onKeyDown={(e) => { if (e.key === 'Enter') onTrace(); }}
        />
      </div>

      <div className="field">
        <label htmlFor="version">Version</label>
        <select
          id="version"
          className="select"
          value={version}
          disabled={!versions.length}
          onChange={(e) => setVersion(Number(e.target.value))}
        >
          {versions.length === 0 && <option value={1}>v1</option>}
          {versions.map((v) => (
            <option key={v.version} value={v.version}>
              v{v.version} &middot; {v.overallStatus}
            </option>
          ))}
        </select>
      </div>

      <div className="field">
        <label htmlFor="speed">Speed</label>
        <select id="speed" className="select" value={scale} onChange={(e) => setScale(Number(e.target.value))}>
          <option value={1.6}>Slow</option>
          <option value={1.0}>Normal</option>
          <option value={0.55}>Fast</option>
        </select>
      </div>

      <button className="btn btn-trace" onClick={onTrace} disabled={loading || running}>
        {loading ? 'Loading\u2026' : running ? 'Tracing\u2026' : '\u26A1 Trace'}
      </button>
    </div>
  );
}
