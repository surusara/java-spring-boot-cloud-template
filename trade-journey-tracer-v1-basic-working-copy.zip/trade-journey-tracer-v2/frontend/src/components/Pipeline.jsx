import React from 'react';
import { kindIcon, statusClass } from '../constants';

// Layout constants for the DAG grid.
const COL_W = 190;
const ROW_H = 142;
const PAD_X = 80;
const PAD_Y = 76;

const REACHED = (s) => s && s !== 'NOT_STARTED' && s !== 'AWAITING';
const LIVE = (s) => s === 'RECEIVED' || s === 'PROCESSING' || s === 'RECOVERING' || s === 'STALE';
const TERMINAL_OK = (s) => s === 'SUCCESS' || s === 'RECOVERED' || s === 'PARTIAL';

// Renders the branching settlement journey as a left-to-right DAG. The trade flows
// through one active node at a time; the incoming edge of the active node animates.
export default function Pipeline({ nodes, edges = [], activeIndex, onSelect, selectedNodeId, tick }) {
  if (!nodes.length) return null;

  const byId = {};
  nodes.forEach((n, i) => { byId[n.nodeId] = { ...n, _i: i }; });

  const maxCol = Math.max(...nodes.map((n) => n.col));
  const maxRow = Math.max(...nodes.map((n) => n.row));
  const width = PAD_X * 2 + maxCol * COL_W;
  const height = PAD_Y * 2 + maxRow * ROW_H;
  const cx = (n) => PAD_X + n.col * COL_W;
  const cy = (n) => PAD_Y + n.row * ROW_H;

  const active = activeIndex >= 0 ? nodes[activeIndex] : null;

  return (
    <div className="dag-wrap">
      <div className="dag" style={{ width, height }}>
        <svg className="dag-edges" width={width} height={height}>
          {edges.map((e) => {
            const a = byId[e.from];
            const b = byId[e.to];
            if (!a || !b) return null;
            const ax = cx(a), ay = cy(a), bx = cx(b), by = cy(b);
            const mx = (ax + bx) / 2;
            const d = `M ${ax} ${ay} C ${mx} ${ay}, ${mx} ${by}, ${bx} ${by}`;
            let cls = '';
            if (b.status === 'FAILED') cls = 'failed';
            else if (b._i === activeIndex && LIVE(b.status)) cls = 'flowing';
            else if (REACHED(b.status)) cls = 'done';
            return <path key={`${e.from}->${e.to}`} className={`edge ${cls}`} d={d} />;
          })}
        </svg>

        {nodes.map((n, i) => (
          <div
            key={n.nodeId}
            className="dag-node"
            style={{ left: cx(n), top: cy(n) }}
          >
            <div
              className={`node ${statusClass(n.status)} ${selectedNodeId === n.nodeId ? 'selected' : ''}`}
              onClick={() => onSelect(n.nodeId)}
              title="Click for details"
            >
              <div className="orb-wrap">
                <div className="ring" />
                <div className="orb">
                  <span className="icon">{n.status === 'FAILED' ? '\u26A0\uFE0F' : kindIcon(n.kind)}</span>
                  <span className="num">{i + 1}</span>
                </div>
              </div>
              <div className="label">{n.name}</div>
              <div className="svc">{n.service}</div>
              <div className="latency">{n.terminal && n.latencyMs ? `${n.latencyMs} ms` : ''}</div>
              <LiveBadge node={n} />
            </div>
          </div>
        ))}

        {active && (
          <div
            className={`dag-tracer ${active.status === 'FAILED' ? 'fail' : active.status === 'RECOVERING' ? 'recover' : ''}`}
            style={{ left: cx(active), top: cy(active) }}
          />
        )}
      </div>
    </div>
  );
}

// Live indicator under a node: recovery attempts, polling timer, or stale flag.
function LiveBadge({ node }) {
  const s = node.status;
  if (s === 'RECOVERING') {
    return <div className="live-badge recovering">{`\u21BB ${node.attempt}/${node.maxAttempts}`}</div>;
  }
  if (s === 'PROCESSING' || s === 'RECEIVED') {
    const waited = secsSince(node.receivedAt);
    return (
      <div className="live-badge polling">
        <span className="dots"><i /><i /><i /></span>
        {waited != null ? ` ${waited}s` : ''}
      </div>
    );
  }
  if (s === 'STALE') {
    return <div className="live-badge stale">stale</div>;
  }
  return <div className="live-badge" />;
}

function secsSince(iso) {
  if (!iso) return null;
  const t = Date.parse(iso);
  if (Number.isNaN(t)) return null;
  return Math.max(0, (Date.now() - t) / 1000).toFixed(1);
}
