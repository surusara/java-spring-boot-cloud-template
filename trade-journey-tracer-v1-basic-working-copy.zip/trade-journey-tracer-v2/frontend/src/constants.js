// Static presentation metadata for nodes + status helpers shared across components.

export const NODE_ICONS = {
  'trade-received': '\uD83D\uDCE5',
  'trade-validated': '\uD83D\uDD0D',
  'trade-enriched': '\uD83E\uDDE9',
  'trade-event-published': '\uD83D\uDCE1',
  'trade-consumer': '\uD83D\uDD04',
  'settlement-order': '\uD83D\uDCDD',
  'clearing-netting': '\u2696\uFE0F',
  'funding': '\uD83D\uDCB0',
  'accounting': '\uD83D\uDCCA',
  'payment': '\u2705'
};

// Icon per node KIND in the settlement DAG (node ids may carry an SO suffix).
export const KIND_ICONS = {
  'trade': '\uD83D\uDCC4',              // 📄
  'trade-event': '\uD83D\uDCE1',        // 📡
  'confirmation-object': '\uD83D\uDCCB',// 📋
  'confirmation': '\uD83E\uDD1D',       // 🤝
  'settlement-obligation': '\uD83D\uDCDD', // 📝
  'payment-instruction': '\uD83E\uDDFE',// 🧾
  'payment': '\uD83D\uDCB3',            // 💳
  'funding': '\uD83D\uDCB0',            // 💰
  'accounting': '\uD83D\uDCCA'          // 📊
};

export function kindIcon(kind) {
  return KIND_ICONS[kind] || '\u25CF';
}

// Map a backend NodeStatus (or transient PROCESSING) to a CSS state class.
export function statusClass(status) {
  switch (status) {
    case 'PROCESSING':
    case 'RECEIVED':
    case 'AWAITING':
      return 'processing';
    case 'RECOVERING':
      return 'recovering';
    case 'SUCCESS':
      return 'success';
    case 'PARTIAL':
      return 'partial';
    case 'RECOVERED':
      return 'recovered';
    case 'FAILED':
      return 'error';
    case 'STALE':
      return 'stale';
    default:
      return 'pending';
  }
}

// A node the tracer is still polling (non-terminal, reached).
export function isLiveStatus(status) {
  return status === 'RECEIVED' || status === 'PROCESSING' || status === 'RECOVERING' || status === 'STALE';
}

export function levelClass(level) {
  switch (level) {
    case 'SUCCESS':
      return 'ok';
    case 'WARN':
      return 'warn';
    case 'ERROR':
      return 'err';
    default:
      return 'info';
  }
}

export function fmtTime(iso) {
  if (!iso) return '--:--:--';
  const d = new Date(iso);
  return d.toTimeString().slice(0, 8) + '.' + String(d.getMilliseconds()).padStart(3, '0');
}

export function badgeClass(overall) {
  switch (overall) {
    case 'SUCCESS':
      return 'done';
    case 'RECOVERED':
      return 'recovered';
    case 'FAILED':
      return 'fail';
    case 'IN_PROGRESS':
      return 'run';
    default:
      return 'idle';
  }
}
