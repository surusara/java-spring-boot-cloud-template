import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { fetchLiveTrace, fetchVersions } from './api/traceApi';
import { isLiveStatus } from './constants';
import SearchBar from './components/SearchBar';
import Pipeline from './components/Pipeline';
import EventStream from './components/EventStream';
import NodeDetails from './components/NodeDetails';
import TraceSummary from './components/TraceSummary';

const TERMINAL_SUCCESS = ['SUCCESS', 'RECOVERED', 'PARTIAL'];
const BASE_INTERVAL = 700;     // ms between polls
const MAX_INTERVAL = 2500;     // backoff cap when the frontier is stuck
const CLIENT_TIMEOUT = 120000; // safety bound: stop polling after 2 min

export default function App() {
  const [tradeId, setTradeId] = useState('TRD-9F3A21');
  const [versions, setVersions] = useState([]);
  const [version, setVersion] = useState(1);
  const [scale, setScale] = useState(1.0);

  const [liveNodes, setLiveNodes] = useState([]);
  const [edges, setEdges] = useState([]);
  const [events, setEvents] = useState([]);
  const [activeIndex, setActiveIndex] = useState(-1);
  const [selectedNodeId, setSelectedNodeId] = useState(null);

  const [loading, setLoading] = useState(false);
  const [running, setRunning] = useState(false);
  const [error, setError] = useState(null);

  const [overall, setOverall] = useState(null);
  const [statusLabel, setStatusLabel] = useState('Idle');
  const [statusCls, setStatusCls] = useState('idle');
  const [stepsDone, setStepsDone] = useState(0);
  const [elapsed, setElapsed] = useState(0);
  const [failedStage, setFailedStage] = useState(null);
  const [tick, setTick] = useState(0); // drives smooth per-node waiting timers

  const runningRef = useRef(false);
  const pollTimer = useRef(null);
  const interval = useRef(BASE_INTERVAL);
  const prevSig = useRef('');
  const wallStart = useRef(0);

  const clearTimers = () => {
    if (pollTimer.current) clearTimeout(pollTimer.current);
    pollTimer.current = null;
  };

  // Smooth ticker so per-node "waited Ns" timers advance between polls.
  useEffect(() => {
    if (!running) return undefined;
    const id = setInterval(() => setTick((t) => t + 1), 300);
    return () => clearInterval(id);
  }, [running]);

  useEffect(() => () => { runningRef.current = false; clearTimers(); }, []);

  const applySnapshot = useCallback((snap) => {
    const nodes = snap.nodes.map((n) => ({ ...n, liveStatus: n.status }));
    setLiveNodes(nodes);
    setEdges(snap.edges || []);
    setEvents(snap.timeline);
    setElapsed(snap.elapsedMs);
    setOverall(snap.overallStatus);

    // Frontier = last reached node; active = the node still being polled.
    let frontier = -1;
    let active = -1;
    nodes.forEach((n, i) => {
      if (n.status !== 'NOT_STARTED') frontier = i;
      if (isLiveStatus(n.status)) active = i;
    });
    const failedIdx = nodes.findIndex((n) => n.status === 'FAILED');
    if (failedIdx >= 0) {
      setActiveIndex(failedIdx);
      setFailedStage(`Step ${failedIdx + 1} \u00b7 ${nodes[failedIdx].name}`);
    } else {
      setActiveIndex(active >= 0 ? active : (snap.terminal ? -1 : frontier));
      setFailedStage(null);
    }

    setStepsDone(nodes.filter((n) => TERMINAL_SUCCESS.includes(n.status)).length);
  }, []);

  const finish = useCallback((snap) => {
    runningRef.current = false;
    setRunning(false);
    if (snap.overallStatus === 'FAILED') {
      setStatusLabel('Failed');
      setStatusCls('fail');
    } else if (snap.overallStatus === 'RECOVERED') {
      setStatusLabel('Completed (recovered)');
      setStatusCls('recovered');
      setActiveIndex(-1);
    } else {
      setStatusLabel('Completed');
      setStatusCls('done');
      setActiveIndex(-1);
    }
  }, []);

  const stopWithError = useCallback((e) => {
    runningRef.current = false;
    setRunning(false);
    setError(e.message || String(e));
    setStatusLabel('Error');
    setStatusCls('fail');
  }, []);

  const poll = useCallback(async (id, ver, scl) => {
    if (!runningRef.current) return;
    if (performance.now() - wallStart.current > CLIENT_TIMEOUT) {
      runningRef.current = false;
      setRunning(false);
      setStatusLabel('Stale (no terminal response)');
      setStatusCls('fail');
      return;
    }
    try {
      const snap = await fetchLiveTrace(id, ver, { reset: false, scale: scl });
      applySnapshot(snap);
      if (snap.terminal) { finish(snap); return; }

      // Exponential backoff while the frontier is unchanged (keep retrying, gently).
      const sig = snap.nodes.map((n) => `${n.status}:${n.attempt}`).join('|');
      interval.current = sig === prevSig.current
        ? Math.min(interval.current * 1.25, MAX_INTERVAL)
        : BASE_INTERVAL;
      prevSig.current = sig;

      pollTimer.current = setTimeout(() => poll(id, ver, scl), interval.current);
    } catch (e) {
      stopWithError(e);
    }
  }, [applySnapshot, finish, stopWithError]);

  const startLive = useCallback(async (id, ver, scl) => {
    clearTimers();
    runningRef.current = true;
    setRunning(true);
    setError(null);
    setEvents([]);
    setSelectedNodeId(null);
    setActiveIndex(-1);
    setFailedStage(null);
    setStepsDone(0);
    setElapsed(0);
    setOverall(null);
    setStatusLabel('Tracing\u2026');
    setStatusCls('run');
    prevSig.current = '';
    interval.current = BASE_INTERVAL;
    wallStart.current = performance.now();
    try {
      const snap = await fetchLiveTrace(id, ver, { reset: true, scale: scl });
      applySnapshot(snap);
      if (snap.terminal) { finish(snap); return; }
      pollTimer.current = setTimeout(() => poll(id, ver, scl), interval.current);
    } catch (e) {
      stopWithError(e);
    }
  }, [applySnapshot, finish, poll, stopWithError]);

  const onTrace = useCallback(async () => {
    const id = (tradeId || '').trim();
    if (!id) { setError('Enter a Trade ID'); return; }
    clearTimers();
    runningRef.current = false;
    setLoading(true);
    setError(null);
    try {
      const v = await fetchVersions(id);
      setVersions(v.versions || []);
      const latest = v.versions && v.versions.length ? v.versions[v.versions.length - 1].version : 1;
      setVersion(latest);
      await startLive(id, latest, scale);
    } catch (e) {
      stopWithError(e);
    } finally {
      setLoading(false);
    }
  }, [tradeId, scale, startLive, stopWithError]);

  const onVersionChange = useCallback((v) => {
    setVersion(v);
    if (tradeId.trim()) startLive(tradeId.trim(), v, scale);
  }, [tradeId, scale, startLive]);

  const selectedNode = useMemo(
    () => (selectedNodeId ? liveNodes.find((n) => n.nodeId === selectedNodeId) || null : null),
    [selectedNodeId, liveNodes]
  );

  const total = liveNodes.length || 0;

  return (
    <div className="wrap">
      <div className="header">
        <div>
          <div className="title"><span className="dot" /> Live Trade Journey Tracer</div>
          <div className="subtitle">Enter a Trade ID &mdash; the tracer polls each microservice until it reaches a terminal state</div>
        </div>
        <div className="legend">
          <span><i style={{ background: '#64748b' }} /> Pending</span>
          <span><i style={{ background: '#22d3ee' }} /> Processing</span>
          <span><i style={{ background: '#a78bfa' }} /> Recovering</span>
          <span><i style={{ background: '#2dd4bf' }} /> Success</span>
          <span><i style={{ background: '#fbbf24' }} /> Partial</span>
          <span><i style={{ background: '#f87171' }} /> Failed</span>
        </div>
      </div>

      <SearchBar
        tradeId={tradeId}
        setTradeId={setTradeId}
        versions={versions}
        version={version}
        setVersion={onVersionChange}
        scale={scale}
        setScale={setScale}
        onTrace={onTrace}
        loading={loading}
        running={running}
      />

      {error && <div className="error-bar">{error}</div>}

      {liveNodes.length > 0 ? (
        <Pipeline
          nodes={liveNodes}
          edges={edges}
          activeIndex={activeIndex}
          onSelect={setSelectedNodeId}
          selectedNodeId={selectedNodeId}
          tick={tick}
        />
      ) : (
        <div className="stage stage-empty">
          <div className="empty">Enter a Trade ID and press <b>Trace</b> to visualize the journey.</div>
        </div>
      )}

      <div className="grid">
        <EventStream events={events} />
        <div className="right-col">
          <TraceSummary
            tradeId={tradeId}
            version={version}
            overall={overall}
            statusLabel={statusLabel}
            statusCls={statusCls}
            stepsDone={stepsDone}
            total={total}
            elapsed={elapsed}
            failedStage={failedStage}
          />
          <NodeDetails node={selectedNode} />
        </div>
      </div>
    </div>
  );
}
