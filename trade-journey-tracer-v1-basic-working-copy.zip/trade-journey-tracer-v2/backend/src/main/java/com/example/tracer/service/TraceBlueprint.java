package com.example.tracer.service;

import com.example.tracer.model.EdgeView;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Deterministic blueprint of a trade's settlement journey as a branching DAG.
 *
 * <p>The real flow is not a straight line — it fans out:
 * <pre>
 *   Trade -&gt; Trade Event -&gt; Confirmation Object -&gt; Confirmation
 *                         \-&gt; Settlement Obligation -&gt; Payment Instruction -&gt; Payment
 *                                                   \-&gt; Funding
 *                                                   \-&gt; Accounting
 * </pre>
 * A single trade may raise <em>several</em> settlement obligations; each obligation
 * (identified by its own {@code soId} + version) gets its own Payment / Funding /
 * Accounting sub-branch.
 *
 * <p>This class is the single source of truth for the graph shape and the seeded
 * outcome (which node fails and whether it auto-recovers). Both {@link TraceService}
 * (version labels) and {@link LiveTraceService} (live timing) build on it, so the
 * version dropdown always agrees with what the live tracer plays out.
 *
 * <p>Nodes are returned in <strong>traversal order</strong> (topological DFS) so the
 * live tracer can light them up strictly one at a time, and each carries a
 * {@code col}/{@code row} grid position for the DAG layout.
 */
public final class TraceBlueprint {

    /** A node template: identity, lineage and grid position (no timing). */
    public record Node(
            String nodeId,
            String kind,
            String name,
            String service,
            String parentId,
            String soId,
            int soVersion,
            int col,
            double row
    ) {}

    public final String tradeId;
    public final int version;
    public final int soCount;
    public final List<Node> nodes;   // traversal (topological) order
    public final List<EdgeView> edges;
    public final int failAt;         // index into nodes, or -1 for happy path
    public final boolean recovered;  // only meaningful when failAt >= 0
    public final long seed;

    private TraceBlueprint(String tradeId, int version, int soCount, List<Node> nodes,
                           List<EdgeView> edges, int failAt, boolean recovered, long seed) {
        this.tradeId = tradeId;
        this.version = version;
        this.soCount = soCount;
        this.nodes = nodes;
        this.edges = edges;
        this.failAt = failAt;
        this.recovered = recovered;
        this.seed = seed;
    }

    public String overallStatus() {
        if (failAt < 0) return "SUCCESS";
        return recovered ? "RECOVERED" : "FAILED";
    }

    public static TraceBlueprint of(String tradeId, int version) {
        long seed = (tradeId.toUpperCase() + "#" + version).hashCode();
        Random rnd = new Random(seed);

        // 1..2 settlement obligations per trade version.
        int soCount = 1 + rnd.nextInt(2);

        List<Node> nodes = new ArrayList<>();
        List<EdgeView> edges = new ArrayList<>();

        double totalRows = 1 + 3.0 * soCount;
        double trunkRow = (totalRows - 1) / 2.0;

        // --- Trunk -------------------------------------------------------
        nodes.add(new Node("trade", "trade", "Trade", "trade-gateway",
                null, null, 0, 0, trunkRow));
        nodes.add(new Node("trade-event", "trade-event", "Trade Event", "trade-producer",
                "trade", null, 0, 1, trunkRow));
        edges.add(new EdgeView("trade", "trade-event"));

        // --- Confirmation branch (row 0) ---------------------------------
        nodes.add(new Node("confirmation-object", "confirmation-object", "Confirmation Object",
                "confirmation-svc", "trade-event", null, 0, 2, 0));
        edges.add(new EdgeView("trade-event", "confirmation-object"));
        nodes.add(new Node("confirmation", "confirmation", "Confirmation",
                "confirmation-svc", "confirmation-object", null, 0, 3, 0));
        edges.add(new EdgeView("confirmation-object", "confirmation"));

        // --- One sub-tree per settlement obligation ----------------------
        for (int k = 1; k <= soCount; k++) {
            String soId = "SO-" + (10000 + rnd.nextInt(89999));
            int soVer = 1 + rnd.nextInt(2);
            double base = 1 + 3.0 * (k - 1); // first row of this obligation's band

            String so = "so-" + k;
            String pi = "pi-" + k;
            String pay = "pay-" + k;
            String fund = "funding-" + k;
            String acct = "accounting-" + k;
            String soName = soCount > 1 ? "Settlement Obligation #" + k : "Settlement Obligation";

            nodes.add(new Node(so, "settlement-obligation", soName, "settlement-svc",
                    "trade-event", soId, soVer, 2, base + 1));
            edges.add(new EdgeView("trade-event", so));

            nodes.add(new Node(pi, "payment-instruction", "Payment Instruction", "payment-instruction-svc",
                    so, soId, soVer, 3, base));
            edges.add(new EdgeView(so, pi));
            nodes.add(new Node(pay, "payment", "Payment", "payment-svc",
                    pi, soId, soVer, 4, base));
            edges.add(new EdgeView(pi, pay));

            nodes.add(new Node(fund, "funding", "Funding", "funding-svc",
                    so, soId, soVer, 3, base + 1));
            edges.add(new EdgeView(so, fund));

            nodes.add(new Node(acct, "accounting", "Accounting", "ledger-svc",
                    so, soId, soVer, 3, base + 2));
            edges.add(new EdgeView(so, acct));
        }

        int failAt = rnd.nextInt(100) < 45 ? rnd.nextInt(nodes.size()) : -1;
        boolean recovered = failAt >= 0 && rnd.nextInt(100) < 60;

        return new TraceBlueprint(tradeId, version, soCount, nodes, edges, failAt, recovered, seed);
    }
}
