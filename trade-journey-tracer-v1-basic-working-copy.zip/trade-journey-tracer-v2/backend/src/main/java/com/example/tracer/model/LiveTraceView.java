package com.example.tracer.model;

import java.util.List;

/**
 * A point-in-time snapshot of a live trace. The tracer keeps polling the
 * {@code /live} endpoint while {@code terminal == false}; once true, every
 * node has reached a terminal state (SUCCESS / RECOVERED / PARTIAL / FAILED).
 */
public record LiveTraceView(
        String tradeId,
        int version,
        String overallStatus,
        boolean terminal,
        long elapsedMs,
        List<LiveNodeView> nodes,
        List<EdgeView> edges,
        List<TimelineEvent> timeline
) {
}
