package com.example.tracer.service;

import com.example.tracer.model.*;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Live tracer over the branching settlement DAG (see {@link TraceBlueprint}).
 *
 * <p>A trace session is started for a (tradeId, version) pair and then evolves over
 * wall-clock time. Nodes are walked in <strong>traversal order, strictly one at a
 * time</strong>: each node only starts once the previous node in the walk reaches a
 * terminal state, so the UI shows the trade flowing from one system to the next
 * rather than everything lighting up at once.
 *
 * <p>Each node moves AWAITING &rarr; RECEIVED &rarr; PROCESSING &rarr; (SUCCESS |
 * PARTIAL | RECOVERING &rarr; RECOVERED | FAILED). The tracer keeps polling while any
 * reached node is non-terminal, so a slow node stays PROCESSING and an exception node
 * stays RECOVERING until it auto-recovers. A hard (non-recovered) failure halts the
 * remaining journey.
 *
 * <p>The outcome is seeded via {@link TraceBlueprint}, so it always matches the
 * version list; only the timing here is real-time.
 */
@Service
public class LiveTraceService {

    /** Exception type + message per node kind. */
    private static final Map<String, String[]> EXCEPTIONS = Map.ofEntries(
            Map.entry("trade", new String[]{"ValidationException", "Schema validation failed: missing settlementDate"}),
            Map.entry("trade-event", new String[]{"KafkaPublishException", "Kafka broker unavailable - trade event publish rejected"}),
            Map.entry("confirmation-object", new String[]{"ConfirmationException", "Confirmation object build failed - missing counterparty SSI"}),
            Map.entry("confirmation", new String[]{"ConfirmationException", "Counterparty confirmation timed out"}),
            Map.entry("settlement-obligation", new String[]{"SettlementException", "Settlement obligation rejected by CCP"}),
            Map.entry("payment-instruction", new String[]{"PaymentInstructionException", "Payment instruction validation failed - invalid BIC"}),
            Map.entry("payment", new String[]{"PaymentException", "Payment gateway returned 503 Service Unavailable"}),
            Map.entry("funding", new String[]{"FundingException", "Insufficient funding balance for obligation"}),
            Map.entry("accounting", new String[]{"LedgerException", "Ledger posting conflict - optimistic lock failure"})
    );

    /** Node kinds that emit an outbox event when they succeed. */
    private static final java.util.Set<String> OUTBOX_KINDS =
            java.util.Set.of("trade-event", "confirmation", "settlement-obligation", "payment");

    private final Map<String, Session> sessions = new ConcurrentHashMap<>();

    public LiveTraceView snapshot(String tradeId, int version, boolean reset, double scale) {
        String key = tradeId.toUpperCase() + "#" + version;
        Session session = sessions.get(key);
        if (reset || session == null) {
            session = new Session(tradeId, version, scale);
            sessions.put(key, session);
        }
        return session.snapshot();
    }

    // ---------------------------------------------------------------------
    // Planned node (a blueprint node enriched with timing)
    // ---------------------------------------------------------------------

    private static final class NodePlan {
        String nodeId, kind, name, service, parentId, soId;
        int col;
        double row;
        long receivedAt, procStart, terminalAt;
        long latencyMs;
        boolean reached = true;        // false for nodes after a hard failure
        boolean willFail;
        boolean willRecover;
        long exceptionAt;
        long[] attemptAts = new long[0];
        long recoveredAt;
        long failedAt;
        long[] heartbeatAts = new long[0];
        OutboxInfo outbox;
        String exType, exMsg, stackRef;
        Map<String, String> relatedIds = Map.of();
    }

    // ---------------------------------------------------------------------
    // Session: precomputed plan + live snapshot
    // ---------------------------------------------------------------------

    private final class Session {
        final String tradeId;
        final int version;
        final Instant start;
        final List<NodePlan> plan = new ArrayList<>();
        final List<EdgeView> edges;
        long planEndMs;
        final int failAt;
        final boolean recovered;

        Session(String tradeId, int version, double scale) {
            this.tradeId = tradeId;
            this.version = version;
            this.start = Instant.now();
            double s = scale <= 0 ? 1.0 : scale;

            TraceBlueprint bp = TraceBlueprint.of(tradeId, version);
            this.failAt = bp.failAt;
            this.recovered = bp.recovered;
            this.edges = bp.edges;

            // Timing RNG kept separate from the outcome draws inside the blueprint.
            Random tr = new Random(bp.seed * 31 + 7);
            String msgId = "msg-" + Integer.toHexString(tr.nextInt(0x7fffffff));
            String payId = "PAY-" + (100000 + tr.nextInt(899999));

            long cursor = (long) (300 * s);
            boolean halted = false;

            List<TraceBlueprint.Node> bnodes = bp.nodes;
            for (int i = 0; i < bnodes.size(); i++) {
                TraceBlueprint.Node bn = bnodes.get(i);
                NodePlan p = new NodePlan();
                p.nodeId = bn.nodeId();
                p.kind = bn.kind();
                p.name = bn.name();
                p.service = bn.service();
                p.parentId = bn.parentId();
                p.soId = bn.soId();
                p.col = bn.col();
                p.row = bn.row();

                Map<String, String> related = new LinkedHashMap<>();
                related.put("tradeId", tradeId);
                related.put("messageId", msgId);
                if (bn.soId() != null) {
                    related.put("settlementId", bn.soId());
                    related.put("settlementVersion", "v" + bn.soVersion());
                }
                if (bn.kind().equals("payment") || bn.kind().equals("payment-instruction")) {
                    related.put("paymentId", payId);
                }
                p.relatedIds = related;

                if (halted) {
                    p.reached = false;
                    plan.add(p);
                    continue;
                }

                p.receivedAt = cursor;
                p.procStart = p.receivedAt + (long) ((80 + tr.nextInt(120)) * s);

                long baseDur = (long) ((900 + tr.nextInt(1300)) * s);
                // ~20% of healthy nodes are "slow" — response delayed, tracer keeps polling.
                boolean slow = (i != failAt) && tr.nextInt(100) < 20;
                if (slow) {
                    baseDur += (long) ((1200 + tr.nextInt(2400)) * s);
                    p.heartbeatAts = heartbeats(p.procStart, p.procStart + baseDur, (long) (1100 * s));
                }
                p.latencyMs = baseDur;

                if (i == failAt) {
                    p.willFail = true;
                    String[] ex = EXCEPTIONS.getOrDefault(bn.kind(),
                            new String[]{"ProcessingException", "Unexpected error in " + bn.name()});
                    p.exType = ex[0];
                    p.exMsg = ex[1];
                    p.stackRef = "stacktrace://" + p.nodeId + "/" + Integer.toHexString(tr.nextInt(0xffffff));
                    p.exceptionAt = p.procStart + (long) (baseDur * 0.5);

                    int attempts = 1 + tr.nextInt(3);
                    long backoff = (long) (900 * s);
                    long[] ats = new long[attempts];
                    long t = p.exceptionAt;
                    for (int a = 0; a < attempts; a++) {
                        t += backoff * (a + 1L);
                        ats[a] = t;
                    }
                    p.attemptAts = ats;
                    long last = ats[attempts - 1];

                    if (recovered) {
                        p.willRecover = true;
                        p.recoveredAt = last + (long) (450 * s);
                        p.terminalAt = p.recoveredAt;
                        cursor = p.terminalAt + (long) ((250 + tr.nextInt(300)) * s);
                    } else {
                        p.failedAt = last + (long) (450 * s);
                        p.terminalAt = p.failedAt;
                        halted = true;
                        cursor = p.terminalAt;
                    }
                } else {
                    p.terminalAt = p.procStart + baseDur;
                    p.outbox = outboxFor(bn.kind(), tr, msgId, i);
                    cursor = p.terminalAt + (long) ((250 + tr.nextInt(300)) * s);
                }

                plan.add(p);
            }
            this.planEndMs = cursor + (long) (400 * s);
        }

        LiveTraceView snapshot() {
            long raw = Instant.now().toEpochMilli() - start.toEpochMilli();
            long elapsed = Math.min(raw, planEndMs);

            List<LiveNodeView> nodes = new ArrayList<>();
            List<TimelineEvent> timeline = new ArrayList<>();
            int[] seq = {0};
            boolean hardFailed = false;
            boolean anyRecovered = false;
            boolean allReachedTerminal = true;

            for (NodePlan p : plan) {
                if (!p.reached) {
                    nodes.add(notStarted(p));
                    continue;
                }

                NodeStatus status;
                boolean terminal = false;
                int attempt = 0;
                int maxAttempts = 0;
                ExceptionInfo exception = null;
                String receivedAtIso = null;
                String processedAtIso = null;
                long latency = 0;

                if (elapsed < p.receivedAt) {
                    status = NodeStatus.AWAITING;
                    allReachedTerminal = false;
                } else {
                    receivedAtIso = iso(p.receivedAt);
                    emit(timeline, seq, p, p.receivedAt, "INFO", "RECEIVED", p.name + " received message",
                            details("messageId", p.relatedIds.get("messageId"), "topic", topicFor(p),
                                    "tradeId", tradeId, "schemaVersion", "v" + version), elapsed);

                    if (elapsed < p.procStart) {
                        status = NodeStatus.RECEIVED;
                        allReachedTerminal = false;
                    } else {
                        emit(timeline, seq, p, p.procStart, "INFO", "PROCESSING", p.name + " processing started",
                                details("consumerGroup", p.service + "-cg", "tradeId", tradeId), elapsed);

                        int hb = 0;
                        for (long h : p.heartbeatAts) {
                            if (h <= elapsed) {
                                hb++;
                                emit(timeline, seq, p, h, "INFO", "AWAITING_RESPONSE",
                                        "No terminal response yet - tracer re-polling " + p.service,
                                        details("poll", hb, "tradeId", tradeId, "note", "node still processing"), elapsed);
                            }
                        }

                        if (p.willFail) {
                            maxAttempts = p.attemptAts.length;
                            if (elapsed >= p.exceptionAt) {
                                emit(timeline, seq, p, p.exceptionAt, "ERROR", "EXCEPTION",
                                        "Exception raised: " + p.exMsg,
                                        details("exceptionType", p.exType, "message", p.exMsg,
                                                "stackRef", p.stackRef, "attempt", 0, "tradeId", tradeId), elapsed);
                            }
                            for (int a = 0; a < p.attemptAts.length; a++) {
                                if (p.attemptAts[a] <= elapsed) {
                                    attempt = a + 1;
                                    emit(timeline, seq, p, p.attemptAts[a], "WARN", "RECOVERY_ATTEMPT",
                                            "Auto-recovery attempt " + (a + 1) + "/" + maxAttempts + " via RETRY_BACKOFF",
                                            details("attempt", a + 1, "maxAttempts", maxAttempts,
                                                    "strategy", "RETRY_BACKOFF", "tradeId", tradeId), elapsed);
                                }
                            }

                            if (p.willRecover && elapsed >= p.recoveredAt) {
                                status = NodeStatus.RECOVERED;
                                terminal = true;
                                anyRecovered = true;
                                latency = p.terminalAt - p.procStart;
                                processedAtIso = iso(p.recoveredAt);
                                exception = new ExceptionInfo(true, p.exType, p.exMsg, p.stackRef,
                                        true, attempt, iso(p.recoveredAt), "RETRY_BACKOFF");
                                emit(timeline, seq, p, p.recoveredAt, "INFO", "RECOVERED",
                                        "Trade auto-recovered after " + attempt + " attempt(s) - latest status OK",
                                        details("totalAttempts", attempt, "strategy", "RETRY_BACKOFF",
                                                "tradeId", tradeId), elapsed);
                            } else if (!p.willRecover && elapsed >= p.failedAt) {
                                status = NodeStatus.FAILED;
                                terminal = true;
                                hardFailed = true;
                                latency = p.terminalAt - p.procStart;
                                processedAtIso = iso(p.failedAt);
                                exception = new ExceptionInfo(true, p.exType, p.exMsg, p.stackRef,
                                        false, attempt, null, "DLQ_PARKED");
                                emit(timeline, seq, p, p.failedAt, "ERROR", "HALTED",
                                        "Recovery exhausted - message parked in DLQ, manual intervention required",
                                        details("action", "DLQ_PARKED", "attempts", attempt,
                                                "dlqTopic", topicFor(p) + ".DLQ", "exceptionType", p.exType), elapsed);
                            } else if (elapsed >= p.exceptionAt) {
                                status = NodeStatus.RECOVERING;
                                allReachedTerminal = false;
                                exception = new ExceptionInfo(true, p.exType, p.exMsg, p.stackRef,
                                        false, attempt, null, "RETRY_BACKOFF");
                            } else {
                                status = NodeStatus.PROCESSING;
                                allReachedTerminal = false;
                            }
                        } else if (elapsed >= p.terminalAt) {
                            latency = p.latencyMs;
                            processedAtIso = iso(p.terminalAt);
                            emit(timeline, seq, p, p.terminalAt, "SUCCESS", "PROCESSED",
                                    p.name + " processed successfully",
                                    details("durationMs", p.latencyMs, "recordsProcessed", 1, "tradeId", tradeId), elapsed);
                            if (p.outbox != null && p.outbox.status() == OutboxStatus.PENDING) {
                                status = NodeStatus.PARTIAL;
                                terminal = true;
                                emit(timeline, seq, p, p.terminalAt + 5, "WARN", "OUTBOX_PENDING",
                                        "Processed; outbox publish still pending (relay will retry)",
                                        details("outboxId", p.outbox.messageId(), "topic", p.outbox.topic(),
                                                "status", "PENDING", "relay", "outbox-poller"), elapsed);
                            } else {
                                status = NodeStatus.SUCCESS;
                                terminal = true;
                                if (p.outbox != null) {
                                    emit(timeline, seq, p, p.terminalAt + 5, "SUCCESS", "OUTBOX_PUBLISHED",
                                            "Outbox event published: " + p.outbox.messageId(),
                                            details("outboxId", p.outbox.messageId(), "topic", p.outbox.topic(),
                                                    "partition", p.outbox.partition(), "offset", p.outbox.offset(),
                                                    "status", "PUBLISHED"), elapsed);
                                }
                            }
                        } else {
                            status = NodeStatus.PROCESSING;
                            allReachedTerminal = false;
                        }
                    }
                }

                NodeMetrics metrics = new NodeMetrics(attempt, latency, terminal ? 1 : 0);
                nodes.add(new LiveNodeView(p.nodeId, p.kind, p.name, p.service, p.col, p.row,
                        p.parentId, p.soId, status.name(), terminal, attempt, maxAttempts, latency,
                        receivedAtIso, processedAtIso, p.outbox, exception, metrics, p.relatedIds));
            }

            timeline.sort((a, b) -> a.timestamp().compareTo(b.timestamp()));

            boolean terminalOverall;
            String overall;
            if (hardFailed) {
                terminalOverall = true;
                overall = "FAILED";
            } else if (failAt < 0 || recovered) {
                terminalOverall = allReachedTerminal && elapsed >= planEndMs - 1;
                overall = terminalOverall ? (anyRecovered ? "RECOVERED" : "SUCCESS") : "IN_PROGRESS";
            } else {
                terminalOverall = false;
                overall = "IN_PROGRESS";
            }

            return new LiveTraceView(tradeId, version, overall, terminalOverall, elapsed,
                    nodes, edges, timeline);
        }

        private String iso(long offsetMs) {
            return start.plusMillis(offsetMs).toString();
        }

        private LiveNodeView notStarted(NodePlan p) {
            return new LiveNodeView(p.nodeId, p.kind, p.name, p.service, p.col, p.row,
                    p.parentId, p.soId, NodeStatus.NOT_STARTED.name(), false, 0, 0, 0,
                    null, null, null, null, new NodeMetrics(0, 0, 0), p.relatedIds);
        }

        private void emit(List<TimelineEvent> out, int[] seq, NodePlan p, long offset,
                          String level, String type, String msg, Map<String, Object> details, long elapsed) {
            if (offset > elapsed) return;
            out.add(new TimelineEvent("evt-" + version + "-" + p.nodeId + "-" + type + "-" + offset,
                    iso(offset), p.nodeId, p.service, level, type, msg, details));
        }

        private String topicFor(NodePlan p) {
            return p.service + ".events";
        }
    }

    // ---------------------------------------------------------------------
    // Helpers
    // ---------------------------------------------------------------------

    private static long[] heartbeats(long from, long to, long step) {
        if (step <= 0) return new long[0];
        List<Long> hs = new ArrayList<>();
        for (long t = from + step; t < to && hs.size() < 4; t += step) {
            hs.add(t);
        }
        long[] arr = new long[hs.size()];
        for (int i = 0; i < arr.length; i++) arr[i] = hs.get(i);
        return arr;
    }

    private static OutboxInfo outboxFor(String kind, Random rnd, String msgId, int i) {
        if (!OUTBOX_KINDS.contains(kind)) return null;
        boolean pending = rnd.nextInt(100) < 18;
        return new OutboxInfo(
                pending ? OutboxStatus.PENDING : OutboxStatus.SUCCESS,
                "out-" + msgId + "-" + i,
                kind + ".events",
                rnd.nextInt(6),
                (long) rnd.nextInt(100000));
    }

    private static Map<String, Object> details(Object... kv) {
        Map<String, Object> m = new LinkedHashMap<>();
        for (int i = 0; i + 1 < kv.length; i += 2) {
            m.put(String.valueOf(kv[i]), kv[i + 1]);
        }
        return m;
    }
}
