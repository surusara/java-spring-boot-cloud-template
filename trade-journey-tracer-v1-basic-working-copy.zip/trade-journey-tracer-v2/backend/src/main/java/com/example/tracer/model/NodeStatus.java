package com.example.tracer.model;

/**
 * Lifecycle status of a single microservice node within a trade journey.
 */
public enum NodeStatus {
    NOT_STARTED,
    AWAITING,
    RECEIVED,
    PROCESSING,
    RECOVERING,
    SUCCESS,
    FAILED,
    RECOVERED,
    PARTIAL,
    STALE
}
