package com.example.tracer.service;

import com.example.tracer.model.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * Generates deterministic, realistic trade journey traces.
 *
 * <p>This is a stand-in for a real data layer. In production each stage would be
 * backed by a microservice call / recon table lookup. The generation is seeded by
 * (tradeId, version) so the same trade always renders the same story, while
 * different trades/versions exercise success, exception, and auto-recovery paths.
 *
 * <p>To wire a real backend, replace {@link #generateTrace} with repository reads
 * and keep the {@link TraceView} / {@link NodeView} contract unchanged.
 */
@Service
public class TraceService {

    /** nodeId, display name, owning service. Order defines the pipeline. */
    private static final String[][] STAGES = {
            {"trade-received", "Trade Received", "trade-gateway"},
            {"trade-validated", "Validation", "trade-validator"},
            {"trade-enriched", "Enrichment", "ref-data-svc"},
            {"trade-event-published", "Event Published", "trade-producer"},
            {"trade-consumer", "Trade Consumer", "trade-consumer"},
            {"settlement-order", "Settlement Order", "settlement-svc"},
            {"clearing-netting", "Clearing & Netting", "clearing-svc"},
            {"funding", "Funding", "funding-svc"},
            {"accounting", "Accounting", "ledger-svc"},
            {"payment", "Payment", "payment-svc"}
    };

    /** exceptionType, message — indexed by stage. */
    private static final String[][] EXCEPTIONS = {
            {"ValidationException", "Schema validation failed: missing settlementDate"},
            {"ValidationException", "Quantity precision invalid for instrument"},
            {"ReferenceDataException", "Downstream timeout calling reference-data-svc"},
            {"KafkaPublishException", "Kafka broker unavailable - publish rejected"},
            {"DeserializationException", "Poison message - consumer cannot deserialize payload"},
            {"SettlementException", "Settlement order rejected by CCP"},
            {"ClearingException", "Netting mismatch with clearing house"},
            {"FundingException", "Insufficient funding balance for trade"},
            {"LedgerException", "Ledger posting conflict - optimistic lock failure"},
            {"PaymentException", "Payment gateway returned 503 Service Unavailable"}
    };

    // ---------------------------------------------------------------------
    // Public API
    // ---------------------------------------------------------------------

    public VersionsResponse getVersions(String tradeId) {
        int count = 1 + Math.floorMod(tradeId.toUpperCase().hashCode(), 3); // 1..3 versions
        List<VersionSummary> versions = new ArrayList<>();
        for (int v = 1; v <= count; v++) {
            // Outcome comes from the shared DAG blueprint so the label matches the live trace.
            TraceBlueprint bp = TraceBlueprint.of(tradeId, v);
            TraceView t = generateTrace(tradeId, v);
            versions.add(new VersionSummary(v, bp.overallStatus(), t.lastUpdatedAt()));
        }
        return new VersionsResponse(tradeId, versions);
    }

    public TraceView getTrace(String tradeId, int version) {
        if (version < 1) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "version must be >= 1");
        }
        return generateTrace(tradeId, version);
    }

    public NodeView getNode(String tradeId, int version, String nodeId) {
        return generateTrace(tradeId, version).nodes().stream()
                .filter(n -> n.nodeId().equals(nodeId))
                .findFirst()
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "node not found: " + nodeId));
    }

    public List<TimelineEvent> getTimeline(String tradeId, int version) {
        return generateTrace(tradeId, version).timeline();
    }

    // ---------------------------------------------------------------------
    // Generation
    // ---------------------------------------------------------------------

    private TraceView generateTrace(String tradeId, int version) {
        long seed = (tradeId.toUpperCase() + "#" + version).hashCode();
        Random rnd = new Random(seed);

        int failAt = rnd.nextInt(100) < 45 ? rnd.nextInt(STAGES.length) : -1; // 45% chance of failure
        boolean recovered = failAt >= 0 && rnd.nextInt(100) < 60;             // 60% auto-recovery success

        String soId = "SO-" + (10000 + rnd.nextInt(89999));
        String msgId = "msg-" + Integer.toHexString(rnd.nextInt(0x7fffffff));
        String payId = "PAY-" + (100000 + rnd.nextInt(899999));

        Instant base = Instant.now().minusSeconds(180 + rnd.nextInt(120));
        Instant cursor = base;

        List<NodeView> nodes = new ArrayList<>();
        List<EdgeView> edges = new ArrayList<>();
        List<TimelineEvent> timeline = new ArrayList<>();
        int[] seq = {0};
        boolean halted = false;

        for (int i = 0; i < STAGES.length; i++) {
            String nodeId = STAGES[i][0];
            String name = STAGES[i][1];
            String svc = STAGES[i][2];
            if (i > 0) {
                edges.add(new EdgeView(STAGES[i - 1][0], nodeId));
            }

            if (halted) {
                nodes.add(notStarted(nodeId, name, svc));
                continue;
            }

            long latency = 40 + rnd.nextInt(360);
            Instant recv = cursor;
            Instant proc = recv.plusMillis(latency);
            cursor = proc.plusMillis(20 + rnd.nextInt(60));

            Map<String, String> related = new LinkedHashMap<>();
            related.put("tradeId", tradeId);
            related.put("messageId", msgId);
            if (i >= 5) related.put("settlementId", soId);
            if (i >= 9) related.put("paymentId", payId);

            // RECEIVED + PROCESSING events (always emitted for a reached node)
            timeline.add(event(seq, recv, nodeId, svc, "INFO", "RECEIVED",
                    name + " received message",
                    details("messageId", msgId, "topic", topicFor(i), "partition", rnd.nextInt(6),
                            "offset", (long) rnd.nextInt(500000), "schemaVersion", "v" + version)));
            timeline.add(event(seq, recv.plusMillis(2), nodeId, svc, "INFO", "PROCESSING",
                    name + " processing started",
                    details("thread", "StreamThread-" + (1 + rnd.nextInt(4)),
                            "consumerGroup", svc + "-cg", "tradeId", tradeId)));

            OutboxInfo outbox = outboxFor(i, rnd, msgId);
            NodeStatus status;
            ExceptionInfo exception = null;
            int retryCount = 0;

            if (i == failAt) {
                String exType = EXCEPTIONS[i][0];
                String exMsg = EXCEPTIONS[i][1];
                String stackRef = "stacktrace://" + nodeId + "/" + Integer.toHexString(rnd.nextInt(0xffffff));

                timeline.add(event(seq, proc, nodeId, svc, "ERROR", "EXCEPTION",
                        "Exception raised: " + exMsg,
                        details("exceptionType", exType, "message", exMsg, "stackRef", stackRef,
                                "attempt", 0, "tradeId", tradeId)));

                if (recovered) {
                    int attempts = 1 + rnd.nextInt(3);
                    retryCount = attempts;
                    Instant t = proc;
                    for (int a = 1; a <= attempts; a++) {
                        long backoff = latency * a;
                        t = t.plusMillis(backoff);
                        timeline.add(event(seq, t, nodeId, svc, "WARN", "RECOVERY_ATTEMPT",
                                "Auto-recovery attempt " + a + "/" + attempts + " via RETRY_BACKOFF",
                                details("attempt", a, "maxAttempts", attempts, "strategy", "RETRY_BACKOFF",
                                        "backoffMs", backoff, "exceptionType", exType)));
                    }
                    Instant recAt = t.plusMillis(30);
                    cursor = recAt.plusMillis(30);
                    timeline.add(event(seq, recAt, nodeId, svc, "INFO", "RECOVERED",
                            "Trade auto-recovered after " + attempts + " attempt(s)",
                            details("totalAttempts", attempts, "strategy", "RETRY_BACKOFF",
                                    "recoveredAt", recAt.toString(), "tradeId", tradeId)));
                    status = NodeStatus.RECOVERED;
                    exception = new ExceptionInfo(true, exType, exMsg, stackRef, true, attempts,
                            recAt.toString(), "RETRY_BACKOFF");
                } else {
                    retryCount = 1 + rnd.nextInt(3);
                    timeline.add(event(seq, proc.plusMillis(latency), nodeId, svc, "ERROR", "HALTED",
                            "Recovery exhausted - message parked in DLQ, manual intervention required",
                            details("action", "DLQ_PARKED", "requiresManualIntervention", true,
                                    "attempts", retryCount, "dlqTopic", topicFor(i) + ".DLQ",
                                    "exceptionType", exType)));
                    status = NodeStatus.FAILED;
                    exception = new ExceptionInfo(true, exType, exMsg, stackRef, false, retryCount,
                            null, "DLQ_PARKED");
                    halted = true;
                }
            } else {
                status = NodeStatus.SUCCESS;
                timeline.add(event(seq, proc, nodeId, svc, "SUCCESS", "PROCESSED",
                        name + " processed successfully",
                        details("durationMs", latency, "recordsProcessed", 1, "tradeId", tradeId)));

                if (outbox != null) {
                    if (outbox.status() == OutboxStatus.SUCCESS) {
                        timeline.add(event(seq, proc.plusMillis(5), nodeId, svc, "SUCCESS", "OUTBOX_PUBLISHED",
                                "Outbox event published: " + outbox.messageId(),
                                details("outboxId", outbox.messageId(), "topic", outbox.topic(),
                                        "partition", outbox.partition(), "offset", outbox.offset(),
                                        "status", "PUBLISHED")));
                    } else if (outbox.status() == OutboxStatus.PENDING) {
                        status = NodeStatus.PARTIAL;
                        timeline.add(event(seq, proc.plusMillis(5), nodeId, svc, "WARN", "OUTBOX_PENDING",
                                "Trade processed; outbox publish still pending (relay will retry)",
                                details("outboxId", outbox.messageId(), "topic", outbox.topic(),
                                        "status", "PENDING", "relay", "outbox-poller")));
                    }
                }
            }

            NodeMetrics metrics = new NodeMetrics(retryCount, latency, 1);
            nodes.add(new NodeView(nodeId, name, svc, status,
                    recv.toString(), proc.toString(), latency, outbox, exception, metrics, related));
        }

        String overall = failAt < 0 ? "SUCCESS" : (recovered ? "RECOVERED" : "FAILED");
        return new TraceView(tradeId, version, overall, base.toString(), cursor.toString(),
                nodes, edges, timeline);
    }

    // ---------------------------------------------------------------------
    // Helpers
    // ---------------------------------------------------------------------

    private NodeView notStarted(String nodeId, String name, String svc) {
        return new NodeView(nodeId, name, svc, NodeStatus.NOT_STARTED,
                null, null, 0, null, null, new NodeMetrics(0, 0, 0), Map.of());
    }

    /** Only certain stages emit a transactional outbox event. */
    private OutboxInfo outboxFor(int i, Random rnd, String msgId) {
        if (i == 3 || i == 5 || i == 9) {
            boolean pending = rnd.nextInt(100) < 20; // 20% "only trade processed, outbox pending"
            return new OutboxInfo(
                    pending ? OutboxStatus.PENDING : OutboxStatus.SUCCESS,
                    "out-" + msgId + "-" + i,
                    topicFor(i),
                    rnd.nextInt(6),
                    (long) rnd.nextInt(100000));
        }
        return null;
    }

    private String topicFor(int i) {
        return STAGES[i][2] + ".events";
    }

    private TimelineEvent event(int[] seq, Instant ts, String nodeId, String svc,
                                String level, String type, String msg, Map<String, Object> details) {
        return new TimelineEvent("evt-" + (seq[0]++), ts.toString(), nodeId, svc, level, type, msg, details);
    }

    private Map<String, Object> details(Object... kv) {
        Map<String, Object> m = new LinkedHashMap<>();
        for (int i = 0; i + 1 < kv.length; i += 2) {
            m.put(String.valueOf(kv[i]), kv[i + 1]);
        }
        return m;
    }
}
