package com.example.tracer.model;

import java.util.Map;

/**
 * A node as seen by the live tracer at a point in time.
 * Unlike {@link NodeView}, the status here evolves between polls and the
 * tracer keeps polling while {@code terminal == false}.
 *
 * <p>{@code kind}, {@code parentId}, {@code col} and {@code row} describe the node's
 * place in the branching DAG so the UI can lay it out and draw edges; {@code soId}
 * ties a node to the settlement obligation it belongs to (null on the trunk).
 */
public record LiveNodeView(
        String nodeId,
        String kind,
        String name,
        String service,
        int col,
        double row,
        String parentId,
        String soId,
        String status,
        boolean terminal,
        int attempt,
        int maxAttempts,
        long latencyMs,
        String receivedAt,
        String processedAt,
        OutboxInfo outbox,
        ExceptionInfo exception,
        NodeMetrics metrics,
        Map<String, String> relatedIds
) {
}
