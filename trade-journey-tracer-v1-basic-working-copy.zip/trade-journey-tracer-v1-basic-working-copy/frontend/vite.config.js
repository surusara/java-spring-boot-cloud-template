import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Proxy /api to the Spring Boot backend so the UI can use same-origin fetch in dev.
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      '/api': {
        target: 'http://localhost:8080',
        changeOrigin: true
      }
    }
  }
});
