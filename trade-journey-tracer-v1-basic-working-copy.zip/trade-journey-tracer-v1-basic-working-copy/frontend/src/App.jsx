import React, { useCallback, useMemo, useRef, useState } from 'react';
import { fetchTrace, fetchVersions } from './api/traceApi';
import SearchBar from './components/SearchBar';
import Pipeline from './components/Pipeline';
import EventStream from './components/EventStream';
import NodeDetails from './components/NodeDetails';
import TraceSummary from './components/TraceSummary';

export default function App() {
  const [tradeId, setTradeId] = useState('TRD-9F3A21');
  const [versions, setVersions] = useState([]);
  const [version, setVersion] = useState(1);
  const [speed, setSpeed] = useState(850);

  const [trace, setTrace] = useState(null);
  const [liveNodes, setLiveNodes] = useState([]);
  const [events, setEvents] = useState([]);
  const [activeIndex, setActiveIndex] = useState(-1);
  const [selectedNodeId, setSelectedNodeId] = useState(null);

  const [loading, setLoading] = useState(false);
  const [running, setRunning] = useState(false);
  const [error, setError] = useState(null);
  const [statusLabel, setStatusLabel] = useState('Idle');
  const [statusCls, setStatusCls] = useState('idle');
  const [stepsDone, setStepsDone] = useState(0);
  const [elapsed, setElapsed] = useState(0);
  const [failedStage, setFailedStage] = useState(null);

  const timers = useRef([]);
  const runningRef = useRef(false);

  const clearTimers = () => {
    timers.current.forEach(clearTimeout);
    timers.current = [];
  };

  const playback = useCallback((t, spd) => {
    clearTimers();
    runningRef.current = true;
    setRunning(true);
    setError(null);
    setEvents([]);
    setSelectedNodeId(null);
    setActiveIndex(-1);
    setFailedStage(null);
    setStepsDone(0);
    setStatusLabel('Tracing\u2026');
    setStatusCls('run');

    const base = t.nodes.map((n) => ({ ...n, liveStatus: 'NOT_STARTED' }));
    setLiveNodes(base);

    const byNode = {};
    for (const e of t.timeline) (byNode[e.nodeId] = byNode[e.nodeId] || []).push(e);

    const startWall = performance.now();
    let i = 0;

    const setLive = (idx, status) =>
      setLiveNodes((prev) => prev.map((x, k) => (k === idx ? { ...x, liveStatus: status } : x)));

    const pushNodeEvents = (nodeId) => {
      const evs = byNode[nodeId] || [];
      setEvents((prev) => [...prev, ...evs]);
    };

    const finish = () => {
      runningRef.current = false;
      setRunning(false);
      setActiveIndex(-1);
      const overall = t.overallStatus;
      setStatusLabel(overall === 'RECOVERED' ? 'Completed (recovered)' : 'Completed');
      setStatusCls(overall === 'RECOVERED' ? 'recovered' : 'done');
      setElapsed(Math.round(performance.now() - startWall));
    };

    const finishHalted = () => {
      runningRef.current = false;
      setRunning(false);
      setElapsed(Math.round(performance.now() - startWall));
    };

    const stepFn = () => {
      if (!runningRef.current) return;
      if (i >= t.nodes.length) { finish(); return; }

      const n = t.nodes[i];
      if (n.status === 'NOT_STARTED') { finish(); return; }

      setActiveIndex(i);
      setLive(i, 'PROCESSING');
      setElapsed(Math.round(performance.now() - startWall));

      const dur = spd * (0.7 + Math.random() * 0.6);
      const t1 = setTimeout(() => {
        if (!runningRef.current) return;
        setLive(i, n.status);
        pushNodeEvents(n.nodeId);
        setElapsed(Math.round(performance.now() - startWall));

        if (n.status === 'FAILED') {
          setStepsDone(i);
          setFailedStage(`Step ${i + 1} \u00b7 ${n.name}`);
          setStatusLabel('Failed');
          setStatusCls('fail');
          finishHalted();
          return;
        }

        setStepsDone(i + 1);
        i += 1;
        const t2 = setTimeout(stepFn, 180);
        timers.current.push(t2);
      }, dur);
      timers.current.push(t1);
    };

    stepFn();
  }, []);

  const loadAndPlay = useCallback(
    async (id, ver, spd) => {
      setLoading(true);
      setError(null);
      try {
        const t = await fetchTrace(id, ver);
        setTrace(t);
        setVersion(ver);
        playback(t, spd);
      } catch (e) {
        setError(e.message);
        setStatusLabel('Error');
        setStatusCls('fail');
      } finally {
        setLoading(false);
      }
    },
    [playback]
  );

  const onTrace = useCallback(async () => {
    const id = (tradeId || '').trim();
    if (!id) { setError('Enter a Trade ID'); return; }
    clearTimers();
    runningRef.current = false;
    setLoading(true);
    setError(null);
    try {
      const v = await fetchVersions(id);
      setVersions(v.versions || []);
      const latest = v.versions && v.versions.length ? v.versions[v.versions.length - 1].version : 1;
      await loadAndPlay(id, latest, speed);
    } catch (e) {
      setError(e.message);
      setStatusLabel('Error');
      setStatusCls('fail');
      setLoading(false);
    }
  }, [tradeId, speed, loadAndPlay]);

  const onVersionChange = useCallback(
    (v) => {
      setVersion(v);
      if (tradeId.trim()) loadAndPlay(tradeId.trim(), v, speed);
    },
    [tradeId, speed, loadAndPlay]
  );

  const selectedNode = useMemo(
    () => (selectedNodeId ? liveNodes.find((n) => n.nodeId === selectedNodeId) || null : null),
    [selectedNodeId, liveNodes]
  );

  const total = liveNodes.length || 10;

  return (
    <div className="wrap">
      <div className="header">
        <div>
          <div className="title"><span className="dot" /> Live Trade Journey Tracer</div>
          <div className="subtitle">Enter a Trade ID &mdash; the UI calls the trace API and replays the journey across microservices</div>
        </div>
        <div className="legend">
          <span><i style={{ background: '#64748b' }} /> Pending</span>
          <span><i style={{ background: '#22d3ee' }} /> Processing</span>
          <span><i style={{ background: '#2dd4bf' }} /> Success</span>
          <span><i style={{ background: '#fbbf24' }} /> Partial / Recovered</span>
          <span><i style={{ background: '#f87171' }} /> Exception</span>
        </div>
      </div>

      <SearchBar
        tradeId={tradeId}
        setTradeId={setTradeId}
        versions={versions}
        version={version}
        setVersion={onVersionChange}
        speed={speed}
        setSpeed={setSpeed}
        onTrace={onTrace}
        loading={loading}
        running={running}
      />

      {error && <div className="error-bar">{error}</div>}

      {liveNodes.length > 0 ? (
        <Pipeline
          nodes={liveNodes}
          activeIndex={activeIndex}
          onSelect={setSelectedNodeId}
          selectedNodeId={selectedNodeId}
        />
      ) : (
        <div className="stage stage-empty">
          <div className="empty">Enter a Trade ID and press <b>Trace</b> to visualize the journey.</div>
        </div>
      )}

      <div className="grid">
        <EventStream events={events} />
        <div className="right-col">
          <TraceSummary
            tradeId={trace ? trace.tradeId : tradeId}
            version={version}
            overall={trace ? trace.overallStatus : null}
            statusLabel={statusLabel}
            statusCls={statusCls}
            stepsDone={stepsDone}
            total={total}
            elapsed={elapsed}
            failedStage={failedStage}
          />
          <NodeDetails node={selectedNode} />
        </div>
      </div>
    </div>
  );
}
