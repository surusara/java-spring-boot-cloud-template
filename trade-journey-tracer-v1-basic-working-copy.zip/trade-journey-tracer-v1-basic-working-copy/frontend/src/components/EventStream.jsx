import React, { useEffect, useRef, useState } from 'react';
import { levelClass, fmtTime } from '../constants';

// Live, streaming event log with expandable details for investigation.
export default function EventStream({ events }) {
  const logRef = useRef(null);
  const [open, setOpen] = useState({});

  useEffect(() => {
    if (logRef.current) {
      logRef.current.scrollTop = logRef.current.scrollHeight;
    }
  }, [events]);

  const toggle = (id) => setOpen((o) => ({ ...o, [id]: !o[id] }));

  return (
    <div className="card">
      <h3><span className="live" /> Live Event Stream</h3>
      <div className="log" ref={logRef}>
        {events.length === 0 && (
          <div className="empty">Awaiting trace&hellip; press <b>Trace</b> to begin streaming events.</div>
        )}
        {events.map((e) => {
          const hasDetails = e.details && Object.keys(e.details).length > 0;
          return (
            <div key={e.id} className={`logline ${levelClass(e.level)}`}>
              <div className="logline-head" onClick={() => hasDetails && toggle(e.id)}>
                <span className="t">{fmtTime(e.timestamp)}</span>
                <span className="evt-type">{e.eventType}</span>
                <span className="msg">
                  <b>{e.service}</b> {e.message}
                </span>
                {hasDetails && <span className="chev">{open[e.id] ? '\u25BE' : '\u25B8'}</span>}
              </div>
              {hasDetails && open[e.id] && (
                <div className="details">
                  {Object.entries(e.details).map(([k, v]) => (
                    <div className="kv" key={k}>
                      <span className="dk">{k}</span>
                      <span className="dv">{String(v)}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
