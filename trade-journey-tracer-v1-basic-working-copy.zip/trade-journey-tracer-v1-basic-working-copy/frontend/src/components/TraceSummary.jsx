import React from 'react';
import { badgeClass } from '../constants';

export default function TraceSummary({ tradeId, version, overall, statusLabel, statusCls, stepsDone, total, elapsed, failedStage }) {
  return (
    <div className="card">
      <h3>Trace Summary</h3>
      <div className="summary">
        <div className="stat"><span className="k">Status</span><span className={`badge ${statusCls}`}>{statusLabel}</span></div>
        <div className="stat"><span className="k">Trade ID</span><span className="v mono">{tradeId || '\u2014'}</span></div>
        <div className="stat"><span className="k">Version</span><span className="v mono">{version ? `v${version}` : '\u2014'}</span></div>
        <div className="stat"><span className="k">Outcome</span><span className={`badge ${badgeClass(overall)}`}>{overall || '\u2014'}</span></div>
        <div className="stat"><span className="k">Steps Completed</span><span className="v mono">{stepsDone} / {total}</span></div>
        <div className="stat"><span className="k">Elapsed</span><span className="v mono">{elapsed} ms</span></div>
        <div className="stat"><span className="k">Failed Stage</span><span className="v" style={{ color: '#f87171' }}>{failedStage || '\u2014'}</span></div>
      </div>
    </div>
  );
}
