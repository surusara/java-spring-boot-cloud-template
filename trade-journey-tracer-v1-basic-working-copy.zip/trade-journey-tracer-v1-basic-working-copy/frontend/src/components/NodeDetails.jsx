import React from 'react';
import { statusClass } from '../constants';

// Detail inspector for a selected node.
export default function NodeDetails({ node }) {
  if (!node) {
    return (
      <div className="card">
        <h3>Node Inspector</h3>
        <div className="empty">Click any node to inspect its status, outbox and exception detail.</div>
      </div>
    );
  }

  const { outbox, exception, metrics, relatedIds } = node;

  return (
    <div className="card">
      <h3>Node Inspector</h3>
      <div className="node-detail">
        <div className="nd-title">
          <span className={`pill ${statusClass(node.liveStatus || node.status)}`}>{node.liveStatus || node.status}</span>
          <span className="nd-name">{node.name}</span>
        </div>
        <div className="svc-line">{node.service}</div>

        <Row k="Received" v={node.receivedAt} mono />
        <Row k="Processed" v={node.processedAt} mono />
        <Row k="Latency" v={node.latencyMs ? `${node.latencyMs} ms` : '\u2014'} />

        {outbox && (
          <>
            <div className="section">Outbox</div>
            <Row k="Status" v={outbox.status} tag={outbox.status} />
            <Row k="Message" v={outbox.messageId} mono />
            <Row k="Topic" v={outbox.topic} mono />
            <Row k="Partition / Offset" v={`${outbox.partition} / ${outbox.offset}`} mono />
          </>
        )}

        {exception && exception.raised && (
          <>
            <div className="section section-err">Exception</div>
            <Row k="Type" v={exception.type} />
            <Row k="Message" v={exception.message} />
            <Row k="Recovered" v={exception.recovered ? 'YES' : 'NO'} tag={exception.recovered ? 'SUCCESS' : 'FAILED'} />
            <Row k="Attempts" v={exception.recoveryAttempts} />
            <Row k="Strategy" v={exception.recoveryStrategy} />
            {exception.recoveredAt && <Row k="Recovered At" v={exception.recoveredAt} mono />}
            <Row k="Stack Ref" v={exception.stackRef} mono />
          </>
        )}

        {metrics && (
          <>
            <div className="section">Metrics</div>
            <Row k="Retry Count" v={metrics.retryCount} />
            <Row k="Duration" v={`${metrics.durationMs} ms`} />
            <Row k="Records" v={metrics.recordsProcessed} />
          </>
        )}

        {relatedIds && Object.keys(relatedIds).length > 0 && (
          <>
            <div className="section">Related IDs</div>
            {Object.entries(relatedIds).map(([k, v]) => (
              <Row key={k} k={k} v={v} mono />
            ))}
          </>
        )}
      </div>
    </div>
  );
}

function Row({ k, v, mono, tag }) {
  return (
    <div className="stat">
      <span className="k">{k}</span>
      {tag ? (
        <span className={`pill ${statusClass(tag)}`}>{String(v)}</span>
      ) : (
        <span className={`v ${mono ? 'mono' : ''}`}>{v == null ? '\u2014' : String(v)}</span>
      )}
    </div>
  );
}
