import React, { useEffect, useLayoutEffect, useRef } from 'react';
import { NODE_ICONS, statusClass } from '../constants';

export default function Pipeline({ nodes, activeIndex, onSelect, selectedNodeId }) {
  const stageRef = useRef(null);
  const tracerRef = useRef(null);
  const nodeRefs = useRef([]);

  useLayoutEffect(() => {
    const tracer = tracerRef.current;
    const stage = stageRef.current;
    if (!tracer || !stage) return;
    if (activeIndex < 0 || !nodeRefs.current[activeIndex]) {
      tracer.style.opacity = '0';
      return;
    }
    const orb = nodeRefs.current[activeIndex];
    const sRect = stage.getBoundingClientRect();
    const oRect = orb.getBoundingClientRect();
    const x = oRect.left - sRect.left + oRect.width / 2;
    const y = oRect.top - sRect.top + oRect.height / 2;
    tracer.style.left = x + 'px';
    tracer.style.top = y + 'px';
    tracer.style.opacity = '1';
    stage.style.setProperty('--gx', x + 'px');
    orb.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });
  }, [activeIndex, nodes]);

  useEffect(() => {
    const tracer = tracerRef.current;
    if (!tracer) return;
    const cur = nodes[activeIndex];
    if (cur && cur.liveStatus === 'FAILED') {
      tracer.style.background = '#f87171';
      tracer.style.boxShadow = '0 0 14px 5px #f87171';
    } else {
      tracer.style.background = '#fff';
      tracer.style.boxShadow = '0 0 12px 4px var(--cyan)';
    }
  }, [activeIndex, nodes]);

  return (
    <div className="stage" ref={stageRef}>
      <div className="tracer" ref={tracerRef} />
      <div className="pipeline">
        {nodes.map((n, i) => {
          const cls = statusClass(n.liveStatus);
          const icon = n.liveStatus === 'FAILED' ? '\u26A0\uFE0F' : (NODE_ICONS[n.nodeId] || '\u25CF');
          return (
            <React.Fragment key={n.nodeId}>
              <div
                className={`node ${cls} ${selectedNodeId === n.nodeId ? 'selected' : ''}`}
                onClick={() => onSelect(n.nodeId)}
                title="Click for details"
              >
                <div className="orb-wrap" ref={(el) => (nodeRefs.current[i] = el)}>
                  <div className="ring" />
                  <div className="orb">
                    <span className="icon">{icon}</span>
                    <span className="num">{i + 1}</span>
                  </div>
                </div>
                <div className="label">{n.name}</div>
                <div className="svc">{n.service}</div>
                <div className="latency">
                  {n.liveStatus !== 'NOT_STARTED' && n.latencyMs ? `${n.latencyMs} ms` : ''}
                </div>
              </div>

              {i < nodes.length - 1 && (
                <div className={`pipe ${pipeState(nodes, i, activeIndex)}`}>
                  <div className="fill" />
                </div>
              )}
            </React.Fragment>
          );
        })}
      </div>
    </div>
  );
}

function pipeState(nodes, i, activeIndex) {
  const next = nodes[i + 1];
  if (!next) return '';
  if (next.liveStatus === 'FAILED') return 'failed';
  if (activeIndex === i + 1 && (next.liveStatus === 'PROCESSING' || next.liveStatus === 'RECEIVED')) return 'flowing';
  if (['SUCCESS', 'RECOVERED', 'PARTIAL'].includes(next.liveStatus)) return 'done';
  return '';
}
