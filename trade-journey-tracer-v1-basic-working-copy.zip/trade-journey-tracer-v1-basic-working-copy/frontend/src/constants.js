// Static presentation metadata for nodes + status helpers shared across components.

export const NODE_ICONS = {
  'trade-received': '\uD83D\uDCE5',
  'trade-validated': '\uD83D\uDD0D',
  'trade-enriched': '\uD83E\uDDE9',
  'trade-event-published': '\uD83D\uDCE1',
  'trade-consumer': '\uD83D\uDD04',
  'settlement-order': '\uD83D\uDCDD',
  'clearing-netting': '\u2696\uFE0F',
  'funding': '\uD83D\uDCB0',
  'accounting': '\uD83D\uDCCA',
  'payment': '\u2705'
};

// Map a backend NodeStatus (or transient PROCESSING) to a CSS state class.
export function statusClass(status) {
  switch (status) {
    case 'PROCESSING':
    case 'RECEIVED':
      return 'processing';
    case 'SUCCESS':
      return 'success';
    case 'PARTIAL':
      return 'partial';
    case 'RECOVERED':
      return 'recovered';
    case 'FAILED':
      return 'error';
    default:
      return 'pending';
  }
}

export function levelClass(level) {
  switch (level) {
    case 'SUCCESS':
      return 'ok';
    case 'WARN':
      return 'warn';
    case 'ERROR':
      return 'err';
    default:
      return 'info';
  }
}

export function fmtTime(iso) {
  if (!iso) return '--:--:--';
  const d = new Date(iso);
  return d.toTimeString().slice(0, 8) + '.' + String(d.getMilliseconds()).padStart(3, '0');
}

export function badgeClass(overall) {
  switch (overall) {
    case 'SUCCESS':
      return 'done';
    case 'RECOVERED':
      return 'recovered';
    case 'FAILED':
      return 'fail';
    default:
      return 'idle';
  }
}
