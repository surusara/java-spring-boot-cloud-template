// Thin API client for the trace backend. All calls go through the Vite proxy (/api -> :8080).

const BASE = '/api/traces/trades';

async function getJson(url) {
  const res = await fetch(url);
  if (!res.ok) {
    const text = await res.text().catch(() => '');
    throw new Error(`Request failed (${res.status}): ${text || url}`);
  }
  return res.json();
}

export function fetchVersions(tradeId) {
  return getJson(`${BASE}/${encodeURIComponent(tradeId)}/versions`);
}

export function fetchTrace(tradeId, version) {
  return getJson(`${BASE}/${encodeURIComponent(tradeId)}/versions/${version}`);
}

export function fetchNode(tradeId, version, nodeId) {
  return getJson(`${BASE}/${encodeURIComponent(tradeId)}/versions/${version}/nodes/${nodeId}`);
}

export function fetchTimeline(tradeId, version) {
  return getJson(`${BASE}/${encodeURIComponent(tradeId)}/versions/${version}/timeline`);
}
