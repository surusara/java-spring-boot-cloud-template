package com.example.tracer.model;

/**
 * Summary of one version of a trade (a trade may have many versions).
 */
public record VersionSummary(
        int version,
        String overallStatus,
        String lastUpdatedAt
) {
}
