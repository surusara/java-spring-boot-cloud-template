package com.example.tracer.model;

/**
 * Status of the transactional outbox for a node.
 * SUCCESS  = trade processed AND outbox event published.
 * PENDING  = trade processed but outbox publish not yet completed ("only trade processed").
 * FAILED   = outbox publish failed.
 * NONE     = node does not produce an outbox event.
 */
public enum OutboxStatus {
    NONE,
    PENDING,
    SUCCESS,
    FAILED
}
