package com.example.tracer.model;

import java.util.List;

/**
 * Full trace for a single trade version: graph nodes, edges and the timeline.
 */
public record TraceView(
        String tradeId,
        int version,
        String overallStatus,
        String startedAt,
        String lastUpdatedAt,
        List<NodeView> nodes,
        List<EdgeView> edges,
        List<TimelineEvent> timeline
) {
}
