package com.example.tracer.model;

/**
 * Directed edge between two nodes in the journey graph.
 */
public record EdgeView(
        String from,
        String to
) {
}
