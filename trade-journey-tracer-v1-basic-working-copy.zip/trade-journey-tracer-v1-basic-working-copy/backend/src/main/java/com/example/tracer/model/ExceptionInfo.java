package com.example.tracer.model;

/**
 * Exception detail attached to a node when processing failed.
 * Captures whether an auto-recovery succeeded and how it was attempted.
 */
public record ExceptionInfo(
        boolean raised,
        String type,
        String message,
        String stackRef,
        boolean recovered,
        int recoveryAttempts,
        String recoveredAt,
        String recoveryStrategy
) {
}
