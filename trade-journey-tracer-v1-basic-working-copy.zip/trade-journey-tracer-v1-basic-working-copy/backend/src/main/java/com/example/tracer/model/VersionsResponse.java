package com.example.tracer.model;

import java.util.List;

/**
 * Response for "list all versions of a trade".
 */
public record VersionsResponse(
        String tradeId,
        List<VersionSummary> versions
) {
}
