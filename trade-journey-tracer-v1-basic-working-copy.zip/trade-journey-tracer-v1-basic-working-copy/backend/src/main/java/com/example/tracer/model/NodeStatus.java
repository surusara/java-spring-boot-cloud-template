package com.example.tracer.model;

/**
 * Lifecycle status of a single microservice node within a trade journey.
 */
public enum NodeStatus {
    NOT_STARTED,
    RECEIVED,
    PROCESSING,
    SUCCESS,
    FAILED,
    RECOVERED,
    PARTIAL
}
