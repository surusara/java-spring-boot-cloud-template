package com.example.tracer.model;

/**
 * Lightweight per-node metrics surfaced to the UI.
 */
public record NodeMetrics(
        int retryCount,
        long durationMs,
        Integer recordsProcessed
) {
}
