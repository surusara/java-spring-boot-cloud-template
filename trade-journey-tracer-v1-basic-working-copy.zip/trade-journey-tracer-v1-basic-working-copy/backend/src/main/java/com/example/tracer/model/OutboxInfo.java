package com.example.tracer.model;

/**
 * Transactional outbox detail for a node.
 */
public record OutboxInfo(
        OutboxStatus status,
        String messageId,
        String topic,
        Integer partition,
        Long offset
) {
}
