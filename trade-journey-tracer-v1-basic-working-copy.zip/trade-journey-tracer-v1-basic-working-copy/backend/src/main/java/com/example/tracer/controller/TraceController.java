package com.example.tracer.controller;

import com.example.tracer.model.NodeView;
import com.example.tracer.model.TimelineEvent;
import com.example.tracer.model.TraceView;
import com.example.tracer.model.VersionsResponse;
import com.example.tracer.service.TraceService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

/**
 * Trace API. Mirrors the contract in trade_journey_architecture.md.
 */
@RestController
@RequestMapping("/api")
public class TraceController {

    private final TraceService traceService;

    public TraceController(TraceService traceService) {
        this.traceService = traceService;
    }

    @GetMapping("/health")
    public Map<String, String> health() {
        return Map.of("status", "UP", "service", "trade-journey-tracer");
    }

    /** List all versions of a trade. */
    @GetMapping("/traces/trades/{tradeId}/versions")
    public VersionsResponse versions(@PathVariable String tradeId) {
        return traceService.getVersions(tradeId);
    }

    /** Full trace (nodes, edges, timeline) for a trade version. */
    @GetMapping("/traces/trades/{tradeId}/versions/{version}")
    public TraceView trace(@PathVariable String tradeId, @PathVariable int version) {
        return traceService.getTrace(tradeId, version);
    }

    /** Single node detail. */
    @GetMapping("/traces/trades/{tradeId}/versions/{version}/nodes/{nodeId}")
    public NodeView node(@PathVariable String tradeId, @PathVariable int version, @PathVariable String nodeId) {
        return traceService.getNode(tradeId, version, nodeId);
    }

    /** Timeline / event stream for a trade version. */
    @GetMapping("/traces/trades/{tradeId}/versions/{version}/timeline")
    public List<TimelineEvent> timeline(@PathVariable String tradeId, @PathVariable int version) {
        return traceService.getTimeline(tradeId, version);
    }
}
