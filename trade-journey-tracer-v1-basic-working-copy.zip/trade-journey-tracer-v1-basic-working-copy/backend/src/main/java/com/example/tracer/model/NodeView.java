package com.example.tracer.model;

import java.util.Map;

/**
 * A single microservice stage within the trade journey graph.
 */
public record NodeView(
        String nodeId,
        String name,
        String service,
        NodeStatus status,
        String receivedAt,
        String processedAt,
        long latencyMs,
        OutboxInfo outbox,
        ExceptionInfo exception,
        NodeMetrics metrics,
        Map<String, String> relatedIds
) {
}
