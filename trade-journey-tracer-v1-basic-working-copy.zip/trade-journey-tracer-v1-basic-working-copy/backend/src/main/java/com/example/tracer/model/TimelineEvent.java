package com.example.tracer.model;

import java.util.Map;

/**
 * A single event in the trade journey timeline / live event stream.
 * `details` carries arbitrary investigation context (offsets, attempts, stack refs, ...).
 */
public record TimelineEvent(
        String id,
        String timestamp,
        String nodeId,
        String service,
        String level,
        String eventType,
        String message,
        Map<String, Object> details
) {
}
