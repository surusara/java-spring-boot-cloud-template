# Settlement observability kit

This package gives you all three things together:

1. A **sample Spring Boot application** that simulates a settlement flow with DB save, API call, and Kafka publish.
2. A **plug-and-play Spring Boot starter** for timing and tracing.
3. A **step-by-step performance testing guide** using JMeter, VisualVM, Micrometer, and Application Insights / OpenTelemetry.

---

## Project structure

- `settlement-observability-starter/` — reusable starter with `@TimedOperation`, Micrometer timers, and OpenTelemetry spans.
- `settlement-sample-app/` — example app that uses the starter.
- `docs/KQL-queries.md` — KQL queries for p95 DB vs API vs Kafka.
- `load-test/settlement-load-test.jmx` — simple JMeter test plan.

---

## What this sample demonstrates

A single REST API call goes through three measured steps:

- `settlement.db.save` → simulated DB save using H2 + JPA
- `settlement.api.refdata` → simulated downstream HTTP call
- `settlement.kafka.publish` → simulated Kafka publish step
- `settlement.total.processing` → total end-to-end business processing time

This is the exact model you need in a settlement microservice when you want to answer:

- Is the slowdown in DB?
- Is the slowdown in API?
- Is the slowdown in Kafka / messaging?
- Is total latency increasing because of JVM pressure?

---

## Standard metric model for a settlement platform

### Metric names

Use stable, low-cardinality names.

#### Total business timings
- `settlement.total.processing`
- `settlement.trade.validation`
- `settlement.trade.enrichment`
- `settlement.trade.netting`
- `settlement.trade.funding`
- `settlement.trade.accounting`

#### External dependency timings
- `settlement.db.save`
- `settlement.db.read`
- `settlement.api.refdata`
- `settlement.api.accounting`
- `settlement.api.funding`
- `settlement.kafka.publish`
- `settlement.kafka.consume`

#### Throughput counters
- `settlement.processed.count`
- `settlement.failed.count`
- `settlement.kafka.messages.published`
- `settlement.exceptions.count`

#### JVM / runtime metrics
- `jvm.memory.used`
- `jvm.gc.pause`
- `jvm.threads.live`
- `process.cpu.usage`
- `system.cpu.usage`

### Recommended dimensions

Keep dimensions useful but controlled.

Always include:
- `service`
- `environment`
- `version`

Include only when the number of unique values is limited:
- `component` → `db`, `api`, `kafka`, `service`
- `operation` → `save`, `refdata`, `publish`, `process`
- `currency`
- `product`
- `flow`
- `namespace`
- `pod`

Do **not** use high-cardinality values as metric dimensions:
- `tradeId`
- `settlementObligationId`
- `accountId`
- random UUIDs

Those belong in **logs or traces**, not metrics.

---

## Why this model works during performance testing

- **JMeter** tells you the system is slow from outside.
- **Custom metrics** tell you which layer is slow.
- **VisualVM / JFR** tell you which JVM methods or threads are hot.
- **Tracing** gives a clean call-flow view.

Together, they answer both:
- “How slow is it?”
- “Which part is slow?”

---

## How to run the sample app locally

### Prerequisites
- Java 21
- Maven 3.9+

### Build

```bash
mvn clean package
```

### Run

```bash
cd settlement-sample-app
mvn spring-boot:run
```

### Test the API

```bash
curl -X POST http://localhost:8080/api/settlement/process \
  -H "Content-Type: application/json" \
  -d '{"tradeId":"T-1001","currency":"EUR","amount":1200.55,"counterparty":"CPTY1"}'
```

### Prometheus-style metrics endpoint

```bash
http://localhost:8080/actuator/prometheus
```

Search for these timer metrics:
- `settlement_db_save_seconds`
- `settlement_api_refdata_seconds`
- `settlement_kafka_publish_seconds`
- `settlement_total_processing_seconds`

---

## How the plug-and-play starter works

### Annotation
Use the reusable annotation:

```java
@TimedOperation(value = "settlement.db.save", component = "db", operation = "save")
```

### What it does
The starter automatically:
- wraps the method with a Micrometer `Timer`
- attaches common tags such as `service`, `environment`, `version`
- records the method duration

### What tracing helper does
`TraceHelper` creates spans like:
- `db.save.settlement`
- `api.call.refdata`
- `kafka.publish.settlement`

This means metrics answer the “how much time” question, and spans answer the “where in the flow” question.

---

## How to send telemetry to Application Insights

You have two common options.

### Option A — Azure Monitor OpenTelemetry Java agent
Add the Java agent to your app startup:

```bash
java -javaagent:/opt/agents/applicationinsights-agent.jar -jar settlement-sample-app.jar
```

Set the connection string:

```bash
export APPLICATIONINSIGHTS_CONNECTION_STRING="InstrumentationKey=...;IngestionEndpoint=..."
```

### Option B — OpenTelemetry distro / auto instrumentation on AKS
Use Azure Monitor OpenTelemetry-based instrumentation for Java workloads on AKS, then point the cluster or app to your workspace-based Application Insights resource.

---

## AKS deployment sketch

Use environment variables similar to these:

```yaml
env:
  - name: APPLICATIONINSIGHTS_CONNECTION_STRING
    valueFrom:
      secretKeyRef:
        name: appinsights-secret
        key: connection-string
  - name: OTEL_SERVICE_NAME
    value: settlement-sample-app
  - name: OTEL_RESOURCE_ATTRIBUTES
    value: service.namespace=oneposttrade,deployment.environment=prod,service.version=1.0.0
  - name: JAVA_TOOL_OPTIONS
    value: "-javaagent:/opt/agents/applicationinsights-agent.jar"
```

---

## Step-by-step: JMeter

### 1) Download
Download from the official JMeter site.

### 2) Install
- Unzip the archive.
- Ensure Java is installed.
- Start JMeter:
  - macOS/Linux: `bin/jmeter`
  - Windows: `bin/jmeter.bat`

### 3) Open the supplied test plan
Open:
- `load-test/settlement-load-test.jmx`

### 4) Run the test
This test sends POST requests to:
- `/api/settlement/process`

### 5) What to observe in JMeter
Check:
- average response time
- p95 / p99
- throughput
- error %

### 6) What JMeter does **not** tell you
It does not break down DB vs API vs Kafka by itself.
That’s why we add custom metrics and tracing.

---

## Step-by-step: VisualVM

### 1) Download
Download VisualVM from the official site.

### 2) Install
- Unzip it.
- Start VisualVM.

### 3) Attach to the sample app
When the Spring Boot app is running locally, select the Java process in VisualVM.

### 4) Useful tabs
- **Monitor** → CPU, heap, classes, threads
- **Threads** → blocked or waiting threads
- **Sampler** → lightweight hotspot sampling
- **Profiler** → deeper CPU / memory profiling when needed

### 5) What to look for
- Hot methods in DB save logic
- HTTP client calls taking longer than expected
- Too many blocked threads
- GC spikes or growing heap

### 6) When to use it
Use VisualVM after metrics show that the app is slow, not as the first tool.

---

## Step-by-step: how to check metrics during a test

### Local check
1. Start the app.
2. Hit `/actuator/prometheus`.
3. Run the JMeter plan.
4. Refresh the metrics endpoint and watch timer counts increase.

### Application Insights check
If telemetry is flowing to Application Insights:
1. Run the test.
2. Open Logs.
3. Run the KQL queries from `docs/KQL-queries.md`.
4. Compare `settlement.db.save` vs `settlement.api.refdata` vs `settlement.kafka.publish`.

---

## How to read the results

### Case 1 — DB is slow
- `settlement.db.save` p95 grows sharply
- total processing also grows
- VisualVM may show JDBC or Hibernate-heavy time

### Case 2 — downstream API is slow
- `settlement.api.refdata` dominates p95
- request time rises with it
- traces show client span duration increase

### Case 3 — messaging is slow
- `settlement.kafka.publish` grows
- producer spans become longer
- threads may wait on network or broker ack

### Case 4 — JVM pressure
- total latency increases
- CPU and GC metrics rise
- VisualVM shows thread contention or GC pressure

---

## What to do in a real settlement microservice

### For REST APIs
Instrument:
- controller total time
- service business time
- DB calls
- external API calls
- message publish time

### For Kafka consumers
Instrument:
- message lag
- consume to commit time
- business processing time
- DB write time
- downstream publish time
- exception / retry count

### Recommended tracing spans
- `kafka.consume.trade`
- `validate.trade`
- `enrich.trade`
- `db.save.obligation`
- `api.call.refdata`
- `kafka.publish.settlement`

---

## Suggested next upgrade for your real platform

Once the pattern works, convert the sample metrics into your real naming scheme:

- `cashsettlement.tradeconsumer.total.processing`
- `cashsettlement.tradeconsumer.db.save.trade`
- `cashsettlement.tradeconsumer.api.refdata`
- `cashsettlement.tradeconsumer.kafka.publish.so`
- `cashsettlement.settlementprocessor.db.update.status`
- `cashsettlement.funding.api.call`

Then build dashboards around:
- p95 per microservice
- p95 per dependency type
- throughput per flow
- error rate per flow
- JVM pressure per pod

---

## Notes

This sample simulates Kafka timing with `Thread.sleep(...)` instead of requiring a real broker, so you can run it quickly. In your production service, replace `SettlementPublisher` with real `KafkaTemplate` or Kafka Streams instrumentation.
