package com.example.drift.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Externalised topic names for the drift-feed Kafka Streams application.
 * Configure in {@code application.yml} under the {@code drift.feed} prefix.
 *
 * <pre>
 * drift:
 *   feed:
 *     trades-input-topic:   settlement.trades.v1
 *     processing-topic:     settlement.trades.processing.v1
 *     parked-topic:         settlement.trades.parked.v1
 *     config-topic:         settlement.drift-config.v1
 * </pre>
 */
@ConfigurationProperties(prefix = "drift.feed")
public class DriftFeedProperties {

    /** Source topic — raw incoming trades (produced by upstream systems). */
    private String tradesInputTopic = "settlement.trades.v1";

    /** Destination for trades that pass the drift gate (normal processing pipeline). */
    private String processingTopic  = "settlement.trades.processing.v1";

    /**
     * Destination for trades that are held back in COUNTERPARTY_ALLOWLIST,
     * TRADE_ALLOWLIST, or PAUSE modes.  These can be replayed to the source
     * topic later by a separate replay job.
     */
    private String parkedTopic      = "settlement.trades.parked.v1";

    /**
     * Compacted config topic — key = {@code "global"}, value = JSON {@link com.example.drift.model.DriftConfig}.
     * Must be a compacted Kafka topic so the latest config survives broker restarts.
     */
    private String configTopic      = "settlement.drift-config.v1";

    public String getTradesInputTopic() { return tradesInputTopic; }
    public void setTradesInputTopic(String t) { this.tradesInputTopic = t; }

    public String getProcessingTopic()  { return processingTopic; }
    public void setProcessingTopic(String t) { this.processingTopic = t; }

    public String getParkedTopic()      { return parkedTopic; }
    public void setParkedTopic(String t) { this.parkedTopic = t; }

    public String getConfigTopic()      { return configTopic; }
    public void setConfigTopic(String t) { this.configTopic = t; }
}
