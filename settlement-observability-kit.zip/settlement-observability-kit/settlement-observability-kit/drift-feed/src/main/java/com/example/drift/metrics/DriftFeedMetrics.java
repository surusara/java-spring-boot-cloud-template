package com.example.drift.metrics;

import com.example.drift.model.Decision;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.Gauge;
import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.stereotype.Component;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

/**
 * Micrometer metrics for the drift-feed routing decisions.
 *
 * <h3>Metrics exported</h3>
 * <pre>
 * drift_decisions_total{result="process|park|drop", counterparty="...", mode="..."}
 *   → cumulative count of routing decisions by type
 *
 * drift_parked_total{counterparty="...", mode="..."}
 *   → alias for park decisions (easier to alert on in Prometheus)
 *
 * drift_dropped_total{counterparty="...", mode="..."}
 *   → alias for drop decisions
 * </pre>
 *
 * <h3>Prometheus alert examples</h3>
 * <pre>
 * # Alert when drift mode is not OFF (gate is active)
 * rate(drift_decisions_total{result="park"}[5m]) > 0
 *
 * # Alert when drop rate is high (PERCENT gate aggressively filtering)
 * rate(drift_decisions_total{result="drop"}[5m]) > 10
 * </pre>
 */
@Component
public class DriftFeedMetrics {

    private static final String METRIC_DECISIONS = "drift.decisions";

    private final MeterRegistry registry;

    /**
     * Cache of counters keyed by "decision|counterparty|mode" to avoid
     * creating a new Counter object on every message (hot path).
     */
    private final ConcurrentMap<String, Counter> counterCache = new ConcurrentHashMap<>();

    public DriftFeedMetrics(MeterRegistry registry) {
        this.registry = registry;
    }

    /**
     * Records a routing decision.
     * Called once per trade message — must be fast and allocation-free on the hot path.
     *
     * @param decision    the routing outcome
     * @param counterparty the trade's counterparty (for breakdown by counterparty)
     * @param mode        the current drift mode (for breakdown by mode)
     */
    public void recordDecision(Decision decision, String counterparty, String mode) {
        String key = decision.name() + "|" + sanitise(counterparty) + "|" + mode;
        counterCache
                .computeIfAbsent(key, k -> Counter.builder(METRIC_DECISIONS)
                        .description("Number of drift-feed routing decisions")
                        .tag("result",       decision.name().toLowerCase())
                        .tag("counterparty", sanitise(counterparty))
                        .tag("mode",         mode)
                        .register(registry))
                .increment();
    }

    /**
     * Registers a gauge that reflects the current percentage threshold.
     * Call this whenever the drift config changes (from DriftConfigHolder or controller).
     */
    public void recordPercentThreshold(int percentAllowed) {
        Gauge.builder("drift.config.percent.threshold",
                       () -> (double) percentAllowed)
             .description("Current PERCENT mode threshold (0-100)")
             .register(registry);
    }

    // strip characters that would break Prometheus label format
    private String sanitise(String value) {
        if (value == null) return "unknown";
        return value.replaceAll("[^a-zA-Z0-9_.-]", "_");
    }
}
