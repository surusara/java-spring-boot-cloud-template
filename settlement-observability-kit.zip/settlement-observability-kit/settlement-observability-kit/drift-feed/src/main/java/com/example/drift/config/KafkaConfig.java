package com.example.drift.config;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.annotation.EnableKafkaStreams;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;

import java.util.HashMap;
import java.util.Map;

/**
 * Kafka configuration for the drift-feed application.
 *
 * <p>Provides two separate consumer constructs:
 * <ol>
 *   <li>{@code driftConfigListenerContainerFactory} — lightweight {@link org.springframework.kafka.annotation.KafkaListener}
 *       for the compacted config topic (String key, String value)</li>
 *   <li>Kafka Streams (enabled via {@link EnableKafkaStreams}) — configured via
 *       {@code spring.kafka.streams.*} properties in application.yml</li>
 * </ol>
 */
@Configuration
@EnableKafka
@EnableKafkaStreams
public class KafkaConfig {

    @Value("${spring.kafka.bootstrap-servers}")
    private String bootstrapServers;

    // Optional Confluent Cloud SASL props — empty strings when running locally
    @Value("${spring.kafka.properties.security.protocol:PLAINTEXT}")
    private String securityProtocol;

    @Value("${spring.kafka.properties.sasl.mechanism:PLAIN}")
    private String saslMechanism;

    @Value("${spring.kafka.properties.sasl.jaas.config:}")
    private String saslJaasConfig;

    /**
     * Dedicated consumer factory for the drift-config listener.
     * Uses String deserializer — raw JSON is parsed by {@link DriftConfigHolder}.
     */
    @Bean
    public ConsumerFactory<String, String> driftConfigConsumerFactory() {
        Map<String, Object> props = new HashMap<>();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,   StringDeserializer.class);
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest"); // always read full config on restart
        props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, true);

        // Confluent Cloud SASL / SSL (applied only when configured)
        if (!"PLAINTEXT".equals(securityProtocol)) {
            props.put("security.protocol", securityProtocol);
            props.put("sasl.mechanism",   saslMechanism);
            if (!saslJaasConfig.isBlank()) {
                props.put("sasl.jaas.config", saslJaasConfig);
            }
        }
        return new DefaultKafkaConsumerFactory<>(props);
    }

    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, String> driftConfigListenerContainerFactory(
            ConsumerFactory<String, String> driftConfigConsumerFactory) {
        ConcurrentKafkaListenerContainerFactory<String, String> factory =
                new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(driftConfigConsumerFactory);
        factory.setConcurrency(1); // config topic is single-partition
        return factory;
    }
}
