package com.example.drift.config;

import com.example.drift.model.DriftConfig;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import java.util.concurrent.atomic.AtomicReference;

/**
 * Thread-safe holder for the current {@link DriftConfig}.
 *
 * <p>A {@link KafkaListener} on the compacted config topic keeps this in sync.
 * Every instance of the drift-feed application maintains its own local copy —
 * updates propagate within Kafka's polling interval (typically &lt; 1 second).
 *
 * <p>Starts with {@link DriftConfig#defaultOff()} so trades always flow until
 * an explicit PAUSE or filter is published.
 *
 * <h3>Config topic requirements</h3>
 * <ul>
 *   <li>Cleanup policy: {@code compact} — so the latest value survives pod restarts</li>
 *   <li>Message key: {@code "global"} (single-partition single-key pattern)</li>
 *   <li>Message value: JSON {@link DriftConfig}</li>
 *   <li>Partitions: 1 (config is global, no need for parallelism)</li>
 * </ul>
 */
@Component
public class DriftConfigHolder {

    private static final Logger log = LoggerFactory.getLogger(DriftConfigHolder.class);

    private final AtomicReference<DriftConfig> current =
            new AtomicReference<>(DriftConfig.defaultOff());

    private final ObjectMapper mapper;

    public DriftConfigHolder() {
        this.mapper = new ObjectMapper().registerModule(new JavaTimeModule());
    }

    /**
     * Returns the current active drift config.
     * Called on every message in the Streams topology — must be very fast (lock-free read).
     */
    public DriftConfig getCurrent() {
        return current.get();
    }

    /**
     * Replaces the active config with the provided one.
     * Called programmatically when the REST endpoint publishes a new config
     * and the local Kafka listener has not yet received it.
     */
    public void update(DriftConfig config) {
        DriftConfig previous = current.getAndSet(config);
        log.info("DriftConfig updated: {} → {} (by={} reason={})",
                previous.mode(), config.mode(), config.updatedBy(), config.reason());
    }

    /**
     * Kafka listener — receives every update published to the compacted config topic.
     * Spring Kafka deserializes the raw bytes; we parse JSON here for full control.
     */
    @KafkaListener(
            topics       = "${drift.feed.config-topic:settlement.drift-config.v1}",
            groupId      = "drift-config-consumer-${random.uuid}",   // unique per pod — all pods get every message
            containerFactory = "driftConfigListenerContainerFactory"
    )
    public void onConfigUpdate(String payload) {
        if (payload == null || payload.isBlank()) {
            log.warn("Received null/blank drift config message — ignoring");
            return;
        }
        try {
            DriftConfig config = mapper.readValue(payload, DriftConfig.class);
            update(config);
        } catch (Exception e) {
            log.error("Failed to parse drift config message — keeping previous config. payload={}", payload, e);
        }
    }
}
