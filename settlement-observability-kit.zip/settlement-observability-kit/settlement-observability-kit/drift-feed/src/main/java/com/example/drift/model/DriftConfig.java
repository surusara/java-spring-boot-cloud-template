package com.example.drift.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.time.Instant;
import java.util.Set;

/**
 * Immutable configuration record published to the compacted Kafka topic
 * {@code settlement.drift-config.v1} (key = {@code "global"}).
 *
 * <p>All running drift-feed instances pick up changes within seconds via the
 * {@link com.example.drift.config.DriftConfigHolder} Kafka listener.
 *
 * <h3>Examples</h3>
 * <pre>
 * // Canary release — allow 20% of trades through
 * { "mode":"PERCENT", "percentAllowed":20, "reason":"Canary v2.4.1", "updatedBy":"ops1" }
 *
 * // Validate specific counterparties only
 * { "mode":"COUNTERPARTY_ALLOWLIST", "counterparties":["CPTY-A","CPTY-B"], "reason":"Release smoke test" }
 *
 * // Hard pause before release begins
 * { "mode":"PAUSE", "reason":"Pre-release gate activated" }
 *
 * // Back to normal
 * { "mode":"OFF", "reason":"Release validated — full traffic resumed" }
 * </pre>
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public record DriftConfig(

        /** Gate mode — determines routing behaviour for all incoming trades. */
        DriftMode mode,

        /**
         * Used only in {@link DriftMode#PERCENT} mode.
         * Value 0–100 inclusive.  E.g. 25 means 25% of trades are processed.
         */
        int percentAllowed,

        /**
         * Used only in {@link DriftMode#COUNTERPARTY_ALLOWLIST} mode.
         * Trades whose {@code counterparty} field is in this set are PROCESSED;
         * all others are PARKED.
         */
        Set<String> counterparties,

        /**
         * Used only in {@link DriftMode#TRADE_ALLOWLIST} mode.
         * Trades whose {@code tradeId} is in this set are PROCESSED;
         * all others are PARKED.
         */
        Set<String> tradeIds,

        /** Human-readable reason for this config change (appears in audit/metrics). */
        String reason,

        /** Username of the operator who published this config. */
        String updatedBy,

        /** Timestamp when this config was published. */
        Instant updatedAt
) {

    /** Safe default: all trades flow through normally. */
    public static DriftConfig defaultOff() {
        return new DriftConfig(
                DriftMode.OFF, 100,
                Set.of(), Set.of(),
                "system-default", "system", Instant.now());
    }

    /** Returns a copy with audit fields set (called by the REST controller). */
    public DriftConfig withAudit(String user) {
        return new DriftConfig(
                mode, percentAllowed, counterparties, tradeIds,
                reason, user, Instant.now());
    }
}
