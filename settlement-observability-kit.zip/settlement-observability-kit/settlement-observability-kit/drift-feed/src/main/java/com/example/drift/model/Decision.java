package com.example.drift.model;

/**
 * Routing decision produced by {@link com.example.drift.router.DriftFeedRouter} for each trade.
 *
 * <pre>
 * PROCESS → trade forwarded to settlement.trades.processing.v1
 * PARK    → trade forwarded to settlement.trades.parked.v1 (replay later)
 * DROP    → trade silently discarded; only a metric counter is incremented
 * </pre>
 *
 * <h3>When DROP vs PARK is used</h3>
 * <ul>
 *   <li><b>PERCENT mode</b>: non-sampled trades are DROPped — no business need to keep them,
 *       the same messages are still on the source topic with their original offsets.</li>
 *   <li><b>COUNTERPARTY_ALLOWLIST / TRADE_ALLOWLIST / PAUSE</b>: non-matching trades are
 *       PARKed so they can be replayed once the drift gate is opened.</li>
 * </ul>
 */
public enum Decision {
    PROCESS,
    PARK,
    DROP
}
