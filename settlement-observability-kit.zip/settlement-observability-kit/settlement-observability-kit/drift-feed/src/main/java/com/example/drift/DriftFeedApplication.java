package com.example.drift;

import com.example.drift.config.DriftFeedProperties;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

@SpringBootApplication
@EnableConfigurationProperties(DriftFeedProperties.class)
public class DriftFeedApplication {

    public static void main(String[] args) {
        SpringApplication.run(DriftFeedApplication.class, args);
    }
}
