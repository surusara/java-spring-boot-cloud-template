package com.example.drift.controller;

import com.example.drift.config.DriftConfigHolder;
import com.example.drift.metrics.DriftFeedMetrics;
import com.example.drift.model.DriftConfig;
import com.example.drift.model.DriftMode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.*;

import java.util.Set;

/**
 * REST API for viewing and updating the drift-feed gate configuration.
 *
 * <p>Publishing a new config via {@code POST /drift/api/config} writes a message to
 * the compacted Kafka config topic.  All running drift-feed pods pick up the change
 * within seconds via their {@link com.example.drift.config.DriftConfigHolder} listener.
 *
 * <h3>Endpoints</h3>
 * <pre>
 *   GET  /drift/api/config         → current active DriftConfig (local to this pod)
 *   POST /drift/api/config         → publish a new DriftConfig to all pods
 *   POST /drift/api/config/off     → shortcut: immediately open the gate (mode=OFF)
 *   POST /drift/api/config/pause   → shortcut: immediately halt all trade processing
 * </pre>
 *
 * <h3>React UI integration</h3>
 * The UI polls {@code GET /drift/api/config} to show the current mode badge, then calls
 * {@code POST /drift/api/config} with the new mode JSON when the operator clicks Apply.
 */
@RestController
@RequestMapping("/drift/api/config")
public class DriftConfigController {

    private static final Logger log = LoggerFactory.getLogger(DriftConfigController.class);

    private static final String CONFIG_KEY = "global";

    private final DriftConfigHolder    configHolder;
    private final KafkaTemplate<String, String> kafkaTemplate;
    private final DriftFeedMetrics     metrics;
    private final String               configTopic;
    private final ObjectMapper         mapper;

    public DriftConfigController(DriftConfigHolder configHolder,
                                 KafkaTemplate<String, String> kafkaTemplate,
                                 DriftFeedMetrics metrics,
                                 @org.springframework.beans.factory.annotation.Value(
                                         "${drift.feed.config-topic:settlement.drift-config.v1}")
                                 String configTopic) {
        this.configHolder  = configHolder;
        this.kafkaTemplate = kafkaTemplate;
        this.metrics       = metrics;
        this.configTopic   = configTopic;
        this.mapper        = new ObjectMapper().registerModule(new JavaTimeModule());
    }

    // -------------------------------------------------------------------------
    // Read current config
    // -------------------------------------------------------------------------

    /** Returns the currently active drift config on THIS pod instance. */
    @GetMapping
    public DriftConfig currentConfig() {
        return configHolder.getCurrent();
    }

    // -------------------------------------------------------------------------
    // Apply a new full config
    // -------------------------------------------------------------------------

    /**
     * Publishes a new {@link DriftConfig} to the config topic.
     * All drift-feed pods will pick it up within ~1 second.
     *
     * <p><b>Body examples:</b>
     * <pre>
     * // Canary 20% — drops 80% of trades, processes 20%
     * { "mode":"PERCENT", "percentAllowed":20, "reason":"Canary v2.4.1" }
     *
     * // Only process CPTY-A and CPTY-B — park all others
     * { "mode":"COUNTERPARTY_ALLOWLIST", "counterparties":["CPTY-A","CPTY-B"], "reason":"Release smoke test" }
     *
     * // Hard pause — park everything
     * { "mode":"PAUSE", "reason":"Pre-release gate" }
     *
     * // Back to normal
     * { "mode":"OFF", "reason":"Release validated" }
     * </pre>
     */
    @PostMapping
    @PreAuthorize("hasRole('SETTLEMENT_OPS_SUPPORT')")
    public ResponseEntity<DriftConfig> applyConfig(
            @Valid @RequestBody DriftConfigRequest request,
            @AuthenticationPrincipal Jwt jwt) {

        DriftConfig config = buildConfig(request, resolveUsername(jwt));
        publishAndUpdateLocal(config, jwt);
        return ResponseEntity.ok(config);
    }

    // -------------------------------------------------------------------------
    // Convenience shortcuts
    // -------------------------------------------------------------------------

    /** Immediately opens the gate — all trades flow through. */
    @PostMapping("/off")
    @PreAuthorize("hasRole('SETTLEMENT_OPS_SUPPORT')")
    public ResponseEntity<DriftConfig> openGate(
            @RequestParam(defaultValue = "Manual override — gate opened") String reason,
            @AuthenticationPrincipal Jwt jwt) {

        DriftConfig config = new DriftConfig(
                DriftMode.OFF, 100, Set.of(), Set.of(),
                reason, resolveUsername(jwt), java.time.Instant.now());
        publishAndUpdateLocal(config, jwt);
        return ResponseEntity.ok(config);
    }

    /** Immediately pauses all trade processing — parks everything. */
    @PostMapping("/pause")
    @PreAuthorize("hasRole('SETTLEMENT_OPS_SUPPORT')")
    public ResponseEntity<DriftConfig> pauseAll(
            @RequestParam String reason,
            @AuthenticationPrincipal Jwt jwt) {

        DriftConfig config = new DriftConfig(
                DriftMode.PAUSE, 0, Set.of(), Set.of(),
                reason, resolveUsername(jwt), java.time.Instant.now());
        publishAndUpdateLocal(config, jwt);
        return ResponseEntity.ok(config);
    }

    // -------------------------------------------------------------------------
    // Private helpers
    // -------------------------------------------------------------------------

    private void publishAndUpdateLocal(DriftConfig config, Jwt jwt) {
        try {
            String payload = mapper.writeValueAsString(config);
            // Publish to compacted topic — all pods receive this via @KafkaListener
            kafkaTemplate.send(configTopic, CONFIG_KEY, payload)
                    .whenComplete((result, ex) -> {
                        if (ex != null) {
                            log.error("Failed to publish drift config to topic {}", configTopic, ex);
                        } else {
                            log.info("Drift config published to topic={} mode={} by={}",
                                    configTopic, config.mode(), config.updatedBy());
                        }
                    });
        } catch (Exception e) {
            log.error("Serialization error publishing drift config", e);
            throw new IllegalStateException("Failed to serialize DriftConfig: " + e.getMessage(), e);
        }

        // Update local holder immediately so this pod doesn't wait for the round-trip
        configHolder.update(config);

        if (config.mode() == DriftMode.PERCENT) {
            metrics.recordPercentThreshold(config.percentAllowed());
        }
    }

    private DriftConfig buildConfig(DriftConfigRequest req, String user) {
        return new DriftConfig(
                req.mode(),
                req.percentAllowed() != null ? req.percentAllowed() : 100,
                req.counterparties()  != null ? req.counterparties() : Set.of(),
                req.tradeIds()        != null ? req.tradeIds()       : Set.of(),
                req.reason(),
                user,
                java.time.Instant.now());
    }

    private String resolveUsername(Jwt jwt) {
        if (jwt.getClaim("upn") != null)               return jwt.getClaim("upn");
        if (jwt.getClaim("preferred_username") != null) return jwt.getClaim("preferred_username");
        return jwt.getSubject();
    }

    // -------------------------------------------------------------------------
    // Request DTO
    // -------------------------------------------------------------------------

    /**
     * Input type for POST /drift/api/config.
     * Separate from DriftConfig record so the request doesn't require audit fields.
     */
    public record DriftConfigRequest(
            @NotNull DriftMode mode,
            Integer            percentAllowed,
            Set<String>        counterparties,
            Set<String>        tradeIds,
            @jakarta.validation.constraints.NotBlank String reason) {}
}
