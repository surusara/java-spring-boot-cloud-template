package com.example.drift.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * Represents an incoming trade message from the settlement trades Kafka topic.
 *
 * <p>Map this record to the actual schema on your {@code settlement.trades.v1} topic.
 * Fields used for routing decisions:
 * <ul>
 *   <li>{@code tradeId}      — used in PERCENT (hash bucket) and TRADE_ALLOWLIST modes</li>
 *   <li>{@code counterparty} — used in COUNTERPARTY_ALLOWLIST mode</li>
 * </ul>
 *
 * @param tradeId      unique identifier for the trade (Kafka message key is also this value)
 * @param currency     ISO 4217 currency code
 * @param amount       trade notional amount
 * @param counterparty counterparty identifier (used for allowlist routing)
 * @param bookId       trading book identifier
 * @param status       trade status from upstream (e.g. NEW, AMENDED, CANCELLED)
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public record Trade(
        String tradeId,
        String currency,
        double amount,
        String counterparty,
        String bookId,
        String status) {

    /** Compact string for logging — avoids printing full record in hot paths. */
    public String shortDesc() {
        return tradeId + "/" + counterparty + "/" + currency;
    }
}
