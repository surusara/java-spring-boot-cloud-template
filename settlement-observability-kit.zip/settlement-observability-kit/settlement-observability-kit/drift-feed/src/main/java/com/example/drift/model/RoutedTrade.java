package com.example.drift.model;

/**
 * Pairs a {@link Trade} with its routing {@link Decision}.
 * Used as the intermediate value type in the Kafka Streams topology so that
 * the router is called only once per message (avoids duplicate decisions when
 * the stream branches).
 */
public record RoutedTrade(Trade trade, Decision decision) {}
