package com.example.drift.model;

/**
 * Controls how the DriftFeedRouter gates trade messages through the stream.
 *
 * <pre>
 * OFF                  → All trades flow to the processing topic (normal steady-state).
 * PERCENT              → Only N% of trades are processed (hash-based, deterministic).
 *                        The remaining (100-N)% are silently dropped and counted.
 *                        Use for canary validation: 5% → 25% → 50% → 100% after release.
 * COUNTERPARTY_ALLOWLIST → Only trades whose counterparty is in the allowlist are processed.
 *                        Non-matching trades are routed to the PARK topic for replay later.
 *                        Use when a release targets only specific counterparty flows.
 * TRADE_ALLOWLIST      → Only specific tradeIds are processed; all others are parked.
 *                        Use for targeted smoke-testing of specific trades post-release.
 * PAUSE                → ALL trades are parked.  No processing occurs.
 *                        Use for a hard gate before starting a controlled release window.
 * </pre>
 */
public enum DriftMode {

    /** Normal: all trades flow through. */
    OFF,

    /**
     * Percentage gate: process N% of trades (deterministic by tradeId hash).
     * Non-matching trades are DROPPED (counted but not stored).
     */
    PERCENT,

    /**
     * Counterparty allowlist: process only matching counterparties.
     * Non-matching trades are PARKED for replay.
     */
    COUNTERPARTY_ALLOWLIST,

    /**
     * Trade ID allowlist: process only matching tradeIds.
     * Non-matching trades are PARKED for replay.
     */
    TRADE_ALLOWLIST,

    /** Hard pause: ALL trades are PARKED. Use as a full gate before a release. */
    PAUSE
}
