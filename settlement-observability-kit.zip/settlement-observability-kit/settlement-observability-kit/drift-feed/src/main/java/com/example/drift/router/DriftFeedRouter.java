package com.example.drift.router;

import com.example.drift.config.DriftConfigHolder;
import com.example.drift.metrics.DriftFeedMetrics;
import com.example.drift.model.Decision;
import com.example.drift.model.DriftConfig;
import com.example.drift.model.Trade;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * Core routing logic for the drift-feed gate.
 *
 * <p>Called once per message inside the Kafka Streams topology.  Must be
 * stateless and thread-safe (Streams may call it from multiple stream threads).
 *
 * <h3>Routing table</h3>
 * <pre>
 * ┌──────────────────────────┬─────────────────────────────────────┬────────────────┐
 * │ Mode                     │ Condition                           │ Decision       │
 * ├──────────────────────────┼─────────────────────────────────────┼────────────────┤
 * │ OFF                      │ always                              │ PROCESS        │
 * │ PERCENT(N)               │ hash(tradeId) % 100 < N             │ PROCESS        │
 * │ PERCENT(N)               │ hash(tradeId) % 100 >= N            │ DROP           │
 * │ COUNTERPARTY_ALLOWLIST   │ trade.counterparty IN allowlist     │ PROCESS        │
 * │ COUNTERPARTY_ALLOWLIST   │ trade.counterparty NOT IN allowlist │ PARK           │
 * │ TRADE_ALLOWLIST          │ trade.tradeId IN allowlist          │ PROCESS        │
 * │ TRADE_ALLOWLIST          │ trade.tradeId NOT IN allowlist      │ PARK           │
 * │ PAUSE                    │ always                              │ PARK           │
 * └──────────────────────────┴─────────────────────────────────────┴────────────────┘
 * </pre>
 *
 * <h3>DROP vs PARK semantics</h3>
 * <ul>
 *   <li><b>PERCENT mode → DROP</b>: The non-sampled messages are intentionally
 *       discarded.  No replay is needed because the percentage gate is used for
 *       canary validation — once the gate opens fully (mode=OFF) the pipeline
 *       processes all future trades normally.  The original messages are still
 *       on the source topic and can be replayed if required.</li>
 *   <li><b>COUNTERPARTY_ALLOWLIST / TRADE_ALLOWLIST / PAUSE → PARK</b>: These
 *       modes are used when specific trades MUST eventually be processed.
 *       Non-matching (and all trades in PAUSE) are written to the park topic so
 *       a replay job can re-inject them once the gate is opened.</li>
 * </ul>
 */
@Component
public class DriftFeedRouter {

    private static final Logger log = LoggerFactory.getLogger(DriftFeedRouter.class);

    private final DriftConfigHolder configHolder;
    private final DriftFeedMetrics  metrics;

    public DriftFeedRouter(DriftConfigHolder configHolder, DriftFeedMetrics metrics) {
        this.configHolder = configHolder;
        this.metrics      = metrics;
    }

    /**
     * Determines the routing decision for a single trade.
     *
     * @param trade the incoming trade message
     * @return one of PROCESS, PARK, or DROP
     */
    public Decision decide(Trade trade) {
        DriftConfig config = configHolder.getCurrent();
        Decision decision  = evaluate(trade, config);
        metrics.recordDecision(decision, trade.counterparty(), config.mode().name());
        return decision;
    }

    // -------------------------------------------------------------------------
    // Private evaluation logic
    // -------------------------------------------------------------------------

    private Decision evaluate(Trade trade, DriftConfig config) {
        return switch (config.mode()) {

            // ── OFF: all trades flow through ─────────────────────────────────
            case OFF -> Decision.PROCESS;

            // ── PERCENT: process N%, drop the rest ───────────────────────────
            // Hash is deterministic — same tradeId always gets the same decision.
            // Math.floorMod avoids negative values for negative hash codes.
            case PERCENT -> {
                int bucket = Math.floorMod(trade.tradeId().hashCode(), 100);
                if (bucket < config.percentAllowed()) {
                    yield Decision.PROCESS;
                } else {
                    log.debug("PERCENT gate: DROP trade={} bucket={} threshold={}",
                            trade.tradeId(), bucket, config.percentAllowed());
                    yield Decision.DROP;
                }
            }

            // ── COUNTERPARTY_ALLOWLIST: match → process, no-match → park ─────
            // Non-matching trades are PARKED (not dropped) because these trades
            // still need to be processed when the gate opens — missing a
            // counterparty settlement is a business risk.
            case COUNTERPARTY_ALLOWLIST -> {
                if (config.counterparties() != null
                        && config.counterparties().contains(trade.counterparty())) {
                    yield Decision.PROCESS;
                } else {
                    log.debug("COUNTERPARTY_ALLOWLIST gate: PARK trade={} counterparty={}",
                            trade.tradeId(), trade.counterparty());
                    yield Decision.PARK;
                }
            }

            // ── TRADE_ALLOWLIST: match → process, no-match → park ────────────
            case TRADE_ALLOWLIST -> {
                if (config.tradeIds() != null
                        && config.tradeIds().contains(trade.tradeId())) {
                    yield Decision.PROCESS;
                } else {
                    log.debug("TRADE_ALLOWLIST gate: PARK trade={}", trade.tradeId());
                    yield Decision.PARK;
                }
            }

            // ── PAUSE: all trades parked ─────────────────────────────────────
            case PAUSE -> {
                log.debug("PAUSE gate: PARK trade={}", trade.tradeId());
                yield Decision.PARK;
            }
        };
    }
}
