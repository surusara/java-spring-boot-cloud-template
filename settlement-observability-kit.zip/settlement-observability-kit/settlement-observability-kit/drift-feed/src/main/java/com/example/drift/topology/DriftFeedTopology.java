package com.example.drift.topology;

import com.example.drift.config.DriftFeedProperties;
import com.example.drift.metrics.DriftFeedMetrics;
import com.example.drift.model.Decision;
import com.example.drift.model.RoutedTrade;
import com.example.drift.model.Trade;
import com.example.drift.router.DriftFeedRouter;
import com.example.drift.serde.JsonSerde;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.kstream.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Map;

/**
 * Kafka Streams topology for the drift-feed gate.
 *
 * <h3>Flow</h3>
 * <pre>
 *  [settlement.trades.v1]
 *       │
 *       ▼ mapValues: attach routing Decision (calls DriftFeedRouter once per message)
 *  [RoutedTrade stream]
 *       │
 *       ▼ split() into three branches
 *       ├── PROCESS → settlement.trades.processing.v1   (normal pipeline)
 *       ├── PARK    → settlement.trades.parked.v1       (held for replay)
 *       └── DROP    → discard + increment metric counter
 * </pre>
 *
 * <h3>Key routing rules</h3>
 * <ul>
 *   <li><b>PERCENT mode</b>: non-sampled trades → DROP (no storage needed)</li>
 *   <li><b>COUNTERPARTY_ALLOWLIST</b>: non-matching counterparty → PARK</li>
 *   <li><b>TRADE_ALLOWLIST</b>: non-matching tradeId → PARK</li>
 *   <li><b>PAUSE</b>: all trades → PARK</li>
 * </ul>
 *
 * <h3>Config update latency</h3>
 * The {@link DriftFeedRouter} reads config from a {@link com.example.drift.config.DriftConfigHolder}
 * backed by a {@code @KafkaListener}.  Config changes take effect within the
 * Kafka consumer polling interval (default 500 ms).
 */
@Configuration
public class DriftFeedTopology {

    private static final Logger log = LoggerFactory.getLogger(DriftFeedTopology.class);

    private final DriftFeedRouter    router;
    private final DriftFeedProperties props;
    private final DriftFeedMetrics   metrics;

    public DriftFeedTopology(DriftFeedRouter router,
                             DriftFeedProperties props,
                             DriftFeedMetrics metrics) {
        this.router  = router;
        this.props   = props;
        this.metrics = metrics;
    }

    /**
     * Builds and registers the Kafka Streams topology.
     *
     * <p>Spring Boot's {@code @EnableKafkaStreams} auto-discovers this bean and
     * uses the injected {@link StreamsBuilder} to wire the topology on startup.
     */
    @Bean
    public KStream<String, Trade> driftFeedStream(StreamsBuilder builder) {

        JsonSerde<Trade>       tradeSerde       = new JsonSerde<>(Trade.class);
        JsonSerde<RoutedTrade> routedTradeSerde = new JsonSerde<>(RoutedTrade.class);

        // ── Source: incoming trades ─────────────────────────────────────────
        KStream<String, Trade> trades = builder.stream(
                props.getTradesInputTopic(),
                Consumed.with(Serdes.String(), tradeSerde)
                        .withName("source-trades"));

        // ── Route: call DriftFeedRouter once per message ────────────────────
        // Wrapping in RoutedTrade avoids calling router.decide() multiple times
        // in the split branches below (important for determinism + performance).
        KStream<String, RoutedTrade> routed = trades
                .mapValues((key, trade) -> {
                    Decision decision = router.decide(trade);
                    log.trace("Routing trade={} counterparty={} → {}",
                              trade.tradeId(), trade.counterparty(), decision);
                    return new RoutedTrade(trade, decision);
                }, Named.as("drift-gate-router"));

        // ── Branch into three named streams ─────────────────────────────────
        Map<String, KStream<String, RoutedTrade>> branches = routed
                .split(Named.as("drift-gate-"))
                .branch(
                    (key, rt) -> rt.decision() == Decision.PROCESS,
                    Branched.as("process"))
                .branch(
                    (key, rt) -> rt.decision() == Decision.PARK,
                    Branched.as("park"))
                .defaultBranch(
                    Branched.as("drop"));

        // ── PROCESS branch → settlement processing pipeline ─────────────────
        branches.get("drift-gate-process")
                .mapValues(RoutedTrade::trade, Named.as("extract-process-trade"))
                .to(props.getProcessingTopic(),
                    Produced.with(Serdes.String(), tradeSerde)
                            .withName("sink-processing"));

        // ── PARK branch → parked topic for later replay ─────────────────────
        // Trades parked here are NOT lost — a replay job reads this topic and
        // re-publishes to settlement.trades.v1 once the drift gate is opened.
        branches.get("drift-gate-park")
                .mapValues(RoutedTrade::trade, Named.as("extract-park-trade"))
                .peek((key, trade) ->
                    log.debug("PARK trade={} counterparty={} → {}",
                              trade.tradeId(), trade.counterparty(), props.getParkedTopic()))
                .to(props.getParkedTopic(),
                    Produced.with(Serdes.String(), tradeSerde)
                            .withName("sink-parked"));

        // ── DROP branch → discard + count (PERCENT mode only) ───────────────
        // No storage — these are intentional drops for the canary/percent gate.
        branches.get("drift-gate-drop")
                .foreach((key, rt) -> {
                    log.debug("DROP trade={} counterparty={}",
                              rt.trade().tradeId(), rt.trade().counterparty());
                    // metric already recorded in DriftFeedRouter.decide()
                }, Named.as("count-dropped"));

        return trades;
    }
}
