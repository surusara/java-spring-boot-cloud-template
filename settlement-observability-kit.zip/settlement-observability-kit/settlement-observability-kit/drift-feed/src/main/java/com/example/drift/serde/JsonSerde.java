package com.example.drift.serde;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.apache.kafka.common.errors.SerializationException;
import org.apache.kafka.common.serialization.Deserializer;
import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.common.serialization.Serializer;

import java.io.IOException;

/**
 * Generic JSON {@link Serde} for Kafka Streams.
 *
 * <p>Usage in topology:
 * <pre>
 *   JsonSerde&lt;Trade&gt; tradeSerde = new JsonSerde&lt;&gt;(Trade.class);
 *   builder.stream("topic", Consumed.with(Serdes.String(), tradeSerde));
 * </pre>
 *
 * <p>A single shared {@link ObjectMapper} (with JavaTimeModule) is created per
 * serde instance.  Pass a pre-configured mapper if you need custom behaviour.
 */
public class JsonSerde<T> implements Serde<T> {

    private final JsonSerializer<T>   serializer;
    private final JsonDeserializer<T> deserializer;

    public JsonSerde(Class<T> type) {
        this(type, defaultMapper());
    }

    public JsonSerde(Class<T> type, ObjectMapper mapper) {
        this.serializer   = new JsonSerializer<>(mapper);
        this.deserializer = new JsonDeserializer<>(type, mapper);
    }

    @Override public Serializer<T>   serializer()   { return serializer; }
    @Override public Deserializer<T> deserializer() { return deserializer; }

    // -------------------------------------------------------------------------
    // Shared mapper factory
    // -------------------------------------------------------------------------

    private static ObjectMapper defaultMapper() {
        ObjectMapper m = new ObjectMapper();
        m.registerModule(new JavaTimeModule());
        return m;
    }

    // -------------------------------------------------------------------------
    // Serializer
    // -------------------------------------------------------------------------

    private static final class JsonSerializer<T> implements Serializer<T> {
        private final ObjectMapper mapper;

        JsonSerializer(ObjectMapper mapper) { this.mapper = mapper; }

        @Override
        public byte[] serialize(String topic, T data) {
            if (data == null) return null;
            try {
                return mapper.writeValueAsBytes(data);
            } catch (IOException e) {
                throw new SerializationException(
                        "Error serializing value for topic [" + topic + "]", e);
            }
        }
    }

    // -------------------------------------------------------------------------
    // Deserializer
    // -------------------------------------------------------------------------

    private static final class JsonDeserializer<T> implements Deserializer<T> {
        private final Class<T>     type;
        private final ObjectMapper mapper;

        JsonDeserializer(Class<T> type, ObjectMapper mapper) {
            this.type   = type;
            this.mapper = mapper;
        }

        @Override
        public T deserialize(String topic, byte[] data) {
            if (data == null || data.length == 0) return null;
            try {
                return mapper.readValue(data, type);
            } catch (IOException e) {
                // Log and return null so the stream continues — dead-letter handling
                // should be configured at the topology level if strict guarantees are needed.
                throw new SerializationException(
                        "Error deserializing value from topic [" + topic + "]", e);
            }
        }
    }
}
