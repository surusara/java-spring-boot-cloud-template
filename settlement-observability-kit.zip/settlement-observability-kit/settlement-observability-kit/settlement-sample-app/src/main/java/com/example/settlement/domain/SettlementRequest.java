package com.example.settlement.domain;

public record SettlementRequest(String tradeId, String currency, double amount, String counterparty) {}
