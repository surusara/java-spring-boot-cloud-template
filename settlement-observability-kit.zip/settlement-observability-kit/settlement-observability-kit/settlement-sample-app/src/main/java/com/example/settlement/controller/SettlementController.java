package com.example.settlement.controller;

import com.example.settlement.domain.SettlementRequest;
import com.example.settlement.domain.SettlementResponse;
import com.example.settlement.service.SettlementService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/settlement")
public class SettlementController {
    private final SettlementService settlementService;

    public SettlementController(SettlementService settlementService) {
        this.settlementService = settlementService;
    }

    @PostMapping("/process")
    public ResponseEntity<SettlementResponse> process(@RequestBody SettlementRequest request) {
        return ResponseEntity.ok(settlementService.process(request));
    }

    @GetMapping("/healthz")
    public String health() {
        return "OK";
    }
}
