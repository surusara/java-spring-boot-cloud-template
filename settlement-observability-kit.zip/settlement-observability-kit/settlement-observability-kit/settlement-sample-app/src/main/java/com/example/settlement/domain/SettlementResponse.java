package com.example.settlement.domain;

public record SettlementResponse(String tradeId, String status, String message) {}
