package com.example.settlement.service;

import com.example.obs.annotation.TimedOperation;
import com.example.obs.trace.TraceHelper;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import io.opentelemetry.api.trace.SpanKind;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class SettlementPublisher {
    private final Counter publishedCounter;
    private final TraceHelper traceHelper;

    public SettlementPublisher(MeterRegistry registry, TraceHelper traceHelper) {
        this.traceHelper = traceHelper;
        this.publishedCounter = Counter.builder("settlement.kafka.messages.published")
                .description("Simulated Kafka publish count")
                .register(registry);
    }

    @TimedOperation(value = "settlement.kafka.publish", component = "kafka", operation = "publish")
    public void publish(String tradeId, String currency) {
        traceHelper.inSpan("kafka.publish.settlement", SpanKind.PRODUCER,
                Map.of("messaging.system", "kafka", "messaging.destination.name", "settlement.processed.v1", "trade.id", tradeId),
                () -> {
                    try {
                        Thread.sleep(20 + Math.abs(currency.hashCode() % 60));
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    }
                    publishedCounter.increment();
                });
    }
}
