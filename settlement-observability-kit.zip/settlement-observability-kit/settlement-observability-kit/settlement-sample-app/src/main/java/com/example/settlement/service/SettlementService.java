package com.example.settlement.service;

import com.example.obs.annotation.TimedOperation;
import com.example.settlement.api.RefDataResponse;
import com.example.settlement.domain.SettlementEntity;
import com.example.settlement.domain.SettlementRequest;
import com.example.settlement.domain.SettlementResponse;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.stereotype.Service;

@Service
public class SettlementService {
    private final SettlementDbService dbService;
    private final RefDataClient refDataClient;
    private final SettlementPublisher publisher;
    private final Counter processedCounter;

    public SettlementService(SettlementDbService dbService,
                             RefDataClient refDataClient,
                             SettlementPublisher publisher,
                             MeterRegistry registry) {
        this.dbService = dbService;
        this.refDataClient = refDataClient;
        this.publisher = publisher;
        this.processedCounter = Counter.builder("settlement.processed.count")
                .description("Number of settlements processed")
                .register(registry);
    }

    @TimedOperation(value = "settlement.total.processing", component = "service", operation = "process")
    public SettlementResponse process(SettlementRequest request) {
        SettlementEntity entity = dbService.saveSettlement(request);
        RefDataResponse refData = refDataClient.fetchRate(request.currency(), request.tradeId());
        publisher.publish(request.tradeId(), request.currency());
        processedCounter.increment();
        return new SettlementResponse(request.tradeId(), entity.getStatus(), "Processed with rate " + refData.fxRate());
    }
}
