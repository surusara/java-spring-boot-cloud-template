package com.example.settlement.service;

import com.example.obs.annotation.TimedOperation;
import com.example.obs.trace.TraceHelper;
import com.example.settlement.api.RefDataResponse;
import io.opentelemetry.api.trace.SpanKind;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

@Service
public class RefDataClient {
    private final RestTemplate restTemplate;
    private final TraceHelper traceHelper;
    @Value("${server.port:8080}")
    private int serverPort;

    public RefDataClient(RestTemplate restTemplate, TraceHelper traceHelper) {
        this.restTemplate = restTemplate;
        this.traceHelper = traceHelper;
    }

    @TimedOperation(value = "settlement.api.refdata", component = "api", operation = "refdata")
    public RefDataResponse fetchRate(String currency, String tradeId) {
        return traceHelper.inSpan("api.call.refdata", SpanKind.CLIENT,
                Map.of("http.method", "GET", "server.address", "localhost", "trade.id", tradeId),
                () -> {
                    String url = "http://localhost:" + serverPort + "/api/refdata/rate?currency=" + currency;
                    return restTemplate.getForObject(url, RefDataResponse.class);
                });
    }
}
