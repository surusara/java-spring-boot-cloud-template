package com.example.settlement.api;

public record RefDataResponse(String currency, double fxRate, String market) {}
