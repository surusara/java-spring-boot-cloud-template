package com.example.settlement.repo;

import com.example.settlement.domain.SettlementEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SettlementRepository extends JpaRepository<SettlementEntity, Long> {
}
