package com.example.settlement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SettlementSampleApplication {
    public static void main(String[] args) {
        SpringApplication.run(SettlementSampleApplication.class, args);
    }
}
