package com.example.settlement.service;

import com.example.obs.annotation.TimedOperation;
import com.example.obs.trace.TraceHelper;
import com.example.settlement.domain.SettlementEntity;
import com.example.settlement.domain.SettlementRequest;
import com.example.settlement.repo.SettlementRepository;
import io.opentelemetry.api.trace.SpanKind;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.Map;

@Service
public class SettlementDbService {
    private final SettlementRepository repository;
    private final TraceHelper traceHelper;

    public SettlementDbService(SettlementRepository repository, TraceHelper traceHelper) {
        this.repository = repository;
        this.traceHelper = traceHelper;
    }

    @TimedOperation(value = "settlement.db.save", component = "db", operation = "save")
    public SettlementEntity saveSettlement(SettlementRequest request) {
        return traceHelper.inSpan("db.save.settlement", SpanKind.INTERNAL,
                Map.of("db.system", "h2", "trade.id", request.tradeId()),
                () -> {
                    try {
                        Thread.sleep(30 + Math.abs(request.tradeId().hashCode() % 70));
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    }
                    SettlementEntity entity = new SettlementEntity();
                    entity.setTradeId(request.tradeId());
                    entity.setCurrency(request.currency());
                    entity.setAmount(request.amount());
                    entity.setCounterparty(request.counterparty());
                    entity.setStatus("SAVED");
                    entity.setCreatedAt(Instant.now());
                    return repository.save(entity);
                });
    }
}
