package com.example.settlement.controller;

import com.example.settlement.api.RefDataResponse;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RefDataController {

    @GetMapping("/api/refdata/rate")
    public RefDataResponse getRate(@RequestParam String currency) throws InterruptedException {
        Thread.sleep(40 + Math.abs(currency.hashCode() % 80));
        double rate = switch (currency.toUpperCase()) {
            case "EUR" -> 1.08;
            case "GBP" -> 1.27;
            case "JPY" -> 0.0067;
            default -> 1.00;
        };
        return new RefDataResponse(currency.toUpperCase(), rate, "SIMULATED");
    }
}
