# Performance Architecture Guideline — Java Spring Boot Microservices

> **Target:** 1,000,000 transactions/day | **Stack:** Java 21 · Spring Boot 3.x · Kubernetes · KEDA  
> **Audience:** Any developer working on performance tuning, capacity planning, or autoscaling.

---

## Table of Contents

1. [Volume Breakdown & Throughput Targets](#1-volume-breakdown--throughput-targets)
2. [JVM & Spring Boot Tuning](#2-jvm--spring-boot-tuning)
3. [Application-Level Performance Patterns](#3-application-level-performance-patterns)
4. [Database Performance](#4-database-performance)
5. [HTTP Client Tuning](#5-http-client-tuning)
6. [Kafka Producer Tuning](#6-kafka-producer-tuning)
7. [Connection Pool Sizing Formula](#7-connection-pool-sizing-formula)
8. [Observability for Performance](#8-observability-for-performance)
9. [Load Testing Methodology](#9-load-testing-methodology)
10. [Pod Sizing & Capacity Planning](#10-pod-sizing--capacity-planning)
11. [Autoscaling Strategies](#11-autoscaling-strategies)
12. [Kubernetes Resource Configuration](#12-kubernetes-resource-configuration)
13. [Performance Checklist](#13-performance-checklist)
14. [Reference Project — Settlement Observability Kit](#14-reference-project--settlement-observability-kit)
15. [Appendix — Reference Configurations](#appendix--reference-configurations)

---

## 1. Volume Breakdown & Throughput Targets

### Traffic Math

| Metric | Value |
|---|---|
| Daily volume | 1,000,000 |
| Peak hours (assume 8h active window) | 8 hours |
| Avg TPS (uniform) | ~12 TPS |
| Peak TPS (3× avg) | ~36 TPS |
| Burst TPS (5× avg, spike) | ~60 TPS |
| Target p95 latency | < 200 ms |
| Target p99 latency | < 500 ms |
| Error rate | < 0.1% |

### Derive Your Own Numbers

```
avg_tps  = daily_volume / (active_hours × 3600)
peak_tps = avg_tps × peak_multiplier         # typically 3×
burst_tps = avg_tps × burst_multiplier        # typically 5×
```

> **Rule of thumb:** Size for peak TPS, autoscale for burst.

---

## 2. JVM & Spring Boot Tuning

### 2.1 JVM Flags (Java 21 — Containers)

```bash
# Production JVM flags for containerized Spring Boot
JAVA_OPTS="\
  -XX:+UseZGC \
  -XX:+ZGenerational \
  -Xms512m \
  -Xmx512m \
  -XX:MaxDirectMemorySize=128m \
  -XX:+UseContainerSupport \
  -XX:MaxRAMPercentage=75.0 \
  -XX:+ExitOnOutOfMemoryError \
  -XX:+HeapDumpOnOutOfMemoryError \
  -XX:HeapDumpPath=/tmp/heapdump.hprof \
  -Djava.security.egd=file:/dev/./urandom"
```

| Flag | Why |
|---|---|
| `UseZGC + ZGenerational` | Sub-millisecond GC pauses, great for latency-sensitive workloads (Java 21+) |
| `Xms == Xmx` | Avoids heap resizing overhead; container-friendly |
| `MaxRAMPercentage=75` | Leave 25% for metaspace, thread stacks, off-heap buffers |
| `ExitOnOutOfMemoryError` | Let Kubernetes restart the pod instead of running degraded |
| `UseContainerSupport` | JVM respects container cgroup memory/CPU limits |

### 2.2 Virtual Threads (Java 21 — Project Loom)

For I/O-heavy settlement processing (DB + HTTP + Kafka), virtual threads provide massive throughput improvement with zero code changes:

```yaml
# application.yml
spring:
  threads:
    virtual:
      enabled: true   # Spring Boot 3.2+
```

**Impact:** Tomcat handles each request on a virtual thread. Blocking I/O (JDBC, HTTP, Kafka send) no longer pins a platform thread. One pod can handle 1000+ concurrent requests instead of being limited to the Tomcat thread pool size.

**When NOT to use:** CPU-bound processing (encryption, complex calculations) — virtual threads don't help and can increase scheduling overhead.

### 2.3 Tomcat Tuning

```yaml
server:
  tomcat:
    threads:
      max: 200          # platform threads; with virtual threads this is ignored
      min-spare: 20
    max-connections: 8192
    accept-count: 100
    connection-timeout: 5000
```

> With virtual threads enabled, `max-threads` is effectively unlimited. The bottleneck shifts to downstream resources (DB pool, HTTP client pool).

---

## 3. Application-Level Performance Patterns

### 3.1 Async Processing Where Possible

If the Kafka publish does not need to complete before responding to the client, fire-and-forget:

```java
@Service
public class SettlementService {

    @TimedOperation(value = "settlement.total.processing", component = "service", operation = "process")
    public SettlementResponse process(SettlementRequest request) {
        // DB save — must complete before response
        SettlementEntity entity = dbService.saveSettlement(request);

        // Ref data — must complete before response
        RefDataResponse refData = refDataClient.fetchRate(request.currency(), request.tradeId());

        // Kafka publish — fire-and-forget (async)
        publisher.publishAsync(request.tradeId(), request.currency());

        processedCounter.increment();
        return new SettlementResponse(request.tradeId(), entity.getStatus(),
                "Processed with rate " + refData.fxRate());
    }
}
```

### 3.2 Parallel Independent Operations

If DB save and RefData fetch are independent, run in parallel:

```java
@TimedOperation(value = "settlement.total.processing", component = "service", operation = "process")
public SettlementResponse process(SettlementRequest request) {
    try (var scope = new StructuredTaskScope.ShutdownOnFailure()) {
        // DB save and refdata lookup in parallel
        Subtask<SettlementEntity> dbTask = scope.fork(() -> dbService.saveSettlement(request));
        Subtask<RefDataResponse> refTask = scope.fork(() ->
                refDataClient.fetchRate(request.currency(), request.tradeId()));

        scope.join().throwIfFailed();

        publisher.publishAsync(request.tradeId(), request.currency());
        processedCounter.increment();

        return new SettlementResponse(request.tradeId(), dbTask.get().getStatus(),
                "Processed with rate " + refTask.get().fxRate());
    }
}
```

> **Impact:** If DB takes 60ms and RefData takes 80ms, sequential = 140ms, parallel = 80ms. At 1M/day this saves ~16 hours of cumulative CPU time.

### 3.3 Batch Processing for Bulk Endpoints

For batch ingestion, use `saveAll()` and batch inserts:

```yaml
spring:
  jpa:
    properties:
      hibernate:
        jdbc:
          batch_size: 50
        order_inserts: true
        order_updates: true
```

### 3.4 Caching Reference Data

If RefData (e.g., FX rates) changes infrequently, cache it:

```java
@Cacheable(value = "refdata-rates", key = "#currency")
@TimedOperation(value = "settlement.api.refdata", component = "api", operation = "refdata")
public RefDataResponse fetchRate(String currency, String tradeId) {
    // HTTP call only on cache miss
}
```

```yaml
spring:
  cache:
    type: caffeine
    caffeine:
      spec: maximumSize=500,expireAfterWrite=300s
```

> **Impact:** RefData hits drop by 90%+ in typical settlement runs where the same currency repeats.

---

## 4. Database Performance

### 4.1 Connection Pool (HikariCP)

```yaml
spring:
  datasource:
    hikari:
      maximum-pool-size: 20       # per pod
      minimum-idle: 5
      idle-timeout: 30000
      connection-timeout: 5000    # fail fast
      max-lifetime: 1800000       # 30 min — rotate before DB kills idle
      leak-detection-threshold: 10000
```

**Sizing formula:**

```
pool_size = (peak_tps_per_pod × avg_query_duration_sec) + headroom
         = (36 × 0.06) + 5
         ≈ 8  (minimum viable), set to 15-20 for safety
```

> **Rule:** Pool size × pod count must not exceed the DB's `max_connections`. If DB allows 200 connections and pool=20, you can run max 10 pods.

### 4.2 Indexing

```sql
-- Essential indexes for settlement queries
CREATE INDEX idx_settlement_trade_id ON settlement_entity(trade_id);
CREATE INDEX idx_settlement_status ON settlement_entity(status);
CREATE INDEX idx_settlement_created_at ON settlement_entity(created_at);
-- Composite for common query patterns
CREATE INDEX idx_settlement_status_created ON settlement_entity(status, created_at);
```

### 4.3 Query Optimization

- Use `@Query` with projections instead of loading full entities when you only need a few fields
- Enable query plan caching: `spring.jpa.properties.hibernate.query.plan_parameter_metadata_max_size=128`
- Avoid N+1 queries — use `@EntityGraph` or `JOIN FETCH`
- Monitor slow queries with `spring.jpa.properties.hibernate.generate_statistics=true` (dev only)

---

## 5. HTTP Client Tuning

Replace `RestTemplate` with connection-pooled `RestClient` or `WebClient`:

### 5.1 RestClient (Spring Boot 3.2+ — Recommended)

```java
@Configuration
public class RestClientConfig {

    @Bean
    public RestClient restClient(RestClient.Builder builder) {
        return builder
                .baseUrl("http://refdata-service:8080")
                .requestFactory(clientHttpRequestFactory())
                .build();
    }

    private ClientHttpRequestFactory clientHttpRequestFactory() {
        var factory = new org.springframework.http.client.JdkClientHttpRequestFactory();
        factory.setReadTimeout(Duration.ofSeconds(3));
        return factory;
    }
}
```

### 5.2 Connection Pooling (Apache HttpClient 5)

```java
@Bean
public ClientHttpRequestFactory clientHttpRequestFactory() {
    var connManager = PoolingHttpClientConnectionManagerBuilder.create()
            .setMaxConnTotal(100)
            .setMaxConnPerRoute(50)
            .build();

    var httpClient = HttpClients.custom()
            .setConnectionManager(connManager)
            .setDefaultRequestConfig(RequestConfig.custom()
                    .setConnectionRequestTimeout(Timeout.ofSeconds(2))
                    .setResponseTimeout(Timeout.ofSeconds(3))
                    .build())
            .build();

    return new HttpComponentsClientHttpRequestFactory(httpClient);
}
```

### 5.3 Timeouts and Circuit Breakers

```yaml
# Resilience4j circuit breaker for external API calls
resilience4j:
  circuitbreaker:
    instances:
      refdata:
        slidingWindowSize: 100
        failureRateThreshold: 50
        waitDurationInOpenState: 30s
        permittedNumberOfCallsInHalfOpenState: 10
  retry:
    instances:
      refdata:
        maxAttempts: 3
        waitDuration: 500ms
        retryExceptions:
          - java.net.SocketTimeoutException
          - org.springframework.web.client.ResourceAccessException
```

---

## 6. Kafka Producer Tuning

```yaml
spring:
  kafka:
    producer:
      batch-size: 16384           # 16 KB — batch messages before send
      linger-ms: 5                # wait up to 5ms to fill a batch
      buffer-memory: 33554432     # 32 MB send buffer
      compression-type: lz4       # best throughput/CPU ratio
      acks: 1                     # leader ack only (fastest)
      retries: 3
      properties:
        max.in.flight.requests.per.connection: 5
        delivery.timeout.ms: 30000
```

> For fire-and-forget publish, use `KafkaTemplate.send()` without calling `.get()` on the future. Monitor delivery failures via producer metrics.

---

## 7. Connection Pool Sizing Formula

### Universal Formula

```
required_connections_per_pod = ceil(peak_tps_per_pod × avg_io_duration_seconds) + buffer

Total across cluster:
total_connections = required_connections_per_pod × max_pod_count
```

### Example: Settlement Service at 1M/day

| Resource | TPS/pod | Avg I/O | Pool Size | Max Pods | Total |
|---|---|---|---|---|---|
| Database (HikariCP) | 18 | 60ms | 15 | 6 | 90 |
| HTTP Client (RefData) | 18 | 80ms | 15 | 6 | 90 |
| Kafka Producer | 18 | 20ms | 5 | 6 | 30 |

> **Critical:** Ensure downstream resources (DB, API gateway) can sustain `total_connections` at max scale.

---

## 8. Observability for Performance

### 8.1 Key Metrics to Track

| Metric | Source | Alert Threshold |
|---|---|---|
| `http.server.requests` (p95) | Micrometer | > 200ms |
| `settlement.db.save` (p95) | Custom Timer | > 100ms |
| `settlement.api.refdata` (p95) | Custom Timer | > 150ms |
| `settlement.kafka.publish` (p95) | Custom Timer | > 50ms |
| `hikaricp.connections.active` | Micrometer | > 80% of max |
| `jvm.gc.pause` (p99) | Micrometer | > 50ms |
| `jvm.memory.used` | Micrometer | > 80% of max |
| `system.cpu.usage` | Micrometer | > 70% sustained |
| `settlement.processed.count` (rate) | Custom Counter | < expected TPS |
| `http.server.requests` (5xx rate) | Micrometer | > 0.1% |

### 8.2 Prometheus Scrape Configuration

```yaml
management:
  endpoints:
    web:
      exposure:
        include: health,info,metrics,prometheus
  metrics:
    tags:
      application: ${spring.application.name}
    distribution:
      percentiles-histogram:
        http.server.requests: true
        settlement.total.processing: true
      slo:
        http.server.requests: 50ms,100ms,200ms,500ms
```

### 8.3 KQL Queries for Capacity Planning

Refer to [KQL-queries.md](KQL-queries.md) for monitoring queries. Key additions for capacity planning:

```kusto
-- TPS per pod over time (use during load tests)
AppMetrics
| where TimeGenerated > ago(1h)
| where Name == "settlement.processed.count"
| extend pod = tostring(Properties["k8s.pod.name"])
| summarize tps = count() / 300.0 by pod, bin(TimeGenerated, 5m)
| render timechart

-- Connection pool saturation
AppMetrics
| where TimeGenerated > ago(1h)
| where Name == "hikaricp.connections.active"
| extend pod = tostring(Properties["k8s.pod.name"])
| summarize max_active = max(Value), avg_active = avg(Value) by pod, bin(TimeGenerated, 5m)
| render timechart
```

---

## 9. Load Testing Methodology

### 9.1 Test Strategy — Progressive Ramp

Run load tests in phases to find the per-pod throughput ceiling:

| Phase | Threads | Duration | Goal |
|---|---|---|---|
| **Warmup** | 5 | 2 min | JIT compilation, pool init |
| **Baseline** | 10 | 5 min | Measure single-pod p95 |
| **Ramp** | 20 → 50 → 100 | 5 min each | Find the inflection point |
| **Saturation** | 150+ | 10 min | Identify ceiling & failure mode |
| **Soak** | Target TPS | 30-60 min | Memory leaks, GC pressure |

### 9.2 JMeter Configuration for 1M/Day Simulation

Update the [settlement-load-test.jmx](../load-test/settlement-load-test.jmx):

```
# Simulate peak hour (125K/hour = ~35 TPS)
Threads:           50
Ramp-up:           60 seconds
Duration:          600 seconds (10 min)
Target throughput: 35 req/sec (via Constant Throughput Timer)
```

### 9.3 Finding Per-Pod Capacity

Run against a **single pod** with increasing load until:

1. **p95 latency exceeds SLO** (e.g., > 200ms)
2. **Error rate exceeds 0.1%**
3. **CPU exceeds 80%** sustained
4. **Connection pool exhaustion** (HikariCP timeout errors)

The TPS at which any of these thresholds is breached = **per-pod capacity**.

### 9.4 Example Capacity Calculation

```
Observed per-pod capacity:      20 TPS (p95 < 200ms, CPU < 70%)
Peak TPS required:              36 TPS
Burst TPS required:             60 TPS

Min pods for peak:              ceil(36 / 20) = 2 pods
Min pods for burst:             ceil(60 / 20) = 3 pods
Pods with headroom (30%):       ceil(3 × 1.3) = 4 pods

Recommendation:
  - Minimum replicas:   2
  - Maximum replicas:   6
  - Target steady-state: 3 pods
```

### 9.5 Load Test Report Template

After each load test, record:

```markdown
## Load Test Report — [Date]
- **Version:** [app version / commit SHA]
- **Pod config:** [CPU/memory requests & limits]
- **Pod count:** [number of replicas during test]
- **JVM flags:** [JAVA_OPTS used]
- **Duration:** [test duration]
- **Total requests:** [count]
- **Avg TPS achieved:** [value]
- **p50/p95/p99 latency:** [values in ms]
- **Error rate:** [percentage]
- **CPU avg/peak:** [percentage]
- **Memory avg/peak:** [MB]
- **GC pause max:** [ms]
- **HikariCP pool utilization:** [active/max]
- **Bottleneck identified:** [DB / HTTP / Kafka / CPU / Memory / None]
- **Recommended pods:** [min-max range]
```

---

## 10. Pod Sizing & Capacity Planning

### 10.1 Resource Requests & Limits

```yaml
resources:
  requests:
    cpu: "500m"        # 0.5 vCPU — guaranteed minimum
    memory: "768Mi"    # heap (512m) + metaspace + overhead
  limits:
    cpu: "1000m"       # 1 vCPU — burstable
    memory: "1Gi"      # hard ceiling — OOMKill if exceeded
```

**Sizing rationale:**

| Component | Memory |
|---|---|
| JVM Heap (`-Xmx`) | 512 MB |
| Metaspace | ~100 MB |
| Thread stacks (200 threads × 1MB) | ~200 MB |
| Direct buffers, native | ~100 MB |
| **Total** | **~912 MB → round to 1Gi limit** |

> With virtual threads, thread stacks are negligible (~few KB each), so 768Mi limit may suffice.

### 10.2 Pod Count Decision Matrix

| Volume/Day | Per-Pod TPS | Peak TPS (3×) | Min Pods | With Headroom | Max Pods (Burst) |
|---|---|---|---|---|---|
| 500K | 20 | 18 | 1 | 2 | 3 |
| 1M | 20 | 36 | 2 | 3 | 6 |
| 2M | 20 | 72 | 4 | 5 | 10 |
| 5M | 20 | 180 | 9 | 12 | 20 |

> **Per-pod TPS must be measured, not assumed.** The values above use 20 TPS as an example. Your actual number depends on DB latency, network hops, and processing complexity.

### 10.3 Startup & Readiness

Fast startup is crucial for autoscaling effectiveness:

```yaml
# Kubernetes probes
livenessProbe:
  httpGet:
    path: /actuator/health/liveness
    port: 8080
  initialDelaySeconds: 15
  periodSeconds: 10
  failureThreshold: 3

readinessProbe:
  httpGet:
    path: /actuator/health/readiness
    port: 8080
  initialDelaySeconds: 10
  periodSeconds: 5
  failureThreshold: 3

startupProbe:
  httpGet:
    path: /actuator/health/liveness
    port: 8080
  initialDelaySeconds: 5
  periodSeconds: 5
  failureThreshold: 12     # 5 + (12 × 5) = 65 seconds max startup
```

**Optimize startup time:**

```yaml
spring:
  jmx:
    enabled: false
  main:
    lazy-initialization: false   # keep false for production
```

- Use Spring AOT / GraalVM native image for sub-second startup if autoscaling aggressively
- Pre-warm connection pools with `spring.datasource.hikari.initialization-fail-timeout=0`

---

## 11. Autoscaling Strategies

### 11.1 Strategy Comparison

| Strategy | Best For | Scale Signal | Response Time |
|---|---|---|---|
| **Fixed Pods** | Predictable, steady traffic | None (manual) | N/A |
| **HPA (CPU/Memory)** | General-purpose scaling | Resource utilization | 30-60s |
| **KEDA (Prometheus)** | Metric-driven (TPS, latency, queue depth) | Custom app metrics | 15-30s |
| **KEDA (Kafka)** | Message-driven services | Consumer lag | 15-30s |

### 11.2 Strategy 1 — Fixed Pod Count

Use when traffic is predictable and cost optimization is less critical:

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: settlement-service
spec:
  replicas: 3      # fixed count based on load test results
  # ...
```

**When to use:**
- Batch processing windows with known volume
- Regulated environments requiring stable capacity
- When downstream systems cannot handle rapid connection scaling

### 11.3 Strategy 2 — HPA (CPU/Memory Based)

```yaml
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: settlement-hpa
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: settlement-service
  minReplicas: 2
  maxReplicas: 6
  metrics:
    - type: Resource
      resource:
        name: cpu
        target:
          type: Utilization
          averageUtilization: 65     # scale up when CPU > 65%
    - type: Resource
      resource:
        name: memory
        target:
          type: Utilization
          averageUtilization: 75     # scale up when memory > 75%
  behavior:
    scaleUp:
      stabilizationWindowSeconds: 30
      policies:
        - type: Pods
          value: 2                    # add max 2 pods at a time
          periodSeconds: 60
    scaleDown:
      stabilizationWindowSeconds: 300  # wait 5 min before scale down
      policies:
        - type: Pods
          value: 1                    # remove 1 pod at a time
          periodSeconds: 120
```

**Tuning tips:**
- Set CPU target to 60-70% — scaling must trigger **before** saturation
- Scale-down must be conservative (5min window) to avoid flapping
- Memory-based scaling is less responsive; use as a safety net alongside CPU

### 11.4 Strategy 3 — KEDA (Prometheus Metrics Based)

KEDA enables scaling based on actual business metrics, which is far more accurate than CPU:

#### Install KEDA

```bash
helm repo add kedacore https://kedacore.github.io/charts
helm install keda kedacore/keda --namespace keda --create-namespace
```

#### Scale on TPS (Request Rate)

```yaml
apiVersion: keda.sh/v1alpha1
kind: ScaledObject
metadata:
  name: settlement-scaledobject
spec:
  scaleTargetRef:
    name: settlement-service
  minReplicaCount: 2
  maxReplicaCount: 8
  pollingInterval: 15
  cooldownPeriod: 300           # 5 min cooldown before scale-down
  triggers:
    - type: prometheus
      metadata:
        serverAddress: http://prometheus.monitoring.svc:9090
        metricName: settlement_requests_per_second
        query: |
          sum(rate(http_server_requests_seconds_count{application="settlement-sample-app",uri="/api/settlement/process"}[2m]))
        threshold: "20"          # 20 TPS per pod — scale up when exceeded
        activationThreshold: "5" # don't scale below 5 TPS total
```

#### Scale on Response Latency (p95)

```yaml
apiVersion: keda.sh/v1alpha1
kind: ScaledObject
metadata:
  name: settlement-latency-scaledobject
spec:
  scaleTargetRef:
    name: settlement-service
  minReplicaCount: 2
  maxReplicaCount: 8
  pollingInterval: 15
  cooldownPeriod: 300
  triggers:
    - type: prometheus
      metadata:
        serverAddress: http://prometheus.monitoring.svc:9090
        metricName: settlement_p95_latency
        query: |
          histogram_quantile(0.95, sum(rate(http_server_requests_seconds_bucket{application="settlement-sample-app",uri="/api/settlement/process"}[2m])) by (le))
        threshold: "0.2"         # scale up when p95 > 200ms
        activationThreshold: "0.05"
```

#### Scale on Kafka Consumer Lag

For Kafka-consuming services:

```yaml
apiVersion: keda.sh/v1alpha1
kind: ScaledObject
metadata:
  name: settlement-kafka-scaledobject
spec:
  scaleTargetRef:
    name: settlement-consumer-service
  minReplicaCount: 1
  maxReplicaCount: 10            # max = number of Kafka partitions
  pollingInterval: 10
  cooldownPeriod: 300
  triggers:
    - type: kafka
      metadata:
        bootstrapServers: kafka-broker:9092
        consumerGroup: settlement-consumer-group
        topic: settlement.incoming.v1
        lagThreshold: "1000"      # scale up when lag > 1000 messages
        activationLagThreshold: "100"
```

#### Combined Scaling (Recommended)

Use multiple triggers for robust autoscaling:

```yaml
apiVersion: keda.sh/v1alpha1
kind: ScaledObject
metadata:
  name: settlement-combined-scaledobject
spec:
  scaleTargetRef:
    name: settlement-service
  minReplicaCount: 2
  maxReplicaCount: 8
  pollingInterval: 15
  cooldownPeriod: 300
  advanced:
    horizontalPodAutoscalerConfig:
      behavior:
        scaleUp:
          stabilizationWindowSeconds: 30
          policies:
            - type: Pods
              value: 2
              periodSeconds: 60
        scaleDown:
          stabilizationWindowSeconds: 300
          policies:
            - type: Pods
              value: 1
              periodSeconds: 120
  triggers:
    # Primary: Scale on TPS per pod
    - type: prometheus
      metadata:
        serverAddress: http://prometheus.monitoring.svc:9090
        metricName: settlement_rps
        query: |
          sum(rate(http_server_requests_seconds_count{application="settlement-sample-app",uri="/api/settlement/process"}[2m]))
        threshold: "20"
    # Safety: Scale on latency
    - type: prometheus
      metadata:
        serverAddress: http://prometheus.monitoring.svc:9090
        metricName: settlement_p95
        query: |
          histogram_quantile(0.95, sum(rate(http_server_requests_seconds_bucket{application="settlement-sample-app",uri="/api/settlement/process"}[2m])) by (le))
        threshold: "0.2"
    # Fallback: CPU-based
    - type: cpu
      metricType: Utilization
      metadata:
        value: "70"
```

### 11.5 Decision Flowchart — Which Autoscaling Strategy?

```
Is traffic predictable and constant?
├── YES → Fixed Pods (Strategy 1)
└── NO
    ├── Can you install KEDA in the cluster?
    │   ├── YES
    │   │   ├── Kafka consumer? → KEDA Kafka trigger
    │   │   ├── REST API? → KEDA Prometheus (TPS + latency)
    │   │   └── Both? → KEDA Combined
    │   └── NO → HPA CPU/Memory (Strategy 2)
    └── Downstream systems handle spiky connections?
        ├── YES → Aggressive scale-up (30s window)
        └── NO → Conservative scale-up (60-120s) + connection limits
```

---

## 12. Kubernetes Resource Configuration

### 12.1 Complete Deployment Manifest

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: settlement-service
  labels:
    app: settlement-service
spec:
  replicas: 2
  selector:
    matchLabels:
      app: settlement-service
  template:
    metadata:
      labels:
        app: settlement-service
      annotations:
        prometheus.io/scrape: "true"
        prometheus.io/path: "/actuator/prometheus"
        prometheus.io/port: "8080"
    spec:
      terminationGracePeriodSeconds: 30
      containers:
        - name: settlement-service
          image: settlement-service:latest
          ports:
            - containerPort: 8080
              name: http
          env:
            - name: JAVA_OPTS
              value: >-
                -XX:+UseZGC -XX:+ZGenerational
                -Xms512m -Xmx512m
                -XX:MaxDirectMemorySize=128m
                -XX:+UseContainerSupport
                -XX:+ExitOnOutOfMemoryError
            - name: SPRING_PROFILES_ACTIVE
              value: "prod"
          resources:
            requests:
              cpu: "500m"
              memory: "768Mi"
            limits:
              cpu: "1000m"
              memory: "1Gi"
          livenessProbe:
            httpGet:
              path: /actuator/health/liveness
              port: 8080
            initialDelaySeconds: 15
            periodSeconds: 10
          readinessProbe:
            httpGet:
              path: /actuator/health/readiness
              port: 8080
            initialDelaySeconds: 10
            periodSeconds: 5
          startupProbe:
            httpGet:
              path: /actuator/health/liveness
              port: 8080
            initialDelaySeconds: 5
            periodSeconds: 5
            failureThreshold: 12
          lifecycle:
            preStop:
              exec:
                command: ["sh", "-c", "sleep 5"]   # drain in-flight requests
      topologySpreadConstraints:
        - maxSkew: 1
          topologyKey: topology.kubernetes.io/zone
          whenUnsatisfiable: DoNotSchedule
          labelSelector:
            matchLabels:
              app: settlement-service
```

### 12.2 Pod Disruption Budget

```yaml
apiVersion: policy/v1
kind: PodDisruptionBudget
metadata:
  name: settlement-pdb
spec:
  minAvailable: 1           # always keep at least 1 pod running
  selector:
    matchLabels:
      app: settlement-service
```

---

## 13. Performance Checklist

Use this checklist before every performance test and production deployment:

### Application Level

- [ ] Virtual threads enabled (`spring.threads.virtual.enabled=true`)
- [ ] Connection pools sized per formula (HikariCP, HTTP client)
- [ ] HTTP client uses connection pooling (not default `RestTemplate`)
- [ ] Timeouts configured on all external calls (DB, HTTP, Kafka)
- [ ] Circuit breakers on external dependencies (Resilience4j)
- [ ] Reference data cached where applicable (Caffeine/Redis)
- [ ] Independent I/O operations parallelized
- [ ] Kafka producer batching enabled
- [ ] N+1 query patterns eliminated
- [ ] Database indexes created for query patterns

### JVM Level

- [ ] ZGC enabled (`-XX:+UseZGC -XX:+ZGenerational`)
- [ ] Heap fixed (`-Xms == -Xmx`)
- [ ] Container support enabled (`-XX:+UseContainerSupport`)
- [ ] OOM triggers pod restart (`-XX:+ExitOnOutOfMemoryError`)
- [ ] Heap dump on OOM (`-XX:+HeapDumpOnOutOfMemoryError`)

### Kubernetes Level

- [ ] Resource requests AND limits set (CPU + Memory)
- [ ] Liveness, readiness, and startup probes configured
- [ ] Graceful shutdown (`preStop` hook + `terminationGracePeriodSeconds`)
- [ ] Pod disruption budget defined
- [ ] Topology spread constraints for zone redundancy
- [ ] Prometheus scrape annotations on pods

### Autoscaling Level

- [ ] Autoscaling strategy chosen (Fixed / HPA / KEDA)
- [ ] Min replicas ≥ 2 (high availability)
- [ ] Max replicas bounded (prevent runaway scaling)
- [ ] Scale-up policy: aggressive enough to handle bursts
- [ ] Scale-down policy: conservative (5min stabilization)
- [ ] Downstream systems validated for max connection count

### Observability Level

- [ ] Micrometer + Prometheus metrics exported
- [ ] Custom timer metrics on each processing step
- [ ] Histogram percentiles enabled for SLO tracking
- [ ] Alerts configured for p95 latency, error rate, CPU, pool exhaustion
- [ ] Load test report documented with pod count recommendation

---

## Appendix — Reference Configurations

### A. application.yml — Performance-Optimized

```yaml
server:
  port: 8080
  tomcat:
    threads:
      max: 200
      min-spare: 20
    max-connections: 8192
    accept-count: 100
    connection-timeout: 5000
  shutdown: graceful

spring:
  application:
    name: settlement-sample-app
  threads:
    virtual:
      enabled: true
  lifecycle:
    timeout-per-shutdown-phase: 30s
  datasource:
    hikari:
      maximum-pool-size: 20
      minimum-idle: 5
      idle-timeout: 30000
      connection-timeout: 5000
      max-lifetime: 1800000
      leak-detection-threshold: 10000
  jpa:
    open-in-view: false
    properties:
      hibernate:
        jdbc:
          batch_size: 50
        order_inserts: true
        generate_statistics: false
  cache:
    type: caffeine
    caffeine:
      spec: maximumSize=500,expireAfterWrite=300s

management:
  endpoints:
    web:
      exposure:
        include: health,info,metrics,prometheus
  endpoint:
    health:
      probes:
        enabled: true
      show-details: always
  metrics:
    tags:
      application: ${spring.application.name}
    distribution:
      percentiles-histogram:
        http.server.requests: true
      slo:
        http.server.requests: 50ms,100ms,200ms,500ms

settlement:
  observability:
    service-name: settlement-sample-app
    environment: ${SPRING_PROFILES_ACTIVE:local}
    version: ${APP_VERSION:1.0.0}
```

### B. Dockerfile — Optimized for Spring Boot

```dockerfile
FROM eclipse-temurin:21-jre-alpine AS runtime

RUN addgroup -S app && adduser -S app -G app
WORKDIR /app

COPY target/settlement-sample-app-*.jar app.jar

USER app

EXPOSE 8080

ENTRYPOINT ["java", \
  "-XX:+UseZGC", "-XX:+ZGenerational", \
  "-Xms512m", "-Xmx512m", \
  "-XX:+UseContainerSupport", \
  "-XX:+ExitOnOutOfMemoryError", \
  "-XX:+HeapDumpOnOutOfMemoryError", \
  "-XX:HeapDumpPath=/tmp/heapdump.hprof", \
  "-jar", "app.jar"]
```

### C. Grafana Dashboard Panels (PromQL)

```promql
# Request rate (TPS)
sum(rate(http_server_requests_seconds_count{application="settlement-sample-app"}[2m]))

# p95 latency
histogram_quantile(0.95, sum(rate(http_server_requests_seconds_bucket{application="settlement-sample-app"}[2m])) by (le))

# Error rate
sum(rate(http_server_requests_seconds_count{application="settlement-sample-app",status=~"5.."}[2m]))
/ sum(rate(http_server_requests_seconds_count{application="settlement-sample-app"}[2m]))

# HikariCP active connections
hikaricp_connections_active{application="settlement-sample-app"}

# JVM heap used
jvm_memory_used_bytes{application="settlement-sample-app",area="heap"}

# GC pause time
rate(jvm_gc_pause_seconds_sum{application="settlement-sample-app"}[2m])
```

---

## Summary — Quick Reference

| What | Recommendation |
|---|---|
| **JVM** | Java 21, ZGC, fixed heap, container-aware |
| **Threads** | Virtual threads enabled |
| **HTTP Client** | Connection-pooled, 3s timeout, circuit breaker |
| **DB Pool** | HikariCP 15-20, sized per TPS formula |
| **Kafka** | Batch 16KB, linger 5ms, LZ4 compression |
| **Pod CPU** | 500m request / 1000m limit |
| **Pod Memory** | 768Mi request / 1Gi limit |
| **Min Pods** | 2 (HA) |
| **Max Pods** | 6-8 (based on load test) |
| **Autoscaling** | KEDA Prometheus (TPS + p95 latency) + CPU fallback |
| **Scale-up** | 30s stabilization, +2 pods max |
| **Scale-down** | 300s stabilization, -1 pod at a time |
| **Target p95** | < 200ms |
| **Target error rate** | < 0.1% |

---

## 14. Reference Project — Settlement Observability Kit

This guideline is backed by a fully working reference project. Each concept described above has a concrete implementation you can run, inspect, and extend.

### 14.1 Project Structure

```
settlement-observability-kit/
├── settlement-observability-starter/   # Reusable Spring Boot starter
│   └── src/main/java/com/example/obs/
│       ├── annotation/TimedOperation.java          # @TimedOperation annotation
│       ├── aspect/TimedOperationAspect.java         # AOP aspect — auto-creates Micrometer timers
│       ├── config/ObservabilityAutoConfiguration.java
│       ├── metrics/ObservabilityProperties.java     # Configurable service/env/version tags
│       ├── metrics/ObservabilityTagProvider.java     # Common tag provider
│       └── trace/TraceHelper.java                   # OpenTelemetry span creation helper
│
├── settlement-sample-app/              # Working sample app — DB + HTTP + Kafka simulation
│   └── src/main/java/com/example/settlement/
│       ├── controller/SettlementController.java     # REST API — POST /api/settlement/process
│       ├── service/SettlementService.java           # Orchestrator — calls DB → API → Kafka
│       ├── service/SettlementDbService.java         # DB save with @TimedOperation + OTel span
│       ├── service/RefDataClient.java               # HTTP call with @TimedOperation + OTel span
│       ├── service/SettlementPublisher.java         # Kafka publish with @TimedOperation + OTel span
│       ├── config/RestClientConfig.java             # RestTemplate bean
│       └── domain/                                  # Request/Response/Entity records
│
├── docs/
│   ├── KQL-queries.md                               # KQL queries for Application Insights
│   └── performance-architecture-guideline.md        # ← This document
│
└── load-test/
    └── settlement-load-test.jmx                     # JMeter test plan
```

### 14.2 Where to Find Each Guideline Topic in Code

| Guideline Section | Reference File(s) | What It Demonstrates |
|---|---|---|
| Custom timer metrics | `TimedOperation.java`, `TimedOperationAspect.java` | Annotation-driven Micrometer timers on any method |
| OpenTelemetry tracing | `TraceHelper.java`, `SettlementDbService.java` | Creating spans with attributes for DB/HTTP/Kafka |
| Common metric tags | `ObservabilityTagProvider.java`, `ObservabilityProperties.java` | Service, environment, version tags on all metrics |
| REST API processing flow | `SettlementController.java`, `SettlementService.java` | Sequential DB → HTTP → Kafka with per-step timing |
| DB save with timing | `SettlementDbService.java` | `@TimedOperation` + `TraceHelper.inSpan()` on JPA save |
| HTTP client call with timing | `RefDataClient.java` | `@TimedOperation` on downstream REST call |
| Kafka publish with timing | `SettlementPublisher.java` | `@TimedOperation` on message publish step |
| Prometheus metrics export | `application.yml` | Actuator `/prometheus` endpoint config |
| KQL monitoring queries | `docs/KQL-queries.md` | p95 breakdown, per-pod analysis, trend by version |
| JMeter load test | `load-test/settlement-load-test.jmx` | Pre-built test plan for settlement API |
| Auto-configuration | `ObservabilityAutoConfiguration.java` | Spring Boot starter wiring via `AutoConfiguration.imports` |

### 14.3 Prerequisites

| Tool | Version | Purpose |
|---|---|---|
| Java | 21+ | Runtime (virtual threads, ZGC, StructuredTaskScope) |
| Maven | 3.9+ | Build |
| JMeter | 5.6+ | Load testing (optional) |
| Docker | 24+ | Container builds (optional) |
| kubectl + KEDA | Latest | Kubernetes autoscaling (optional) |

### 14.4 Build the Project

```bash
# Clone the repository
git clone <repository-url>
cd settlement-observability-kit

# Build all modules (starter + sample app)
mvn clean package
```

### 14.5 Run the Sample App Locally

```bash
cd settlement-sample-app
mvn spring-boot:run
```

The app starts on `http://localhost:8080` with an in-memory H2 database — no external dependencies required.

### 14.6 Test the Settlement API

**Process a single settlement:**

```bash
curl -X POST http://localhost:8080/api/settlement/process \
  -H "Content-Type: application/json" \
  -d '{"tradeId":"T-1001","currency":"EUR","amount":1200.55,"counterparty":"CPTY1"}'
```

**Expected response:**

```json
{
  "tradeId": "T-1001",
  "status": "SAVED",
  "message": "Processed with rate 1.0856"
}
```

**Health check:**

```bash
curl http://localhost:8080/api/settlement/healthz
# Returns: OK
```

### 14.7 View Metrics (Prometheus Format)

```bash
curl http://localhost:8080/actuator/prometheus
```

Search for these timer metrics to see per-step latencies:

```
settlement_db_save_seconds_count
settlement_db_save_seconds_sum
settlement_api_refdata_seconds_count
settlement_api_refdata_seconds_sum
settlement_kafka_publish_seconds_count
settlement_kafka_publish_seconds_sum
settlement_total_processing_seconds_count
settlement_total_processing_seconds_sum
settlement_processed_count_total
```

### 14.8 Run the JMeter Load Test

```bash
# GUI mode (for exploring)
jmeter -t load-test/settlement-load-test.jmx

# Headless mode (for actual testing)
jmeter -n -t load-test/settlement-load-test.jmx \
  -l results.jtl \
  -e -o report/
```

**Default test plan:** 10 threads × 20 loops = 200 requests.

**Scale up for capacity testing:** Edit the JMX file or override via properties:

```bash
jmeter -n -t load-test/settlement-load-test.jmx \
  -Jthreads=50 -Jloops=100 -Jrampup=60 \
  -l results.jtl -e -o report/
```

### 14.9 Run with Docker

```bash
# Build the image
cd settlement-sample-app
mvn clean package -DskipTests
docker build -t settlement-sample-app:latest .

# Run with performance JVM flags
docker run -p 8080:8080 \
  -e JAVA_OPTS="-XX:+UseZGC -XX:+ZGenerational -Xms512m -Xmx512m" \
  settlement-sample-app:latest
```

### 14.10 Send Telemetry to Application Insights

**Option A — Azure Monitor Java Agent:**

```bash
java -javaagent:/opt/agents/applicationinsights-agent.jar \
  -jar settlement-sample-app.jar
```

```bash
export APPLICATIONINSIGHTS_CONNECTION_STRING="InstrumentationKey=...;IngestionEndpoint=..."
```

**Option B — OpenTelemetry auto-instrumentation on AKS:**

Use Azure Monitor OpenTelemetry-based instrumentation for Java workloads on AKS, then point to your workspace-based Application Insights resource.

### 14.11 Step-by-Step: Performance Test → Pod Sizing → Autoscaling

Follow this workflow using the reference project:

```
Step 1: Run locally
   mvn spring-boot:run
   curl POST /api/settlement/process  →  verify it works

Step 2: Measure single-pod baseline
   jmeter -n -t load-test/settlement-load-test.jmx -Jthreads=10
   Check: actuator/prometheus  →  note p95 values per step

Step 3: Find per-pod ceiling
   jmeter -n -t load-test/settlement-load-test.jmx -Jthreads=50
   jmeter -n -t load-test/settlement-load-test.jmx -Jthreads=100
   Stop when p95 > 200ms or errors appear → that's your max TPS/pod

Step 4: Calculate pod count
   pods = ceil(peak_tps / per_pod_tps) × 1.3

Step 5: Deploy to Kubernetes
   Apply Deployment manifest (Section 12.1)
   Set replicas = calculated min pods

Step 6: Configure autoscaling
   Choose strategy from Section 11.5 flowchart
   Apply HPA (Section 11.3) or KEDA ScaledObject (Section 11.4)

Step 7: Validate at scale
   Run JMeter against the cluster at peak TPS
   Monitor: pod count scaling, p95 latency, CPU, connection pools
   Use KQL queries (docs/KQL-queries.md) for Azure Monitor analysis

Step 8: Document results
   Fill in Load Test Report Template (Section 9.5)
   Record final pod min/max for production deployment
```
