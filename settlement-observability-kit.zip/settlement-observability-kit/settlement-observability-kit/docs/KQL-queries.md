# KQL queries for p95 DB vs API vs Kafka

> These queries assume your custom metrics are visible in the `AppMetrics` table and that the metric name is stored in `Name`. If your workspace still exposes `customMetrics`, replace `AppMetrics` with `customMetrics` and `Name` with `name`.

## 1) p95 for DB, API, Kafka, and total processing

```kusto
AppMetrics
| where TimeGenerated > ago(1h)
| where Name in ("settlement.db.save", "settlement.api.refdata", "settlement.kafka.publish", "settlement.total.processing")
| extend service = tostring(Properties["service"])
| extend env = tostring(Properties["environment"])
| summarize p95_ms = percentile(Value, 95), avg_ms = avg(Value), samples = count() by Name, service, env, bin(TimeGenerated, 5m)
| order by TimeGenerated asc
```

## 2) Compare percentage share of total time

```kusto
let p = AppMetrics
| where TimeGenerated > ago(1h)
| where Name in ("settlement.db.save", "settlement.api.refdata", "settlement.kafka.publish", "settlement.total.processing")
| summarize p95_ms = percentile(Value, 95) by Name;
let total = toscalar(p | where Name == "settlement.total.processing" | project p95_ms);
p
| extend pct_of_total = round((p95_ms / total) * 100.0, 2)
| order by p95_ms desc
```

## 3) Per-service comparison in a shared Application Insights resource

```kusto
AppMetrics
| where TimeGenerated > ago(24h)
| where Name in ("settlement.db.save", "settlement.api.refdata", "settlement.kafka.publish")
| extend service = tostring(Properties["service"])
| summarize p95_ms = percentile(Value, 95), p99_ms = percentile(Value, 99), avg_ms = avg(Value) by service, Name
| order by service asc, Name asc
```

## 4) Trend by deployment version

```kusto
AppMetrics
| where TimeGenerated > ago(24h)
| where Name == "settlement.total.processing"
| extend version = tostring(Properties["version"])
| summarize p95_ms = percentile(Value, 95), avg_ms = avg(Value) by version, bin(TimeGenerated, 15m)
| order by TimeGenerated asc
```

## 5) Correlate slow processing with pod or instance

```kusto
AppMetrics
| where TimeGenerated > ago(4h)
| where Name in ("settlement.total.processing", "settlement.db.save", "settlement.api.refdata", "settlement.kafka.publish")
| extend pod = tostring(Properties["k8s.pod.name"])
| summarize p95_ms = percentile(Value, 95), max_ms = max(Value), avg_ms = avg(Value) by pod, Name
| order by p95_ms desc
```

## 6) Identify where the increase happened after a load test window

```kusto
let start = datetime(2026-04-13T09:00:00Z);
let end = datetime(2026-04-13T10:00:00Z);
AppMetrics
| where TimeGenerated between (start .. end)
| where Name in ("settlement.db.save", "settlement.api.refdata", "settlement.kafka.publish", "settlement.total.processing")
| summarize p50_ms = percentile(Value, 50), p95_ms = percentile(Value, 95), p99_ms = percentile(Value, 99), avg_ms = avg(Value), samples = count() by Name
| order by p95_ms desc
```

## 7) Join request latency to custom step metrics

```kusto
let requestPerf = AppRequests
| where TimeGenerated > ago(1h)
| where Name has "/api/settlement/process"
| summarize request_p95 = percentile(DurationMs, 95);
let metricPerf = AppMetrics
| where TimeGenerated > ago(1h)
| where Name in ("settlement.db.save", "settlement.api.refdata", "settlement.kafka.publish")
| summarize step_p95 = percentile(Value, 95) by Name;
requestPerf
| extend k = 1
| join kind=inner (metricPerf | extend k = 1) on k
| project Name, request_p95, step_p95
| order by step_p95 desc
```

## 8) Trace-level drill down when spans are flowing

```kusto
AppDependencies
| where TimeGenerated > ago(1h)
| where OperationName has "process"
| summarize p95_ms = percentile(DurationMs, 95), avg_ms = avg(DurationMs), count() by Target, DependencyType
| order by p95_ms desc
```

## 9) JVM pressure alongside your business processing metric

```kusto
AppMetrics
| where TimeGenerated > ago(1h)
| where Name in ("jvm.gc.pause", "jvm.memory.used", "process.cpu.usage", "settlement.total.processing")
| summarize avg_value = avg(Value), p95_value = percentile(Value, 95) by Name, bin(TimeGenerated, 5m)
| order by TimeGenerated asc
```
