package com.example.ops.service;

import com.example.ops.domain.DeploymentStatus;
import com.example.ops.domain.ScaleResult;
import com.example.ops.exception.DeploymentNotFoundException;
import io.fabric8.kubernetes.api.model.apps.Deployment;
import io.fabric8.kubernetes.client.KubernetesClient;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Set;

/**
 * Namespace-scoped deployment control using the fabric8 Kubernetes client.
 *
 * <h3>Stop vs Delete</h3>
 * <p>"Stop" = scale replicas to 0.  The Deployment object remains; Kubernetes
 * gracefully terminates all pods (respecting terminationGracePeriodSeconds).
 * Kafka Streams consumer groups will rebalance off all partitions.
 * Consumer offsets are preserved in Confluent Cloud — resuming is safe.
 *
 * <h3>RBAC requirement</h3>
 * <p>The ServiceAccount running this pod needs:
 * <pre>
 *   rules:
 *   - apiGroups: ["apps"]
 *     resources: ["deployments","deployments/scale"]
 *     verbs: ["get","list","patch","update"]
 * </pre>
 */
@Service
public class PodControlService {

    private static final Logger log = LoggerFactory.getLogger(PodControlService.class);

    /**
     * Deployments that can NEVER be stopped via this API.
     * Add critical infrastructure services here.
     */
    private static final Set<String> PROTECTED_DEPLOYMENTS = Set.of(
            "ops-control-service"  // cannot stop itself
    );

    private final KubernetesClient k8s;
    private final String namespace;
    private final AuditService audit;
    private final Counter stopCounter;
    private final Counter startCounter;

    public PodControlService(KubernetesClient k8s,
                             @Value("${ops.namespace}") String namespace,
                             AuditService audit,
                             MeterRegistry meterRegistry) {
        this.k8s       = k8s;
        this.namespace = namespace;
        this.audit     = audit;
        this.stopCounter  = Counter.builder("ops.deployments.stopped")
                .description("Number of deployment stop operations").register(meterRegistry);
        this.startCounter = Counter.builder("ops.deployments.started")
                .description("Number of deployment start operations").register(meterRegistry);
    }

    // -------------------------------------------------------------------------
    // Stop — scale to 0
    // -------------------------------------------------------------------------

    /**
     * Scales a deployment to 0 replicas (all pods gracefully terminated).
     *
     * @param deployment deployment name in the configured namespace
     * @param user       authenticated username from JWT (for audit)
     * @param reason     mandatory reason text
     * @param sourceIp   caller IP for audit trail
     */
    public ScaleResult stop(String deployment, String user, String reason, String sourceIp) {
        guardProtectedDeployment(deployment);
        guardSettlementWindow();

        int previous = currentReplicas(deployment);

        // Audit written BEFORE the K8s call — record intent even if call fails
        audit.record(user, "STOP", deployment, namespace, previous, 0, reason, sourceIp);

        k8s.apps().deployments()
           .inNamespace(namespace)
           .withName(deployment)
           .scale(0);

        stopCounter.increment();
        log.warn("STOP deployment={} ns={} prev={} by={} reason={}",
                deployment, namespace, previous, user, reason);

        return new ScaleResult(deployment, previous, 0);
    }

    // -------------------------------------------------------------------------
    // Start — scale to N
    // -------------------------------------------------------------------------

    /**
     * Scales a deployment to the requested number of replicas.
     *
     * @param deployment deployment name
     * @param replicas   desired replica count (1–20)
     * @param user       authenticated username from JWT
     * @param reason     mandatory reason text
     * @param sourceIp   caller IP
     */
    public ScaleResult start(String deployment, int replicas,
                             String user, String reason, String sourceIp) {
        int previous = currentReplicas(deployment);

        audit.record(user, "START", deployment, namespace, previous, replicas, reason, sourceIp);

        k8s.apps().deployments()
           .inNamespace(namespace)
           .withName(deployment)
           .scale(replicas);

        startCounter.increment();
        log.warn("START deployment={} ns={} replicas={} prev={} by={} reason={}",
                deployment, namespace, replicas, previous, user, reason);

        return new ScaleResult(deployment, previous, replicas);
    }

    // -------------------------------------------------------------------------
    // Status
    // -------------------------------------------------------------------------

    public DeploymentStatus status(String deployment) {
        Deployment d = fetchDeployment(deployment);
        int desired   = d.getSpec().getReplicas() == null         ? 0 : d.getSpec().getReplicas();
        int ready     = d.getStatus().getReadyReplicas() == null  ? 0 : d.getStatus().getReadyReplicas();
        int available = d.getStatus().getAvailableReplicas() == null ? 0 : d.getStatus().getAvailableReplicas();
        return new DeploymentStatus(deployment, desired, ready, available);
    }

    /** Returns the status of every deployment in the configured namespace. */
    public List<DeploymentStatus> listAll() {
        return k8s.apps().deployments()
                .inNamespace(namespace)
                .list()
                .getItems()
                .stream()
                .map(d -> {
                    String name = d.getMetadata().getName();
                    int desired   = d.getSpec().getReplicas() == null        ? 0 : d.getSpec().getReplicas();
                    int ready     = d.getStatus().getReadyReplicas() == null ? 0 : d.getStatus().getReadyReplicas();
                    int available = d.getStatus().getAvailableReplicas() == null ? 0 : d.getStatus().getAvailableReplicas();
                    return new DeploymentStatus(name, desired, ready, available);
                })
                .toList();
    }

    // -------------------------------------------------------------------------
    // Private helpers
    // -------------------------------------------------------------------------

    private Deployment fetchDeployment(String name) {
        Deployment d = k8s.apps().deployments().inNamespace(namespace).withName(name).get();
        if (d == null) throw new DeploymentNotFoundException(name, namespace);
        return d;
    }

    private int currentReplicas(String deployment) {
        Deployment d = fetchDeployment(deployment);
        return d.getSpec().getReplicas() == null ? 0 : d.getSpec().getReplicas();
    }

    private void guardProtectedDeployment(String deployment) {
        if (PROTECTED_DEPLOYMENTS.contains(deployment)) {
            throw new IllegalArgumentException(
                    "Deployment '" + deployment + "' is protected and cannot be stopped via this API.");
        }
    }

    /**
     * Blocks STOP operations during the settlement processing window (14:00–16:00 UTC).
     * Adjust window to match your production settlement cut-off times.
     */
    private void guardSettlementWindow() {
        LocalTime now = ZonedDateTime.now(ZoneId.of("UTC")).toLocalTime();
        if (!now.isBefore(LocalTime.of(14, 0)) && now.isBefore(LocalTime.of(16, 0))) {
            throw new IllegalStateException(
                    "STOP is blocked during the settlement processing window (14:00–16:00 UTC). "
                    + "Contact the settlement support lead to override.");
        }
    }
}
