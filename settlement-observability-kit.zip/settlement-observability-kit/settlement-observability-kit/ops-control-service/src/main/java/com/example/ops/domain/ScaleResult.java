package com.example.ops.domain;

/**
 * Result returned after a scale operation (stop or start).
 *
 * @param deployment      name of the Kubernetes Deployment scaled
 * @param previousReplicas replica count before the operation
 * @param newReplicas      replica count after the operation
 */
public record ScaleResult(String deployment, int previousReplicas, int newReplicas) {}
