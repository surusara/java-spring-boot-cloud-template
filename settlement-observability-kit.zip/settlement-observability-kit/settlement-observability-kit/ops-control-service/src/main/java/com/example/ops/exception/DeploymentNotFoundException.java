package com.example.ops.exception;

public class DeploymentNotFoundException extends RuntimeException {

    public DeploymentNotFoundException(String deployment, String namespace) {
        super(String.format("Deployment '%s' not found in namespace '%s'", deployment, namespace));
    }
}
