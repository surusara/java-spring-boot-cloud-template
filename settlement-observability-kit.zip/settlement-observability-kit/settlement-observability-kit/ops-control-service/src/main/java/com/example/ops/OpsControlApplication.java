package com.example.ops;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OpsControlApplication {

    public static void main(String[] args) {
        SpringApplication.run(OpsControlApplication.class, args);
    }
}
