package com.example.ops.domain;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

/**
 * Request body for STOP operations.
 * A mandatory reason is required for audit trail compliance.
 */
public record ActionRequest(
        @NotBlank(message = "reason is mandatory — it appears in the audit log")
        @Size(max = 500, message = "reason must be 500 characters or fewer")
        String reason) {}
