package com.example.ops.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter;
import org.springframework.security.oauth2.server.resource.authentication.JwtGrantedAuthoritiesConverter;
import org.springframework.security.web.SecurityFilterChain;

/**
 * Stateless JWT resource-server security (Entra ID / any OIDC provider).
 *
 * <p>Only members of the {@code SETTLEMENT_OPS_SUPPORT} role (mapped from the
 * JWT {@code roles} claim) may call the /ops/api/** endpoints.
 *
 * <p>Configure the JWT issuer and audience in {@code application.yml}:
 * <pre>
 *   spring.security.oauth2.resourceserver.jwt:
 *     issuer-uri: https://login.microsoftonline.com/{tenant-id}/v2.0
 *     audiences: api://{app-id}
 * </pre>
 */
@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .sessionManagement(sm -> sm.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .csrf(csrf -> csrf.disable())
            .authorizeHttpRequests(auth -> auth
                // Actuator health/readiness — no auth required (K8s probes)
                .requestMatchers("/actuator/health/**", "/actuator/info").permitAll()
                // Prometheus scrape — open within the cluster (protect at network level)
                .requestMatchers("/actuator/prometheus").permitAll()
                // All ops API endpoints require authentication; method-level @PreAuthorize
                // enforces SETTLEMENT_OPS_SUPPORT role on individual operations
                .requestMatchers(HttpMethod.GET,  "/ops/api/**").authenticated()
                .requestMatchers(HttpMethod.POST, "/ops/api/**").authenticated()
                .anyRequest().denyAll()
            )
            .oauth2ResourceServer(oauth2 -> oauth2
                .jwt(jwt -> jwt.jwtAuthenticationConverter(jwtAuthConverter()))
            );
        return http.build();
    }

    /**
     * Maps the {@code roles} claim in the Entra ID token to Spring Security
     * granted authorities prefixed with {@code ROLE_}.
     *
     * <p>Example: token claim {@code "roles": ["SETTLEMENT_OPS_SUPPORT"]}
     * becomes authority {@code ROLE_SETTLEMENT_OPS_SUPPORT}, allowing use of
     * {@code @PreAuthorize("hasRole('SETTLEMENT_OPS_SUPPORT')")}.
     */
    @Bean
    public JwtAuthenticationConverter jwtAuthConverter() {
        JwtGrantedAuthoritiesConverter grantedAuthoritiesConverter = new JwtGrantedAuthoritiesConverter();
        grantedAuthoritiesConverter.setAuthoritiesClaimName("roles");
        grantedAuthoritiesConverter.setAuthorityPrefix("ROLE_");

        JwtAuthenticationConverter converter = new JwtAuthenticationConverter();
        converter.setJwtGrantedAuthoritiesConverter(grantedAuthoritiesConverter);
        return converter;
    }
}
