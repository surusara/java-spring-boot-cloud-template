package com.example.ops.controller;

import com.example.ops.domain.*;
import com.example.ops.service.AuditService;
import com.example.ops.service.PodControlService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST API for one-click deployment control and audit history retrieval.
 *
 * <p>All mutating operations require the {@code SETTLEMENT_OPS_SUPPORT} role
 * in the JWT token.  Read-only operations (status, list, audit) require only
 * a valid authenticated token.
 *
 * <h3>React UI integration</h3>
 * <pre>
 *   GET  /ops/api/deployments           → list all deployments + replica state
 *   GET  /ops/api/deployments/{name}    → single deployment status
 *   POST /ops/api/deployments/{name}/stop  (body: { "reason": "..." })
 *   POST /ops/api/deployments/{name}/start (body: { "replicas": 3, "reason": "..." })
 *   GET  /ops/api/audit                 → last 24 h audit log
 *   GET  /ops/api/audit/{name}          → audit history for a specific deployment
 * </pre>
 */
@RestController
@RequestMapping("/ops/api")
public class DeploymentControlController {

    private final PodControlService podControl;
    private final AuditService auditService;

    public DeploymentControlController(PodControlService podControl, AuditService auditService) {
        this.podControl   = podControl;
        this.auditService = auditService;
    }

    // -----------------------------------------------------------------------
    // Status — read only, any authenticated user
    // -----------------------------------------------------------------------

    /** Returns all deployments in the namespace with their current replica counts. */
    @GetMapping("/deployments")
    public List<DeploymentStatus> listAll() {
        return podControl.listAll();
    }

    /** Returns the current status of a single deployment. */
    @GetMapping("/deployments/{name}")
    public DeploymentStatus status(@PathVariable String name) {
        return podControl.status(name);
    }

    // -----------------------------------------------------------------------
    // Stop — requires SETTLEMENT_OPS_SUPPORT role
    // -----------------------------------------------------------------------

    /**
     * Scales the deployment to 0 replicas (graceful pod termination).
     * Blocked during the settlement processing window (14:00–16:00 UTC).
     */
    @PostMapping("/deployments/{name}/stop")
    @PreAuthorize("hasRole('SETTLEMENT_OPS_SUPPORT')")
    public ResponseEntity<ScaleResult> stop(
            @PathVariable String name,
            @Valid @RequestBody ActionRequest request,
            @AuthenticationPrincipal Jwt jwt,
            HttpServletRequest httpRequest) {

        ScaleResult result = podControl.stop(
                name,
                resolveUsername(jwt),
                request.reason(),
                httpRequest.getRemoteAddr());

        return ResponseEntity.ok(result);
    }

    // -----------------------------------------------------------------------
    // Start — requires SETTLEMENT_OPS_SUPPORT role
    // -----------------------------------------------------------------------

    /**
     * Scales the deployment to the requested number of replicas.
     * Caller must explicitly specify replica count to prevent accidental over-provisioning.
     */
    @PostMapping("/deployments/{name}/start")
    @PreAuthorize("hasRole('SETTLEMENT_OPS_SUPPORT')")
    public ResponseEntity<ScaleResult> start(
            @PathVariable String name,
            @Valid @RequestBody StartRequest request,
            @AuthenticationPrincipal Jwt jwt,
            HttpServletRequest httpRequest) {

        ScaleResult result = podControl.start(
                name,
                request.replicas(),
                resolveUsername(jwt),
                request.reason(),
                httpRequest.getRemoteAddr());

        return ResponseEntity.ok(result);
    }

    // -----------------------------------------------------------------------
    // Audit — read only
    // -----------------------------------------------------------------------

    /** Returns all pod-control actions performed in the last 24 hours. */
    @GetMapping("/audit")
    public List<AuditEntry> recentAudit() {
        return auditService.recentActions();
    }

    /** Returns the last 50 actions performed on a specific deployment. */
    @GetMapping("/audit/{name}")
    public List<AuditEntry> auditForDeployment(@PathVariable String name) {
        return auditService.auditFor(name);
    }

    // -----------------------------------------------------------------------
    // Private helpers
    // -----------------------------------------------------------------------

    /** Extracts the human-readable username from the JWT — prefers upn, then email, then sub. */
    private String resolveUsername(Jwt jwt) {
        if (jwt.getClaim("upn") != null)               return jwt.getClaim("upn");
        if (jwt.getClaim("preferred_username") != null) return jwt.getClaim("preferred_username");
        if (jwt.getClaim("email") != null)              return jwt.getClaim("email");
        return jwt.getSubject();
    }
}
