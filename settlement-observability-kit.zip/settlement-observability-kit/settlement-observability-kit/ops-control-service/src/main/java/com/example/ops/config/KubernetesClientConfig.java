package com.example.ops.config;

import io.fabric8.kubernetes.client.KubernetesClient;
import io.fabric8.kubernetes.client.KubernetesClientBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Provides the fabric8 Kubernetes client bean.
 *
 * <p>When running inside the cluster (Kubernetes pod), the client auto-discovers
 * credentials via the mounted ServiceAccount token at
 * {@code /var/run/secrets/kubernetes.io/serviceaccount/}.
 *
 * <p>When running locally (developer workstation), it falls back to the
 * {@code ~/.kube/config} file.  Set {@code KUBECONFIG} env var to override.
 */
@Configuration
public class KubernetesClientConfig {

    @Bean
    public KubernetesClient kubernetesClient() {
        return new KubernetesClientBuilder().build();
    }
}
