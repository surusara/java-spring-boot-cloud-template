package com.example.ops.service;

import com.example.ops.domain.AuditEntry;
import com.example.ops.domain.AuditEntryRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;

/**
 * Persists every pod-control action for compliance and post-incident review.
 * Writes synchronously before any Kubernetes call so the record exists even
 * if the K8s API call subsequently fails.
 */
@Service
public class AuditService {

    private static final Logger log = LoggerFactory.getLogger(AuditService.class);

    private final AuditEntryRepository repository;

    public AuditService(AuditEntryRepository repository) {
        this.repository = repository;
    }

    @Transactional
    public AuditEntry record(String performedBy, String action, String targetResource,
                             String namespace, Integer previousReplicas, Integer newReplicas,
                             String reason, String sourceIp) {
        AuditEntry entry = new AuditEntry(
                performedBy, action, targetResource, namespace,
                previousReplicas, newReplicas, reason, sourceIp);
        AuditEntry saved = repository.save(entry);
        log.info("AUDIT action={} deployment={} ns={} prev={} new={} by={} reason={}",
                action, targetResource, namespace, previousReplicas, newReplicas,
                performedBy, reason);
        return saved;
    }

    public List<AuditEntry> recentActions() {
        return repository.findRecentActions(Instant.now().minusSeconds(86_400)); // last 24h
    }

    public List<AuditEntry> auditFor(String deployment) {
        return repository.findTop50ByTargetResourceOrderByActionTimestampDesc(deployment);
    }
}
