package com.example.ops.domain;

/**
 * Current readiness snapshot of a Kubernetes Deployment.
 *
 * @param deployment       deployment name
 * @param desiredReplicas  spec.replicas (could be 0 = stopped)
 * @param readyReplicas    status.readyReplicas
 * @param availableReplicas status.availableReplicas
 */
public record DeploymentStatus(
        String deployment,
        int desiredReplicas,
        int readyReplicas,
        int availableReplicas) {

    /** Returns true when all desired pods are ready (i.e. not mid-startup). */
    public boolean isFullyReady() {
        return desiredReplicas > 0 && readyReplicas >= desiredReplicas;
    }

    /** Returns true when the deployment has been scaled to zero (stopped). */
    public boolean isStopped() {
        return desiredReplicas == 0;
    }
}
