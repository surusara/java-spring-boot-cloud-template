package com.example.ops.domain;

import jakarta.validation.constraints.*;

/**
 * Request body for START operations.
 * Caller must specify the desired replica count (prevents accidental runaway).
 */
public record StartRequest(
        @Min(value = 1,  message = "replicas must be at least 1")
        @Max(value = 20, message = "replicas must not exceed 20 — raise limit with the platform team if needed")
        int replicas,

        @NotBlank(message = "reason is mandatory — it appears in the audit log")
        @Size(max = 500, message = "reason must be 500 characters or fewer")
        String reason) {}
