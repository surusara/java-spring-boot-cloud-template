package com.example.ops.domain;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.Instant;
import java.util.List;

public interface AuditEntryRepository extends JpaRepository<AuditEntry, Long> {

    List<AuditEntry> findTop50ByTargetResourceOrderByActionTimestampDesc(String targetResource);

    @Query("SELECT a FROM AuditEntry a WHERE a.actionTimestamp >= :from ORDER BY a.actionTimestamp DESC")
    List<AuditEntry> findRecentActions(@Param("from") Instant from);
}
