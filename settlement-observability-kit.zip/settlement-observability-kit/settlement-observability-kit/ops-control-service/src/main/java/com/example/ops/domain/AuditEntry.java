package com.example.ops.domain;

import jakarta.persistence.*;
import java.time.Instant;

/**
 * Persisted audit record for every pod-control action.
 * Retained for compliance traceability (who stopped/started what and why).
 */
@Entity
@Table(name = "ops_audit_log",
       indexes = {
           @Index(name = "idx_audit_user",      columnList = "performed_by"),
           @Index(name = "idx_audit_resource",  columnList = "target_resource"),
           @Index(name = "idx_audit_timestamp", columnList = "action_timestamp")
       })
public class AuditEntry {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "performed_by",  nullable = false, length = 120)
    private String performedBy;

    @Column(name = "action",        nullable = false, length = 32)
    private String action;          // STOP | START | STATUS_CHECK

    @Column(name = "target_resource", nullable = false, length = 128)
    private String targetResource;  // deployment name

    @Column(name = "namespace", length = 64)
    private String namespace;

    @Column(name = "previous_replicas")
    private Integer previousReplicas;

    @Column(name = "new_replicas")
    private Integer newReplicas;

    @Column(name = "reason", length = 512)
    private String reason;

    @Column(name = "action_timestamp", nullable = false)
    private Instant actionTimestamp;

    @Column(name = "source_ip", length = 64)
    private String sourceIp;

    protected AuditEntry() {}

    public AuditEntry(String performedBy, String action, String targetResource,
                      String namespace, Integer previousReplicas, Integer newReplicas,
                      String reason, String sourceIp) {
        this.performedBy     = performedBy;
        this.action          = action;
        this.targetResource  = targetResource;
        this.namespace       = namespace;
        this.previousReplicas = previousReplicas;
        this.newReplicas     = newReplicas;
        this.reason          = reason;
        this.actionTimestamp = Instant.now();
        this.sourceIp        = sourceIp;
    }

    public Long getId()               { return id; }
    public String getPerformedBy()    { return performedBy; }
    public String getAction()         { return action; }
    public String getTargetResource() { return targetResource; }
    public String getNamespace()      { return namespace; }
    public Integer getPreviousReplicas() { return previousReplicas; }
    public Integer getNewReplicas()   { return newReplicas; }
    public String getReason()         { return reason; }
    public Instant getActionTimestamp() { return actionTimestamp; }
    public String getSourceIp()       { return sourceIp; }
}
