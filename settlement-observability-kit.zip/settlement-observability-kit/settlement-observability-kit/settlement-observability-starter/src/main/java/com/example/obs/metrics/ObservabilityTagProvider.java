package com.example.obs.metrics;

import io.micrometer.core.instrument.Tags;
import org.springframework.stereotype.Component;

@Component
public class ObservabilityTagProvider {
    private final ObservabilityProperties properties;

    public ObservabilityTagProvider(ObservabilityProperties properties) {
        this.properties = properties;
    }

    public Tags commonTags() {
        return Tags.of(
                "service", properties.getServiceName(),
                "environment", properties.getEnvironment(),
                "version", properties.getVersion()
        );
    }
}
