package com.example.obs.aspect;

import com.example.obs.annotation.TimedOperation;
import com.example.obs.metrics.ObservabilityTagProvider;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;

import java.util.concurrent.TimeUnit;

@Aspect
public class TimedOperationAspect {
    private final MeterRegistry meterRegistry;
    private final ObservabilityTagProvider tagProvider;

    public TimedOperationAspect(MeterRegistry meterRegistry, ObservabilityTagProvider tagProvider) {
        this.meterRegistry = meterRegistry;
        this.tagProvider = tagProvider;
    }

    @Around("@annotation(timedOperation)")
    public Object timeOperation(ProceedingJoinPoint pjp, TimedOperation timedOperation) throws Throwable {
        long start = System.nanoTime();
        try {
            return pjp.proceed();
        } finally {
            long durationNanos = System.nanoTime() - start;
            Timer.builder(timedOperation.value())
                    .description("Timed operation for settlement observability")
                    .tags(tagProvider.commonTags())
                    .tag("component", timedOperation.component())
                    .tag("operation", timedOperation.operation())
                    .tag("class", pjp.getSignature().getDeclaringTypeName())
                    .tag("method", pjp.getSignature().getName())
                    .register(meterRegistry)
                    .record(durationNanos, TimeUnit.NANOSECONDS);
        }
    }
}
