package com.example.obs.trace;

import io.opentelemetry.api.GlobalOpenTelemetry;
import io.opentelemetry.api.trace.Span;
import io.opentelemetry.api.trace.SpanKind;
import io.opentelemetry.api.trace.StatusCode;
import io.opentelemetry.api.trace.Tracer;
import io.opentelemetry.context.Scope;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.Callable;

@Component
public class TraceHelper {
    private final Tracer tracer = GlobalOpenTelemetry.getTracer("settlement-observability-starter");

    public <T> T inSpan(String name, SpanKind kind, Map<String, String> attributes, Callable<T> action) {
        Span span = tracer.spanBuilder(name).setSpanKind(kind).startSpan();
        try (Scope ignored = span.makeCurrent()) {
            attributes.forEach(span::setAttribute);
            T result = action.call();
            span.setStatus(StatusCode.OK);
            return result;
        } catch (Exception e) {
            span.recordException(e);
            span.setStatus(StatusCode.ERROR, e.getMessage());
            throw new RuntimeException(e);
        } finally {
            span.end();
        }
    }

    public void inSpan(String name, SpanKind kind, Map<String, String> attributes, Runnable action) {
        inSpan(name, kind, attributes, () -> {
            action.run();
            return null;
        });
    }
}
