package com.example.obs.annotation;

import java.lang.annotation.*;

@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface TimedOperation {
    String value();
    String component();
    String operation();
}
