package com.example.obs.config;

import com.example.obs.aspect.TimedOperationAspect;
import com.example.obs.metrics.ObservabilityProperties;
import com.example.obs.metrics.ObservabilityTagProvider;
import org.springframework.boot.actuate.autoconfigure.metrics.MeterRegistryCustomizer;
import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;

@AutoConfiguration
@ConditionalOnClass(MeterRegistry.class)
@EnableConfigurationProperties(ObservabilityProperties.class)
public class ObservabilityAutoConfiguration {

    @Bean
    public TimedOperationAspect timedOperationAspect(MeterRegistry meterRegistry,
                                                     ObservabilityTagProvider tagProvider) {
        return new TimedOperationAspect(meterRegistry, tagProvider);
    }

    @Bean
    public MeterRegistryCustomizer<MeterRegistry> metricsCommonTags(ObservabilityProperties props) {
        return registry -> registry.config().commonTags(
                "service", props.getServiceName(),
                "environment", props.getEnvironment(),
                "version", props.getVersion()
        );
    }
}
