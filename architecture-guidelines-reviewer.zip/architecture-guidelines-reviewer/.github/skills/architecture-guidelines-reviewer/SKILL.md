# Architecture Guidelines Reviewer SKILL

Structured reference documentation for multi-pack architecture compliance guidelines.

## Overview

This SKILL provides comprehensive architecture guidelines organized by domain:

- **Service-to-Service Security** (s2s) — SPIFFE/Istio/AuthorizationPolicy patterns
- **Kafka Streams Configuration** (kafka-streams-config) — Configuration, lifecycle, and deployment patterns

Each rule pack includes detailed rationale, compliance checks, and remediation guidance.

## Rule Packs Reference

### Service-to-Service Security (s2s)

Located in: [docs/service-to-service.md](./docs/service-to-service.md)

Covers Istio/SPIFFE patterns:
- AuthorizationPolicy configuration and principal binding
- PeerAuthentication mutual TLS enforcement
- Principal naming conventions and trust boundaries
- Swagger/API discovery in service mesh environments

**Typical use:** Architecture validation for microservices mesh deployments, zero-trust enforcement.

### Kafka Streams Configuration (kafka-streams-config)

Located in: [docs/kafka-streams-config.md](./docs/kafka-streams-config.md)

Covers production Kafka Streams patterns:
- KafkaAutoConfiguration exclusion (manual topology control)
- @EnableKafkaStreams ban (explicit builder pattern)
- Explicit `application-id` and thread count configuration
- Static membership (group-instance-id + internal-leave-group-on-close)
- Isolation level (read_committed for transactional safety)

**Typical use:** Production deployment checklist, configuration code review, performance tuning validation.

## How to Use This SKILL

### In Copilot Prompts

Reference specific rule packs in your code review or architecture validation prompts:

```
Review this Kafka Streams configuration against the kafka-streams-config rules.
Specifically check for [KSTREAM-03] explicit application-id, [KSTREAM-04] thread count,
and [KSTREAM-06] isolation level.
```

```
Validate this Istio AuthorizationPolicy against the s2s security rules.
Check for proper principal binding and mTLS enforcement per [S2S-01] and [S2S-02].
```

### Rule ID Reference

Each rule has a unique ID:

**s2s rules:**
- S2S-01: AuthorizationPolicy configuration
- S2S-02: PeerAuthentication mTLS enforcement
- S2S-03: SPIFFE principal naming
- S2S-04: Trust boundary isolation
- S2S-05: Service identity requirements
- S2S-06: Swagger/API discovery in mesh
- S2S-07: Policy validation and auditing

**kafka-streams-config rules:**
- KSTREAM-01: KafkaAutoConfiguration exclusion
- KSTREAM-02: @EnableKafkaStreams ban
- KSTREAM-03: Explicit application-id
- KSTREAM-04: num-stream-threads configuration (KEDA model)
- KSTREAM-05: Static membership (group-instance-id)
- KSTREAM-06: Isolation level (read_committed)

### Documentation Files

All rule definitions, rationale, and examples are in the `docs/` folder:

- `docs/service-to-service.md` — Full S2S rule pack reference
- `docs/kafka-streams-config.md` — Full Kafka Streams rule pack reference

Read these when:
- Onboarding new team members to architecture standards
- Reviewing complex compliance questions
- Designing new services or data pipelines
- Validating configuration in code review

## Integration with MCP Tools

For **programmatic** validation (automatic scanning, CI/CD integration, agent-driven checks), use the MCP agent:

```
@Architecture Guidelines Reviewer

validate_project at F:/dev/my-service-repo
```

This SKILL is the **documentation reference**; the MCP agent is the **automation interface**.

## Adding New Rule Packs

To add a new architecture domain:

1. Create `guidelines/<domain>-rules.js` in the MCP server
2. Create `docs/<domain>.md` reference documentation
3. Export pack metadata and rules from `guidelines/index.js`
4. Add reference section in this SKILL.md
5. Both documentation and automation are now available

## Feedback and Contributions

Questions about specific rules? See the `docs/` reference files for detailed rationale and examples.

Want to propose new rules? Create a new rule pack following the existing pattern in `guidelines/`.
