---
title: Kafka Streams Configuration Standard
description: Bundled reference for Kafka Streams configuration rules covering Spring Boot manual configuration, consumer-group identity, and rebalance-safety settings.
author: GitHub Copilot
ms.date: 2026-06-19
ms.topic: reference
keywords:
  - kafka streams
  - spring boot
  - consumer config
  - keda
estimated_reading_time: 4
---

## Scope

This bundled standard captures the Kafka Streams configuration rule pack derived from the source architecture notes for the Spring Boot cloud template.

It focuses on safe manual Kafka Streams configuration in Spring Boot services that run on Kubernetes with KEDA-driven horizontal scaling.

## Core Expectations

* Spring Boot should exclude `KafkaAutoConfiguration` when Kafka Streams is configured manually
* Manual Kafka Streams configuration should not use `@EnableKafkaStreams`
* `app.stream.application-id` should be configured explicitly
* `app.stream.num-stream-threads` should stay at `1` for the KEDA scaling model
* Static membership settings should be present
* Consumer isolation level should be `read_committed`

## Notes

This file is the bundled reference for the current Kafka Streams configuration rules.

The originating design material lives in the broader Java template documentation, but the rule pack points at this local bundled reference so the reviewer project remains self-contained and packageable.
