---
title: Service-to-Service Standard
description: Bundled reference for the first architecture-guideline rule pack covering SPIFFE and Istio mTLS service-to-service controls.
author: GitHub Copilot
ms.date: 2026-06-19
ms.topic: reference
keywords:
  - spiffe
  - istio
  - mtls
  - authorizationpolicy
estimated_reading_time: 4
---

## Scope

This bundled standard captures the first rule family implemented by the reviewer project.

It focuses on service-to-service security controls for Kubernetes workloads using Istio and SPIFFE-style identities.

## Core Expectations

* AuthorizationPolicy should be deny-by-default using `action: ALLOW`
* Business traffic on port `8080` must be protected
* Management traffic on port `9090` must remain reachable for probes and metrics
* PeerAuthentication should enforce `STRICT` mTLS
* STRICT mTLS needs a carve-out for management traffic on port `9090`
* ServiceAccount resources should exist so SPIFFE identities are stable
* Swagger should be disabled in higher environments
* Allow-list principals should follow the SPIFFE identity format

## Notes

This file is the bundled reference for the current S2S rules.

As the project grows, add more standard documents under `docs/` and keep each rule family pointing at its local bundled reference instead of an unrelated sample project.