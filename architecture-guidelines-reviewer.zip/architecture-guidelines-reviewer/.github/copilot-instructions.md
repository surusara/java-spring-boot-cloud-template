# Architecture Guidelines Copilot Instructions

This repository provides architecture guidelines through both MCP tools and reusable SKILL files.

## Using the Architecture Guidelines SKILL

The `architecture-guidelines-reviewer` SKILL provides structured reference documentation for architectural compliance patterns. Use this SKILL to:

- Reference rule definitions and compliance requirements in your prompts
- Ground code review and architecture validation in established guidelines
- Build prompts that enforce multi-pack rule standards (Service-to-Service security, Kafka Streams configuration, etc.)

## Architecture Guidelines SKILL Reference

For detailed SKILL documentation including all available rule packs and how to apply them, see:
- [Architecture Guidelines SKILL](../.github/skills/architecture-guidelines-reviewer/SKILL.md)

## Using the MCP Tools

When you need programmatic rule checking, validation, or interactive guidance, use the MCP agent:

- **Agent**: `Architecture Guidelines Reviewer` — runs rule validation, lists available rules, explains rule rationale
- **Tools**: 
  - `architecture-guidelines/list_rules` — list all rules or rules for a specific pack
  - `architecture-guidelines/explain_rule` — get detailed explanation of a specific rule
  - `architecture-guidelines/validate_project` — scan a project and report compliance

## Multi-Pack Architecture

Guidelines are organized by pack to support extensibility:

- **s2s** — Service-to-Service security rules (SPIFFE/Istio)
- **kafka-streams-config** — Kafka Streams configuration compliance
- *(more packs can be added to `guidelines/` folder)*

Each pack is independently versioned and documented.
