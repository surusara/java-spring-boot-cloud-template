---
title: Architecture Guidelines Reviewer
description: Standalone MCP server and agent project for packaging and installing architecture compliance reviews into other repositories.
author: Surendra Jaiswal
ms.date: 2026-06-19
ms.topic: overview
keywords:
  - mcp
  - architecture review
  - vscode
  - copilot
estimated_reading_time: 5
---

## Overview

This project packages the architecture-guidelines reviewer as a reusable unit instead of keeping it inside a learning app.

It contains:

* A standalone MCP server for guideline validation
* A rule-pack registry so multiple standards can coexist cleanly
* A dedicated rules folder that can grow over time
* A project-local agent definition for Copilot
* An install script that copies the reviewer into another repository under `.github`

## Layout

* `src/server.js`: MCP server entry point
* `src/scanner.js`: repository scanning and evaluation helpers
* `guidelines/index.js`: rule-pack registry
* `guidelines/s2s-rules.js`: service-to-service security pack
* `guidelines/kafka-streams-config-rules.js`: Kafka Streams configuration pack
* `.github/agents/architecture-guidelines-reviewer.agent.md`: portable agent definition
* `.github/skills/architecture-guidelines-reviewer/docs/service-to-service.md`: bundled S2S reference
* `.github/skills/architecture-guidelines-reviewer/docs/kafka-streams-config.md`: bundled Kafka Streams configuration reference
* `scripts/install-to-project.mjs`: copies the reviewer into a target repository

## Why Separate It

This keeps the learning project focused on MCP exploration while this project becomes the reusable product surface.

That separation matters because:

* You can add more rule families without dragging in demo UI code
* You can keep each standard in its own pack with its own bundled skill reference doc
* You can package this project for user-machine installation later
* You can copy or publish the reviewer independently of any sample app

## Installation Model

The current install model is repository-local:

1. Copy this reviewer into a target repository under `.github/tools/architecture-guidelines-reviewer`
2. Copy the agent file into the target repository under `.github/agents`
3. Update the user's VS Code MCP config to point at the copied reviewer folder

This works for VS Code today because the MCP server is just a local Node process started from `mcp.json`.

## Quick Start

Install dependencies:

```bash
npm install
```

Run the server locally:

```bash
npm run server
```

Current bundled packs:

* `s2s`: SPIFFE and Istio service-to-service controls
* `kafka-streams-config`: Spring Boot Kafka Streams manual configuration and rebalance-safety checks

Install into another repository:

```bash
node scripts/install-to-project.mjs --target F:/dev/some-repo
```

The installer now updates the VS Code user `mcp.json` automatically.

## Installation Steps

Use this flow when a teammate checks out this repository from Git and wants to install the reviewer into another project.

### Prerequisites

* Node.js 20 or later installed on the user machine
* VS Code with Copilot and MCP support enabled
* A target repository where the reviewer should be installed

### Step 1: Clone This Repository

```bash
git clone <your-git-url>
cd architecture-guidelines-reviewer
```

### Step 2: Install This Project's Dependencies

```bash
npm install
```

This installs the dependencies needed to run the installer.

### Step 3: Run the One-Click Installer

Run the installer and point it at the repository that should receive the reviewer.

Either form works:

```bash
node scripts/install-to-project.mjs --target F:/dev/some-repo
```

```bash
node scripts/install-to-project.mjs --target "F:\dev\some-repo"
```

The installer automatically:

1. Copies the reviewer into `.github/tools/architecture-guidelines-reviewer`
2. Copies the agent file into `.github/agents/architecture-guidelines-reviewer.agent.md`
3. Copies the skill bundle into `.github/skills/architecture-guidelines-reviewer`
4. Copies project Copilot instructions into `.github/copilot-instructions.md`
5. Installs Node dependencies inside the copied tool folder
6. Updates the VS Code user MCP config at `%APPDATA%\Code\User\mcp.json`
7. Backs up the existing MCP config when applicable (`%APPDATA%\Code\User\mcp.json.bak`)

The new server entry `architecture-guidelines` is added to or replaces the existing entry in the `servers` object.

### Step 4: Reload VS Code

Reload VS Code so the updated MCP configuration is discovered and the server is started.

### Step 5: Verify the Installation

After reload, you should be able to:

* Use the `Architecture Guidelines Reviewer` agent
* Call `architecture-guidelines/list_rules`
* Call `architecture-guidelines/validate_project` against a target project path

If the server does not start, check:

* Node.js is installed and available on `PATH`
* `%APPDATA%\Code\User\mcp.json` contains the `architecture-guidelines` server entry
* The `cwd` in `mcp.json` points to the copied reviewer folder in the target repository
* `.github/skills/architecture-guidelines-reviewer/SKILL.md` exists in the target repository
* `.github/copilot-instructions.md` exists in the target repository

### Optional: Write to a Different MCP Config for Testing

If you want to test without changing your real VS Code config, you can override the MCP config path:

```bash
node scripts/install-to-project.mjs --target F:/dev/some-repo --mcp-config F:/temp/test-mcp.json
```

## Does Copying Under .github Work

Yes, for VS Code this can work well as a first packaging model.

The main constraints are:

* The user machine still needs Node.js available
* VS Code still needs an MCP config entry pointing to the copied folder
* If you later want IntelliJ support, keep the MCP server portable and avoid editor-specific assumptions in the core logic

## Next Steps

Natural evolution from here:

1. Publish this as an npm package for `npx`-based install
2. Add more rule packs under `guidelines/`
3. Build a VS Code extension that automates the install and config update