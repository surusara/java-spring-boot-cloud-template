import { spawn } from "node:child_process";
import { promises as fs } from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

const args = process.argv.slice(2);

function readArg(name) {
  const prefix = `${name}=`;
  const eqMatch = args.find((arg) => arg.startsWith(prefix));
  if (eqMatch) {
    return eqMatch.slice(prefix.length);
  }

  const spaceIndex = args.indexOf(name);
  if (spaceIndex !== -1 && spaceIndex + 1 < args.length) {
    return args[spaceIndex + 1];
  }

  return null;
}

function printUsage() {
  console.log("Usage: node scripts/install-to-project.mjs --target=<path-to-repo> [--mcp-config=<path-to-mcp.json>]");
}

const targetArg = readArg("--target");
if (!targetArg) {
  printUsage();
  process.exit(1);
}

const mcpConfigArg = readArg("--mcp-config");

const scriptFile = fileURLToPath(import.meta.url);
const sourceRoot = path.resolve(path.dirname(scriptFile), "..");
const targetRoot = path.resolve(targetArg);
const targetGithubRoot = path.join(targetRoot, ".github");
const targetToolRoot = path.join(targetGithubRoot, "tools", "architecture-guidelines-reviewer");
const targetAgentPath = path.join(targetGithubRoot, "agents", "architecture-guidelines-reviewer.agent.md");
const defaultMcpConfigPath = path.join(process.env.APPDATA || path.join(os.homedir(), "AppData", "Roaming"), "Code", "User", "mcp.json");
const mcpConfigPath = path.resolve(mcpConfigArg || defaultMcpConfigPath);

const targetSkillsRoot = path.join(targetGithubRoot, "skills", "architecture-guidelines-reviewer");
const targetCopilotInstructionsPath = path.join(targetGithubRoot, "copilot-instructions.md");

function stripJsonComments(text) {
  let output = "";
  let inString = false;
  let escaped = false;
  let inLineComment = false;
  let inBlockComment = false;

  for (let index = 0; index < text.length; index += 1) {
    const char = text[index];
    const next = text[index + 1];

    if (inLineComment) {
      if (char === "\n") {
        inLineComment = false;
        output += char;
      }
      continue;
    }

    if (inBlockComment) {
      if (char === "*" && next === "/") {
        inBlockComment = false;
        index += 1;
      }
      continue;
    }

    if (inString) {
      output += char;
      if (escaped) {
        escaped = false;
      } else if (char === "\\") {
        escaped = true;
      } else if (char === '"') {
        inString = false;
      }
      continue;
    }

    if (char === '"') {
      inString = true;
      output += char;
      continue;
    }

    if (char === "/" && next === "/") {
      inLineComment = true;
      index += 1;
      continue;
    }

    if (char === "/" && next === "*") {
      inBlockComment = true;
      index += 1;
      continue;
    }

    output += char;
  }

  return output;
}

async function ensureDir(dirPath) {
  await fs.mkdir(dirPath, { recursive: true });
}

async function copyDir(sourceDir, targetDir) {
  await ensureDir(targetDir);
  const entries = await fs.readdir(sourceDir, { withFileTypes: true });

  for (const entry of entries) {
    const sourcePath = path.join(sourceDir, entry.name);
    const targetPath = path.join(targetDir, entry.name);

    if (entry.isDirectory()) {
      await copyDir(sourcePath, targetPath);
      continue;
    }

    if (entry.isFile()) {
      await fs.copyFile(sourcePath, targetPath);
    }
  }
}

async function readJsonFile(filePath) {
  try {
    const raw = await fs.readFile(filePath, "utf8");
    return { exists: true, value: JSON.parse(stripJsonComments(raw)), raw };
  } catch (error) {
    if (error?.code === "ENOENT") {
      return { exists: false, value: {} };
    }
    throw new Error(`Failed to read JSON file at ${filePath}: ${String(error.message || error)}`);
  }
}

async function updateMcpConfig(serverDefinition) {
  await ensureDir(path.dirname(mcpConfigPath));

  const existing = await readJsonFile(mcpConfigPath);
  const mcpConfig = existing.value && typeof existing.value === "object" ? existing.value : {};
  const servers = mcpConfig.servers && typeof mcpConfig.servers === "object" ? mcpConfig.servers : {};

  mcpConfig.servers = {
    ...servers,
    "architecture-guidelines": serverDefinition,
  };

  if (existing.exists) {
    await fs.copyFile(mcpConfigPath, `${mcpConfigPath}.bak`);
  }

  await fs.writeFile(mcpConfigPath, `${JSON.stringify(mcpConfig, null, 2)}\n`, "utf8");
}

async function runCommand(command, commandArgs, cwd) {
  await new Promise((resolve, reject) => {
    const child = spawn(command, commandArgs, {
      cwd,
      stdio: "inherit",
      shell: process.platform === "win32",
    });

    child.on("error", (error) => {
      reject(new Error(`Failed to start ${command}: ${String(error.message || error)}`));
    });

    child.on("exit", (code) => {
      if (code === 0) {
        resolve();
        return;
      }

      reject(new Error(`${command} ${commandArgs.join(" ")} failed with exit code ${code ?? "unknown"}.`));
    });
  });
}

async function main() {
  await ensureDir(path.dirname(targetAgentPath));
  await ensureDir(targetToolRoot);

  await copyDir(path.join(sourceRoot, "src"), path.join(targetToolRoot, "src"));
  await copyDir(path.join(sourceRoot, "guidelines"), path.join(targetToolRoot, "guidelines"));
  await fs.copyFile(path.join(sourceRoot, "package.json"), path.join(targetToolRoot, "package.json"));
  await fs.copyFile(
    path.join(sourceRoot, ".github", "agents", "architecture-guidelines-reviewer.agent.md"),
    targetAgentPath,
  );

  const npmCommand = process.platform === "win32" ? "npm.cmd" : "npm";

  console.log("Copying skills and copilot instructions...");
  await copyDir(path.join(sourceRoot, ".github", "skills", "architecture-guidelines-reviewer"), targetSkillsRoot);
  await fs.copyFile(path.join(sourceRoot, ".github", "copilot-instructions.md"), targetCopilotInstructionsPath);

  console.log(`Installing dependencies in ${targetToolRoot}...`);
  await runCommand(npmCommand, ["install"], targetToolRoot);

  const serverDefinition = {
    type: "stdio",
    command: "node",
    args: ["src/server.js"],
    cwd: targetToolRoot,
  };

  await updateMcpConfig(serverDefinition);

  console.log("Installed architecture-guidelines-reviewer into target repository.");
  console.log(`Target tool root: ${targetToolRoot}`);
  console.log(`Target agent path: ${targetAgentPath}`);
  console.log(`Target skills root: ${targetSkillsRoot}`);
  console.log(`Target copilot instructions: ${targetCopilotInstructionsPath}`);
  console.log(`VS Code MCP config updated: ${mcpConfigPath}`);
  if (!mcpConfigArg) {
    console.log(`Backup written when applicable: ${mcpConfigPath}.bak`);
  }
  console.log("Dependencies installed in the copied tool folder.");
  console.log("\nNext step: reload VS Code so the architecture-guidelines MCP server is picked up.");
}

main().catch((error) => {
  console.error("Install failed:", error);
  process.exit(1);
});