const DOC = ".github/skills/architecture-guidelines-reviewer/docs/kafka-streams-config.md";

function findJavaFiles(ctx, pattern) {
  return ctx.javaFiles.filter((file) => pattern.test(file.text));
}

function findMatchingConfigFiles(ctx, patterns) {
  return ctx.appConfigFiles.filter((file) => patterns.some((pattern) => pattern.test(file.text)));
}

function hasConfigValue(ctx, patterns) {
  return findMatchingConfigFiles(ctx, patterns).length > 0;
}

const rules = [
  {
    id: "KSTREAM-01",
    title: "Spring Boot app must exclude KafkaAutoConfiguration",
    severity: "high",
    doc: DOC,
    rationale:
      "When Kafka Streams is configured manually, leaving KafkaAutoConfiguration enabled can create a phantom second StreamsBuilderFactoryBean and duplicate consumption.",
    fix: "Add `exclude = KafkaAutoConfiguration.class` to the `@SpringBootApplication` declaration for the service entry point.",
    check(ctx) {
      const springApps = findJavaFiles(ctx, /@SpringBootApplication/);
      if (springApps.length === 0) {
        return [{ file: null, message: "No Spring Boot application class found to verify Kafka auto-configuration exclusion." }];
      }

      const protectedApps = springApps.filter((file) => /KafkaAutoConfiguration\.class/.test(file.text));
      if (protectedApps.length > 0) {
        return [];
      }

      return [
        {
          file: springApps[0].path,
          message: "Spring Boot application does not exclude KafkaAutoConfiguration.",
        },
      ];
    },
  },
  {
    id: "KSTREAM-02",
    title: "Manual Kafka Streams setup must not use @EnableKafkaStreams",
    severity: "high",
    doc: DOC,
    rationale:
      "Using @EnableKafkaStreams in a manually configured service can trigger a phantom defaultKafkaStreamsBuilder and a second consumer group.",
    fix: "Remove `@EnableKafkaStreams` and rely on manual `StreamsBuilderFactoryBean` configuration instead.",
    check(ctx) {
      const matches = findJavaFiles(ctx, /@EnableKafkaStreams\b/);
      return matches.map((file) => ({
        file: file.path,
        message: "@EnableKafkaStreams is present in a manually configured Kafka Streams service.",
      }));
    },
  },
  {
    id: "KSTREAM-03",
    title: "Kafka Streams app.stream.application-id must be configured",
    severity: "medium",
    doc: DOC,
    rationale:
      "The application id is the Kafka Streams consumer-group identity and must be explicitly controlled for safe rollout and offset ownership.",
    fix: "Set `app.stream.application-id` in application.yml, application.yaml, or application.properties.",
    check(ctx) {
      const patterns = [
        /app:\s*[\s\S]*?stream:\s*[\s\S]*?application-id:\s*[^\s#]+/m,
        /^app\.stream\.application-id\s*=\s*.+$/m,
      ];

      if (hasConfigValue(ctx, patterns)) {
        return [];
      }

      return [{ file: null, message: "No app.stream.application-id setting was found in application config." }];
    },
  },
  {
    id: "KSTREAM-04",
    title: "Kafka Streams should run with one stream thread per pod",
    severity: "medium",
    doc: DOC,
    rationale:
      "This deployment model expects KEDA to scale pods horizontally. More than one stream thread per pod adds rebalance complexity without the intended scaling benefit.",
    fix: "Set `app.stream.num-stream-threads` to `1` in application config.",
    check(ctx) {
      const validPatterns = [
        /app:\s*[\s\S]*?stream:\s*[\s\S]*?num-stream-threads:\s*1\b/m,
        /^app\.stream\.num-stream-threads\s*=\s*1\s*$/m,
      ];
      const presentPatterns = [
        /app:\s*[\s\S]*?stream:\s*[\s\S]*?num-stream-threads:\s*\d+/m,
        /^app\.stream\.num-stream-threads\s*=\s*\d+\s*$/m,
      ];

      if (hasConfigValue(ctx, validPatterns)) {
        return [];
      }

      const present = findMatchingConfigFiles(ctx, presentPatterns);
      if (present.length === 0) {
        return [{ file: null, message: "No app.stream.num-stream-threads setting was found in application config." }];
      }

      return present.map((file) => ({
        file: file.path,
        message: "app.stream.num-stream-threads is configured but not set to 1.",
      }));
    },
  },
  {
    id: "KSTREAM-05",
    title: "Kafka Streams static membership settings should be present",
    severity: "medium",
    doc: DOC,
    rationale:
      "Static membership plus delayed leave-group behavior reduces disruptive rebalances during KEDA scale events.",
    fix: "Configure `app.stream.group-instance-id` and set `app.stream.internal-leave-group-on-close` to `false` in application config.",
    check(ctx) {
      const groupInstancePatterns = [
        /app:\s*[\s\S]*?stream:\s*[\s\S]*?group-instance-id:\s*\$\{HOSTNAME:[^}]+\}/m,
        /^app\.stream\.group-instance-id\s*=\s*\$\{HOSTNAME:[^}]+\}\s*$/m,
      ];
      const leaveGroupPatterns = [
        /app:\s*[\s\S]*?stream:\s*[\s\S]*?internal-leave-group-on-close:\s*false\b/m,
        /^app\.stream\.internal-leave-group-on-close\s*=\s*false\s*$/m,
      ];

      const violations = [];

      if (!hasConfigValue(ctx, groupInstancePatterns)) {
        violations.push({
          file: null,
          message: "app.stream.group-instance-id is missing or does not use the HOSTNAME-based static membership pattern.",
        });
      }

      if (!hasConfigValue(ctx, leaveGroupPatterns)) {
        violations.push({
          file: null,
          message: "app.stream.internal-leave-group-on-close is missing or not set to false.",
        });
      }

      return violations;
    },
  },
  {
    id: "KSTREAM-06",
    title: "Kafka Streams consumer isolation level should be read_committed",
    severity: "low",
    doc: DOC,
    rationale:
      "Using read_committed prevents the service from consuming aborted transactional writes from upstream producers.",
    fix: "Set `app.stream.consumer.isolation-level` to `read_committed` in application config.",
    check(ctx) {
      const patterns = [
        /app:\s*[\s\S]*?stream:\s*[\s\S]*?consumer:\s*[\s\S]*?isolation-level:\s*read_committed\b/m,
        /^app\.stream\.consumer\.isolation-level\s*=\s*read_committed\s*$/m,
      ];

      if (hasConfigValue(ctx, patterns)) {
        return [];
      }

      return [{ file: null, message: "No app.stream.consumer.isolation-level=read_committed setting was found in application config." }];
    },
  },
];

export const kafkaStreamsConfigRulePack = {
  id: "kafka-streams-config",
  title: "Kafka Streams Configuration",
  description: "Spring Boot Kafka Streams consumer configuration and rebalance-safety checks.",
  doc: DOC,
  rules,
};

export const kafkaStreamsConfigRules = kafkaStreamsConfigRulePack.rules;
