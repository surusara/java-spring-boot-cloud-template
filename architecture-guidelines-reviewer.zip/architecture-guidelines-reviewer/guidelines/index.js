import { kafkaStreamsConfigRulePack } from "./kafka-streams-config-rules.js";
import { s2sRulePack } from "./s2s-rules.js";

export const rulePacks = [s2sRulePack, kafkaStreamsConfigRulePack];

function withPackMetadata(pack) {
  return pack.rules.map((rule) => ({
    ...rule,
    packId: pack.id,
    packTitle: pack.title,
  }));
}

export function getRulesForPack(packId) {
  const packs = packId ? rulePacks.filter((pack) => pack.id === packId) : rulePacks;
  return packs.flatMap(withPackMetadata);
}

export function findRuleById(ruleId) {
  return getRulesForPack().find((rule) => rule.id.toLowerCase() === ruleId.toLowerCase()) || null;
}
