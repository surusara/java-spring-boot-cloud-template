const DOC = ".github/skills/architecture-guidelines-reviewer/docs/service-to-service.md";

function hasKind(yamlFiles, kind) {
  return yamlFiles.filter((file) => new RegExp(`kind:\\s*${kind}\\b`).test(file.text));
}

const rules = [
  {
    id: "S2S-01",
    title: "AuthorizationPolicy must be deny-by-default (action: ALLOW)",
    severity: "high",
    doc: DOC,
    rationale:
      "Deny-by-default means only listed SPIFFE principals can call business APIs. Any unlisted caller is automatically denied.",
    fix: "Add an Istio AuthorizationPolicy with `action: ALLOW` and an explicit `principals` allow-list.",
    check(ctx) {
      const policies = hasKind(ctx.yamlFiles, "AuthorizationPolicy");
      if (policies.length === 0) {
        return [
          {
            file: null,
            message: "No Istio AuthorizationPolicy found in project manifests.",
          },
        ];
      }

      const violations = [];
      for (const file of policies) {
        if (!/action:\s*ALLOW\b/.test(file.text)) {
          violations.push({
            file: file.path,
            message: "AuthorizationPolicy does not use `action: ALLOW` (deny-by-default).",
          });
        }
      }
      return violations;
    },
  },
  {
    id: "S2S-02",
    title: "AuthorizationPolicy must protect port 8080 and not target 9090",
    severity: "high",
    doc: DOC,
    rationale:
      "Business APIs run on 8080 and must be protected. Management port 9090 must stay open so kubelet probes and Prometheus can reach it.",
    fix: 'Scope the policy to `ports: ["8080"]` only. Do not list port 9090.',
    check(ctx) {
      const policies = hasKind(ctx.yamlFiles, "AuthorizationPolicy");
      const violations = [];
      for (const file of policies) {
        if (!/ports:\s*\[?\s*["']?8080["']?/.test(file.text)) {
          violations.push({
            file: file.path,
            message: "AuthorizationPolicy does not protect port 8080.",
          });
        }
        if (/ports:\s*\[[^\]]*9090[^\]]*\]/.test(file.text)) {
          violations.push({
            file: file.path,
            message: "AuthorizationPolicy lists port 9090 (management port must stay unprotected).",
          });
        }
      }
      return violations;
    },
  },
  {
    id: "S2S-03",
    title: "PeerAuthentication should enforce STRICT mTLS",
    severity: "medium",
    doc: DOC,
    rationale:
      "Financial workloads require mTLS with no plaintext. STRICT mode rejects any non-mTLS traffic.",
    fix: "Add a PeerAuthentication resource with `mtls.mode: STRICT` for the namespace.",
    check(ctx) {
      const peers = hasKind(ctx.yamlFiles, "PeerAuthentication");
      if (peers.length === 0) {
        return [{ file: null, message: "No PeerAuthentication resource found." }];
      }
      const anyStrict = peers.some((file) => /mode:\s*STRICT\b/.test(file.text));
      if (!anyStrict) {
        return [{ file: peers[0].path, message: "PeerAuthentication does not use STRICT mTLS mode." }];
      }
      return [];
    },
  },
  {
    id: "S2S-04",
    title: "STRICT mTLS must carve out management port 9090",
    severity: "high",
    doc: DOC,
    rationale:
      "STRICT PeerAuthentication applies to all ports by default, which breaks kubelet HTTP probes on 9090. A port-level exception is required.",
    fix: "Add `portLevelMtls` for port 9090 with `mode: DISABLE` (or PERMISSIVE) in the PeerAuthentication.",
    check(ctx) {
      const peers = hasKind(ctx.yamlFiles, "PeerAuthentication");
      const strict = peers.filter((file) => /mode:\s*STRICT\b/.test(file.text));
      if (strict.length === 0) {
        return [];
      }
      const carveOut = strict.some((file) => /portLevelMtls:/.test(file.text) && /9090:/.test(file.text));
      if (!carveOut) {
        return [
          {
            file: strict[0].path,
            message: "STRICT PeerAuthentication has no portLevelMtls carve-out for port 9090.",
          },
        ];
      }
      return [];
    },
  },
  {
    id: "S2S-05",
    title: "ServiceAccount must be defined for SPIFFE identity",
    severity: "medium",
    doc: DOC,
    rationale: "The ServiceAccount name becomes the SPIFFE identity used in allow-lists.",
    fix: "Define a Kubernetes ServiceAccount and reference it from the Deployment via serviceAccountName.",
    check(ctx) {
      const accounts = hasKind(ctx.yamlFiles, "ServiceAccount");
      if (accounts.length === 0) {
        return [{ file: null, message: "No ServiceAccount resource found." }];
      }
      return [];
    },
  },
  {
    id: "S2S-06",
    title: "Swagger must be disabled in preprod/prod profiles",
    severity: "medium",
    doc: DOC,
    rationale: "Swagger UI on the protected port must be off in preprod and prod for security.",
    fix: "In application.yml, add a preprod/prod profile block setting springdoc api-docs and swagger-ui enabled: false.",
    check(ctx) {
      if (ctx.appConfigFiles.length === 0) {
        return [{ file: null, message: "No application.yml/application.yaml found to verify Swagger profiles." }];
      }
      const violations = [];
      for (const file of ctx.appConfigFiles) {
        const mentionsProdProfile = /on-profile:\s*(preprod|prod)\b/.test(file.text);
        const disablesSpringdoc = /springdoc[\s\S]*?enabled:\s*false/.test(file.text);
        if (mentionsProdProfile && !disablesSpringdoc) {
          violations.push({
            file: file.path,
            message: "preprod/prod profile present but Swagger (springdoc) is not disabled.",
          });
        }
      }
      return violations;
    },
  },
  {
    id: "S2S-07",
    title: "Allow-list principals must use SPIFFE format",
    severity: "low",
    doc: DOC,
    rationale: "Principals must follow cluster.local/ns/{namespace}/sa/{serviceAccount} so Istio can validate identity.",
    fix: "Format each principal as cluster.local/ns/<namespace>/sa/<service-account>.",
    check(ctx) {
      const policies = hasKind(ctx.yamlFiles, "AuthorizationPolicy");
      const violations = [];
      for (const file of policies) {
        const principalLines = file.text
          .split("\n")
          .filter((line) => /cluster\.local|principals|sa\//.test(line))
          .filter((line) => line.includes("cluster.local"));

        for (const line of principalLines) {
          const value = line.replace(/.*?["']([^"']+)["'].*/, "$1");
          if (value.includes("cluster.local") && !/cluster\.local\/ns\/[^/]+\/sa\/[^/"']+/.test(value)) {
            violations.push({
              file: file.path,
              message: `Principal does not match SPIFFE format: ${value.trim()}`,
            });
          }
        }
      }
      return violations;
    },
  },
];

export const s2sRulePack = {
  id: "s2s",
  title: "Service-to-Service Security",
  description: "SPIFFE and Istio mTLS controls for service-to-service traffic.",
  doc: DOC,
  rules,
};

export const s2sRules = s2sRulePack.rules;