import { promises as fs } from "node:fs";
import path from "node:path";

const SKIP_DIRS = new Set([
  "node_modules",
  ".git",
  "target",
  "build",
  "dist",
  ".idea",
  ".vscode",
]);

const YAML_EXTENSIONS = new Set([".yaml", ".yml"]);
const APP_CONFIG_BASENAMES = new Set(["application.yml", "application.yaml", "application.properties"]);
const JAVA_EXTENSIONS = new Set([".java"]);

async function walk(dir, collected) {
  let entries;
  try {
    entries = await fs.readdir(dir, { withFileTypes: true });
  } catch {
    return;
  }

  for (const entry of entries) {
    if (entry.isDirectory()) {
      if (SKIP_DIRS.has(entry.name)) {
        continue;
      }
      await walk(path.join(dir, entry.name), collected);
      continue;
    }

    if (entry.isFile()) {
      collected.push(path.join(dir, entry.name));
    }
  }
}

export async function buildScanContext(projectPath) {
  const absRoot = path.resolve(projectPath);
  const allFiles = [];
  await walk(absRoot, allFiles);

  const yamlFiles = [];
  const appConfigFiles = [];
  const javaFiles = [];

  for (const filePath of allFiles) {
    const ext = path.extname(filePath).toLowerCase();

    let text;
    try {
      text = await fs.readFile(filePath, "utf8");
    } catch {
      continue;
    }

    const rel = path.relative(absRoot, filePath).split(path.sep).join("/");
    const record = { path: rel, text };
    const base = path.basename(filePath).toLowerCase();

    if (YAML_EXTENSIONS.has(ext)) {
      yamlFiles.push(record);
    }

    if (APP_CONFIG_BASENAMES.has(base)) {
      appConfigFiles.push(record);
    }

    if (JAVA_EXTENSIONS.has(ext)) {
      javaFiles.push(record);
    }
  }

  return {
    root: absRoot,
    yamlFiles,
    appConfigFiles,
    javaFiles,
  };
}

export function evaluateRules(rules, ctx) {
  const results = [];
  const severityCounts = { high: 0, medium: 0, low: 0 };

  for (const rule of rules) {
    const violations = rule.check(ctx) || [];
    const passed = violations.length === 0;

    if (!passed) {
      severityCounts[rule.severity] += violations.length;
    }

    results.push({
      id: rule.id,
      packId: rule.packId || null,
      packTitle: rule.packTitle || null,
      title: rule.title,
      severity: rule.severity,
      doc: rule.doc,
      passed,
      violations,
      fix: passed ? null : rule.fix,
    });
  }

  const failedRules = results.filter((result) => !result.passed).length;

  return {
    project: ctx.root,
    scannedYaml: ctx.yamlFiles.length,
    scannedAppConfig: ctx.appConfigFiles.length,
    totalRules: rules.length,
    passedRules: rules.length - failedRules,
    failedRules,
    severityCounts,
    compliant: severityCounts.high === 0,
    results,
  };
}