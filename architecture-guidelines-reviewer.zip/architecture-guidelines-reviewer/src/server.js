#!/usr/bin/env node
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { z } from "zod";

import { findRuleById, getRulesForPack, rulePacks } from "../guidelines/index.js";
import { buildScanContext, evaluateRules } from "./scanner.js";

const server = new McpServer({
  name: "architecture-guidelines-reviewer",
  version: "0.1.0",
});

server.tool(
  "list_rules",
  "List all architecture guideline rules this server can enforce.",
  { packId: z.string().optional() },
  async ({ packId }) => {
    const rules = getRulesForPack(packId);
    const summary = rules.map((rule) => ({
      id: rule.id,
      packId: rule.packId,
      packTitle: rule.packTitle,
      title: rule.title,
      severity: rule.severity,
      doc: rule.doc,
    }));

    return {
      content: [{ type: "text", text: JSON.stringify({ packs: rulePacks, rules: summary }, null, 2) }],
    };
  },
);

server.tool(
  "explain_rule",
  "Explain a single architecture guideline rule by its id.",
  { ruleId: z.string() },
  async ({ ruleId }) => {
    const rule = findRuleById(ruleId);
    if (!rule) {
      return {
        content: [{ type: "text", text: `Rule not found: ${ruleId}` }],
        isError: true,
      };
    }

    return {
      content: [
        {
          type: "text",
          text: JSON.stringify(
            {
              id: rule.id,
              packId: rule.packId,
              packTitle: rule.packTitle,
              title: rule.title,
              severity: rule.severity,
              rationale: rule.rationale,
              fix: rule.fix,
              doc: rule.doc,
            },
            null,
            2,
          ),
        },
      ],
    };
  },
);

server.tool(
  "validate_project",
  "Scan a project folder and validate it against all architecture guideline rules.",
  { projectPath: z.string().optional(), packId: z.string().optional() },
  async ({ projectPath, packId }) => {
    const targetPath = projectPath && projectPath.trim() ? projectPath : process.cwd();
    const ctx = await buildScanContext(targetPath);
    const rules = getRulesForPack(packId);
    const report = evaluateRules(rules, ctx);

    return {
      content: [{ type: "text", text: JSON.stringify({ packId: packId || null, ...report }, null, 2) }],
    };
  },
);

async function main() {
  const transport = new StdioServerTransport();
  await server.connect(transport);
}

main().catch((error) => {
  console.error("Architecture guidelines reviewer server failed to start:", error);
  process.exit(1);
});