package com.trading.processor.consumer;

import com.trading.processor.model.ProcessingResult;
import com.trading.processor.model.TradeMessage;
import com.trading.processor.service.TradeProcessingService;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Component;

import java.time.Instant;

/**
 * Kafka listener for raw trade messages from Confluent Cloud.
 *
 * Threading model:
 *  - Spring creates `concurrency` (10) KafkaConsumer threads per pod.
 *  - Each thread owns a subset of the 20 partitions.
 *  - Processing is synchronous within each thread — one record at a time.
 *  - At 400ms/trade avg and 10 threads → ~25 trades/sec per pod.
 *
 * Offset commit strategy:
 *  - AckMode.RECORD: committed after every record regardless of success/failure.
 *  - Failed records are routed to DLQ BEFORE ack — no partition stall.
 *  - Guarantees at-least-once delivery semantics.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class TradeMessageConsumer {

    private final TradeProcessingService processingService;
    private final MeterRegistry          meterRegistry;

    @Value("${POD_NAME:local}")
    private String podName;

    @KafkaListener(
        topics           = "${kafka.topics.input:trades.raw}",
        groupId          = "${kafka.consumer.group-id:trade-processor-group}",
        containerFactory = "kafkaListenerContainerFactory"
    )
    public void consume(
            ConsumerRecord<String, TradeMessage> record,
            Acknowledgment ack,
            @Header(KafkaHeaders.RECEIVED_PARTITION) int    partition,
            @Header(KafkaHeaders.OFFSET)             long   offset,
            @Header(KafkaHeaders.RECEIVED_TOPIC)     String topic) {

        TradeMessage trade = record.value();
        long startMs = Instant.now().toEpochMilli();

        MDC.put("tradeId",   trade.getTradeId());
        MDC.put("podName",   podName);
        MDC.put("partition", String.valueOf(partition));
        MDC.put("offset",    String.valueOf(offset));

        Timer.Sample timer = Timer.start(meterRegistry);
        try {
            log.info("Consuming | assetClass={} | source={} | side={}",
                     trade.getAssetClass(), trade.getSourceSystem(), trade.getSide());

            ProcessingResult result = processingService.process(
                    trade, offset, partition, topic, startMs);

            if (result.isSuccess()) {
                log.info("Trade processed successfully | latencyMs={}",
                         result.getEnrichedTrade() != null
                             ? result.getEnrichedTrade().getProcessingLatencyMs() : "N/A");
                meterRegistry.counter("trade.consumer.success",
                        "asset_class", trade.getAssetClass().name()).increment();
            } else {
                log.warn("Trade failed | error={} | retryable={}",
                         result.getError(), result.isRetryable());
                meterRegistry.counter("trade.consumer.failure",
                        "reason", result.getError()).increment();
            }

            ack.acknowledge(); // manual commit after DLQ routing is complete

        } catch (Exception ex) {
            log.error("Unhandled exception — escalating to error handler: {}", ex.getMessage(), ex);
            meterRegistry.counter("trade.consumer.error").increment();
            // Re-throw: Spring DefaultErrorHandler applies exponential backoff,
            // then routes to DLQ after max retries are exhausted.
            throw ex;
        } finally {
            timer.stop(meterRegistry.timer("trade.consumer.duration",
                    "partition", String.valueOf(partition)));
            MDC.clear();
        }
    }
}
