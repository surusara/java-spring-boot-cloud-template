package com.trading.processor.service;

import com.trading.processor.model.TradeMessage;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Slf4j
@Service
public class ValidationService {

    /**
     * Validates a raw trade message.
     *
     * @return null if valid, or a human-readable error message if invalid.
     */
    public String validate(TradeMessage trade) {
        if (trade.getTradeId() == null || trade.getTradeId().isBlank()) {
            return "Trade ID is required";
        }
        if (trade.getInstrumentId() == null || trade.getInstrumentId().isBlank()) {
            return "Instrument ID is required";
        }
        if (trade.getAssetClass() == null) {
            return "Asset class is required";
        }
        if (trade.getSide() == null) {
            return "Trade side (BUY/SELL) is required";
        }
        if (trade.getQuantity() == null || trade.getQuantity().signum() <= 0) {
            return "Quantity must be positive";
        }
        if (trade.getPrice() == null || trade.getPrice().signum() <= 0) {
            return "Price must be positive";
        }
        if (trade.getNotional() == null || trade.getNotional().signum() <= 0) {
            return "Notional must be positive";
        }
        if (trade.getCurrency() == null || trade.getCurrency().isBlank()) {
            return "Currency is required";
        }
        if (trade.getTraderId() == null || trade.getTraderId().isBlank()) {
            return "Trader ID is required";
        }
        if (trade.getBookId() == null || trade.getBookId().isBlank()) {
            return "Book ID is required";
        }
        if (trade.getCounterpartyId() == null || trade.getCounterpartyId().isBlank()) {
            return "Counterparty ID is required";
        }
        if (trade.getSourceSystem() == null || trade.getSourceSystem().isBlank()) {
            return "Source system is required";
        }
        if (trade.getTradeDate() == null) {
            return "Trade date is required";
        }
        if (trade.getSettlementDate() == null) {
            return "Settlement date is required";
        }
        return null;
    }
}
