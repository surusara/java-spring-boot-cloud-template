package com.trading.processor.model;

import lombok.Getter;

@Getter
public class ProcessingResult {

    private final String        tradeId;
    private final boolean       success;
    private final boolean       duplicate;
    private final boolean       retryable;
    private final String        error;
    private final EnrichedTrade enrichedTrade;
    private final TradeEvent    event;

    private ProcessingResult(String tradeId, boolean success, boolean duplicate,
                              boolean retryable, String error,
                              EnrichedTrade enrichedTrade, TradeEvent event) {
        this.tradeId       = tradeId;
        this.success       = success;
        this.duplicate     = duplicate;
        this.retryable     = retryable;
        this.error         = error;
        this.enrichedTrade = enrichedTrade;
        this.event         = event;
    }

    public static ProcessingResult success(String tradeId, EnrichedTrade enrichedTrade,
                                           TradeEvent event) {
        return new ProcessingResult(tradeId, true, false, false, null, enrichedTrade, event);
    }

    public static ProcessingResult failure(String tradeId, String error, boolean retryable) {
        return new ProcessingResult(tradeId, false, false, retryable, error, null, null);
    }

    public static ProcessingResult duplicate(String tradeId) {
        return new ProcessingResult(tradeId, false, true, false, "Duplicate trade", null, null);
    }
}
