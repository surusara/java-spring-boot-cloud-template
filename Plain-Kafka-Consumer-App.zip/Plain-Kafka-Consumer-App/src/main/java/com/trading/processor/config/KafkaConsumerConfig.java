package com.trading.processor.config;

import com.trading.processor.model.TradeMessage;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.CooperativeStickyAssignor;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.listener.ContainerProperties;
import org.springframework.kafka.listener.DefaultErrorHandler;
import org.springframework.kafka.support.serializer.ErrorHandlingDeserializer;
import org.springframework.kafka.support.serializer.JsonDeserializer;
import org.springframework.util.backoff.ExponentialBackOff;

import java.util.HashMap;
import java.util.Map;

/**
 * Kafka Consumer Configuration optimised for:
 *  - 5 million trades/day (~58 TPS average, ~1,500 TPS peak)
 *  - 300–500ms processing time per trade (average 400ms)
 *  - Zero stop-the-world rebalances on scale-up/scale-down
 *  - Confluent Cloud SASL_SSL connectivity
 *
 * Key design decisions:
 *
 * 1. CooperativeStickyAssignor
 *    Classic EagerAssignor causes ALL partitions to be revoked and
 *    reassigned on every group change (pod start/stop). With 20 partitions
 *    this means all consumers pausing 10–30s on every KEDA scale event.
 *    CooperativeStickyAssignor does INCREMENTAL rebalancing: only the
 *    partitions that need to move are paused; the rest keep consuming.
 *
 * 2. Static Group Membership (group.instance.id = POD_NAME)
 *    Without this, every pod restart triggers a LEAVE_GROUP + JOIN_GROUP
 *    cycle forcing a full rebalance. With static membership, the broker
 *    keeps the pod's partition assignment alive for session.timeout.ms (45s).
 *    If the pod comes back within 45s (typical rolling update), ZERO rebalance.
 *
 * 3. max.poll.records = 10
 *    With 400ms average processing time and 10 threads, 10 records = 4s batch.
 *    max.poll.interval.ms = 300,000ms gives massive headroom to prevent
 *    "consumer left the group" errors during GC pauses or DB slowness.
 *
 * 4. Concurrency = 10 threads per pod
 *    Each thread owns 1–2 partitions. With 20 Kafka partitions and
 *    KEDA scaling 2→20 pods, at peak each pod owns 1 partition
 *    giving true parallel processing with no contention.
 */
@Slf4j
@Configuration
@EnableKafka
public class KafkaConsumerConfig {

    // Confluent Cloud
    @Value("${kafka.bootstrap-servers}")           private String bootstrapServers;
    @Value("${kafka.security.protocol}")           private String securityProtocol;
    @Value("${kafka.sasl.mechanism}")              private String saslMechanism;
    @Value("${kafka.sasl.jaas-config}")            private String saslJaasConfig;

    // Schema Registry
    @Value("${kafka.schema-registry.url}")         private String schemaRegistryUrl;
    @Value("${kafka.schema-registry.api-key}")     private String schemaRegistryApiKey;
    @Value("${kafka.schema-registry.api-secret}")  private String schemaRegistryApiSecret;

    // Consumer tuning
    @Value("${kafka.consumer.group-id}")                       private String  groupId;
    @Value("${kafka.consumer.auto-offset-reset}")              private String  autoOffsetReset;
    @Value("${kafka.consumer.max-poll-records:10}")            private int     maxPollRecords;
    @Value("${kafka.consumer.max-poll-interval-ms:300000}")    private int     maxPollIntervalMs;
    @Value("${kafka.consumer.session-timeout-ms:45000}")       private int     sessionTimeoutMs;
    @Value("${kafka.consumer.heartbeat-interval-ms:10000}")    private int     heartbeatIntervalMs;
    @Value("${kafka.consumer.fetch-min-bytes:1024}")           private int     fetchMinBytes;
    @Value("${kafka.consumer.fetch-max-wait-ms:500}")          private int     fetchMaxWaitMs;
    @Value("${kafka.consumer.concurrency:10}")                 private int     concurrency;

    /**
     * POD_NAME injected via Kubernetes Downward API.
     * Used as group.instance.id to enable static group membership.
     * Each pod gets a stable, unique identity across restarts.
     */
    @Value("${POD_NAME:trade-processor-default}")
    private String podName;

    @Bean
    public Map<String, Object> consumerConfigs() {
        Map<String, Object> props = new HashMap<>();

        // Confluent Cloud SASL_SSL
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        props.put("security.protocol",  securityProtocol);
        props.put("sasl.mechanism",     saslMechanism);
        props.put("sasl.jaas.config",   saslJaasConfig);

        // Schema Registry auth
        props.put("schema.registry.url",           schemaRegistryUrl);
        props.put("basic.auth.credentials.source", "USER_INFO");
        props.put("basic.auth.user.info",
                  schemaRegistryApiKey + ":" + schemaRegistryApiSecret);

        // Consumer group
        props.put(ConsumerConfig.GROUP_ID_CONFIG,          groupId);
        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, autoOffsetReset);

        // ── REBALANCE PREVENTION #1: Static Group Membership ───────────────
        // The broker retains this pod's partition assignment for session.timeout.ms
        // after it disappears. Rolling restarts complete with ZERO rebalances
        // as long as the pod returns within the session timeout window (45s).
        props.put(ConsumerConfig.GROUP_INSTANCE_ID_CONFIG, podName);

        // ── REBALANCE PREVENTION #2: Cooperative Incremental Rebalancing ───
        // Only partitions being reassigned are briefly paused.
        // Other partitions continue processing without interruption.
        // This is the single most important setting for KEDA scale events.
        props.put(ConsumerConfig.PARTITION_ASSIGNMENT_STRATEGY_CONFIG,
                  CooperativeStickyAssignor.class.getName());

        // Manual offset commit via Spring AckMode.RECORD
        props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false);

        // ── Poll tuning ────────────────────────────────────────────────────
        // max-poll-records × avg-processing-time = 10 × 400ms = 4s per poll.
        // max-poll-interval-ms = 300s → massive headroom before broker
        // treats the consumer as dead and triggers a rebalance.
        props.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG,          maxPollRecords);
        props.put(ConsumerConfig.MAX_POLL_INTERVAL_MS_CONFIG,      maxPollIntervalMs);
        props.put(ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG,        sessionTimeoutMs);
        props.put(ConsumerConfig.HEARTBEAT_INTERVAL_MS_CONFIG,     heartbeatIntervalMs);

        // Fetch tuning
        props.put(ConsumerConfig.FETCH_MIN_BYTES_CONFIG,           fetchMinBytes);
        props.put(ConsumerConfig.FETCH_MAX_WAIT_MS_CONFIG,         fetchMaxWaitMs);
        props.put(ConsumerConfig.MAX_PARTITION_FETCH_BYTES_CONFIG, 1_048_576);

        // Deserializers with error handling wrapper
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,
                  StringDeserializer.class);
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,
                  ErrorHandlingDeserializer.class);
        props.put(ErrorHandlingDeserializer.VALUE_DESERIALIZER_CLASS,
                  JsonDeserializer.class.getName());
        props.put(JsonDeserializer.VALUE_DEFAULT_TYPE,
                  TradeMessage.class.getName());
        props.put(JsonDeserializer.TRUSTED_PACKAGES,
                  "com.trading.processor.model");
        props.put(JsonDeserializer.USE_TYPE_INFO_HEADERS, false);

        log.info("Kafka consumer configured | group={} | instanceId={} | " +
                 "maxPollRecords={} | concurrency={} | assignor=CooperativeSticky",
                 groupId, podName, maxPollRecords, concurrency);
        return props;
    }

    @Bean
    public ConsumerFactory<String, TradeMessage> consumerFactory() {
        return new DefaultKafkaConsumerFactory<>(consumerConfigs());
    }

    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, TradeMessage>
    kafkaListenerContainerFactory(ConsumerFactory<String, TradeMessage> consumerFactory) {

        var factory = new ConcurrentKafkaListenerContainerFactory<String, TradeMessage>();
        factory.setConsumerFactory(consumerFactory);

        // 10 listener threads per pod. At 20 pods peak → 200 threads across cluster,
        // each handling 1 partition from the 20-partition topic with perfect affinity.
        factory.setConcurrency(concurrency);

        // RECORD ack: commit offset immediately after each record.
        // DLQ routing inside the service ensures failed trades never block the partition.
        factory.getContainerProperties().setAckMode(ContainerProperties.AckMode.RECORD);

        // Publish idle event after 30s of no messages (used by liveness probe)
        factory.getContainerProperties().setIdleEventInterval(30_000L);

        // Allow up to 60s for in-flight records to complete on graceful shutdown.
        // Aligned with terminationGracePeriodSeconds: 60 in the Deployment.
        factory.getContainerProperties().setShutdownTimeout(60_000L);

        // ── Error handler: exponential backoff then DLQ ────────────────────
        // Attempts: 1s → 2s → 4s before giving up and routing to DLQ.
        ExponentialBackOff backOff = new ExponentialBackOff(1_000L, 2.0);
        backOff.setMaxAttempts(3);
        backOff.setMaxInterval(10_000L);

        DefaultErrorHandler errorHandler = new DefaultErrorHandler(backOff);
        // These are never worth retrying — skip straight to DLQ
        errorHandler.addNotRetryableExceptions(
            IllegalArgumentException.class,
            com.fasterxml.jackson.core.JsonProcessingException.class,
            jakarta.validation.ValidationException.class
        );
        errorHandler.setCommitRecovered(true); // commit even on DLQ routing
        factory.setCommonErrorHandler(errorHandler);

        return factory;
    }
}
