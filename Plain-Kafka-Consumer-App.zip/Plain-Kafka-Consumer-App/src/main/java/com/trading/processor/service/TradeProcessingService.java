package com.trading.processor.service;

import com.trading.processor.model.EnrichedTrade;
import com.trading.processor.model.ProcessingResult;
import com.trading.processor.model.TradeEvent;
import com.trading.processor.model.TradeMessage;
import com.trading.processor.publisher.TradeEventPublisher;
import com.trading.processor.repository.EnrichedTradeRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class TradeProcessingService {

    private final ValidationService       validationService;
    private final DeduplicationService    deduplicationService;
    private final EnrichedTradeRepository tradeRepository;
    private final TradeEventPublisher     eventPublisher;

    private static final Map<String, BigDecimal> FX_RATES = Map.of(
        "USD", BigDecimal.ONE,
        "EUR", new BigDecimal("1.09"),
        "GBP", new BigDecimal("1.27"),
        "JPY", new BigDecimal("0.0067"),
        "SGD", new BigDecimal("0.74"),
        "HKD", new BigDecimal("0.128"),
        "AUD", new BigDecimal("0.65")
    );

    private static final Map<TradeMessage.AssetClass, Double> RISK_THRESHOLDS = Map.of(
        TradeMessage.AssetClass.EQUITY,       1_000_000.0,
        TradeMessage.AssetClass.FIXED_INCOME, 5_000_000.0,
        TradeMessage.AssetClass.FX,          10_000_000.0,
        TradeMessage.AssetClass.COMMODITY,    2_000_000.0,
        TradeMessage.AssetClass.CRYPTO,         500_000.0,
        TradeMessage.AssetClass.DERIVATIVE,   3_000_000.0
    );

    /** Pipeline: Validate → Deduplicate → Enrich → Persist → Publish */
    @Transactional
    public ProcessingResult process(TradeMessage trade, long kafkaOffset,
                                    int kafkaPartition, String kafkaTopic,
                                    long latencyStartMs) {
        String tradeId = trade.getTradeId();
        try {
            String validationError = validationService.validate(trade);
            if (validationError != null) {
                eventPublisher.publishToDlq(trade, validationError);
                return ProcessingResult.failure(tradeId, validationError, false);
            }
            if (deduplicationService.isDuplicate(tradeId)) {
                return ProcessingResult.duplicate(tradeId);
            }
            EnrichedTrade enriched = enrich(trade, kafkaOffset,
                                            kafkaPartition, kafkaTopic, latencyStartMs);
            EnrichedTrade saved    = tradeRepository.save(enriched);
            deduplicationService.markProcessed(tradeId);
            TradeEvent event = toEvent(saved);
            eventPublisher.publishProcessed(event);
            return ProcessingResult.success(tradeId, saved, event);

        } catch (Exception e) {
            log.error("Processing failed tradeId={}: {}", tradeId, e.getMessage(), e);
            try { eventPublisher.publishToDlq(trade, e.getMessage()); }
            catch (Exception dlqEx) { log.error("DLQ also failed tradeId={}", tradeId, dlqEx); }
            return ProcessingResult.failure(tradeId, e.getMessage(), true);
        }
    }

    private EnrichedTrade enrich(TradeMessage t, long offset, int partition,
                                  String topic, long startMs) {
        BigDecimal notional    = t.getNotional();
        BigDecimal fxRate      = FX_RATES.getOrDefault(t.getCurrency().toUpperCase(), BigDecimal.ONE);
        BigDecimal usdNotional = notional.multiply(fxRate);
        double threshold       = RISK_THRESHOLDS.getOrDefault(t.getAssetClass(), 1_000_000.0);
        double riskScore       = Math.min(usdNotional.doubleValue() / threshold * 100.0, 100.0);
        int latencyMs          = (int)(Instant.now().toEpochMilli() - startMs);

        return EnrichedTrade.builder()
                .tradeId(t.getTradeId())
                .instrumentId(t.getInstrumentId())
                .instrumentName("INSTRUMENT_" + t.getInstrumentId())
                .assetClass(t.getAssetClass())
                .side(t.getSide())
                .quantity(t.getQuantity())
                .price(t.getPrice())
                .notional(notional)
                .currency(t.getCurrency().toUpperCase())
                .usdNotional(usdNotional)
                .fxRate(fxRate)
                .traderId(t.getTraderId())
                .traderName("TRADER_" + t.getTraderId())
                .bookId(t.getBookId())
                .counterpartyId(t.getCounterpartyId())
                .counterpartyName("CP_" + t.getCounterpartyId())
                .tradeDate(t.getTradeDate())
                .settlementDate(t.getSettlementDate())
                .sourceSystem(t.getSourceSystem())
                .status(EnrichedTrade.TradeStatus.PROCESSED)
                .riskScore(riskScore)
                .processingLatencyMs(latencyMs)
                .kafkaOffset(offset)
                .kafkaPartition(partition)
                .kafkaTopic(topic)
                .build();
    }

    private TradeEvent toEvent(EnrichedTrade t) {
        return TradeEvent.builder()
                .tradeId(t.getTradeId())
                .enrichedTradeId(t.getId().toString())
                .status(t.getStatus())
                .assetClass(t.getAssetClass())
                .notional(t.getNotional())
                .currency(t.getCurrency())
                .usdNotional(t.getUsdNotional())
                .riskScore(t.getRiskScore())
                .sourceSystem(t.getSourceSystem())
                .processingLatencyMs(t.getProcessingLatencyMs())
                .build();
    }
}
