package com.trading.processor.config;

import com.trading.processor.model.TradeEvent;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.support.serializer.JsonSerializer;

import java.util.HashMap;
import java.util.Map;

@Configuration
public class KafkaProducerConfig {

    @Value("${kafka.bootstrap-servers}")           private String bootstrapServers;
    @Value("${kafka.security.protocol}")           private String securityProtocol;
    @Value("${kafka.sasl.mechanism}")              private String saslMechanism;
    @Value("${kafka.sasl.jaas-config}")            private String saslJaasConfig;
    @Value("${kafka.schema-registry.url}")         private String schemaRegistryUrl;
    @Value("${kafka.schema-registry.api-key}")     private String schemaRegistryApiKey;
    @Value("${kafka.schema-registry.api-secret}")  private String schemaRegistryApiSecret;
    @Value("${kafka.producer.linger-ms:5}")        private int    lingerMs;
    @Value("${kafka.producer.batch-size:65536}")   private int    batchSize;
    @Value("${kafka.producer.compression-type:lz4}") private String compressionType;

    private Map<String, Object> baseProducerConfigs() {
        Map<String, Object> props = new HashMap<>();
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        props.put("security.protocol",  securityProtocol);
        props.put("sasl.mechanism",     saslMechanism);
        props.put("sasl.jaas.config",   saslJaasConfig);
        props.put("schema.registry.url", schemaRegistryUrl);
        props.put("basic.auth.credentials.source", "USER_INFO");
        props.put("basic.auth.user.info", schemaRegistryApiKey + ":" + schemaRegistryApiSecret);
        props.put(ProducerConfig.ACKS_CONFIG,                           "all");
        props.put(ProducerConfig.RETRIES_CONFIG,                        3);
        props.put(ProducerConfig.RETRY_BACKOFF_MS_CONFIG,               500);
        props.put(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG,             true);
        props.put(ProducerConfig.MAX_IN_FLIGHT_REQUESTS_PER_CONNECTION, 5);
        props.put(ProducerConfig.DELIVERY_TIMEOUT_MS_CONFIG,            120_000);
        props.put(ProducerConfig.REQUEST_TIMEOUT_MS_CONFIG,             30_000);
        props.put(ProducerConfig.LINGER_MS_CONFIG,                      lingerMs);
        props.put(ProducerConfig.BATCH_SIZE_CONFIG,                     batchSize);
        props.put(ProducerConfig.COMPRESSION_TYPE_CONFIG,               compressionType);
        props.put(ProducerConfig.BUFFER_MEMORY_CONFIG,                  67_108_864L);
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG,   StringSerializer.class);
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);
        props.put(JsonSerializer.ADD_TYPE_INFO_HEADERS, false);
        return props;
    }

    @Bean
    public KafkaTemplate<String, TradeEvent> tradeEventKafkaTemplate() {
        ProducerFactory<String, TradeEvent> factory =
                new DefaultKafkaProducerFactory<>(baseProducerConfigs());
        return new KafkaTemplate<>(factory);
    }

    @Bean
    public KafkaTemplate<String, Object> dlqKafkaTemplate() {
        ProducerFactory<String, Object> factory =
                new DefaultKafkaProducerFactory<>(baseProducerConfigs());
        return new KafkaTemplate<>(factory);
    }
}
