package com.trading.processor.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.time.Duration;

/**
 * Redis-backed deduplication service.
 *
 * Each processed trade ID is stored in Redis with a 24-hour TTL.
 * Duplicate detection is O(1) and survives pod restarts.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class DeduplicationService {

    private static final String   KEY_PREFIX = "dedup:trade:";
    private static final Duration TTL        = Duration.ofHours(24);

    private final StringRedisTemplate redisTemplate;

    public boolean isDuplicate(String tradeId) {
        Boolean exists = redisTemplate.hasKey(KEY_PREFIX + tradeId);
        if (Boolean.TRUE.equals(exists)) {
            log.warn("Duplicate trade detected | tradeId={}", tradeId);
            return true;
        }
        return false;
    }

    public void markProcessed(String tradeId) {
        redisTemplate.opsForValue().set(KEY_PREFIX + tradeId, "1", TTL);
    }
}
