package com.trading.processor.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.Instant;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class TradeMessage {

    public enum AssetClass {
        EQUITY, FIXED_INCOME, FX, COMMODITY, CRYPTO, DERIVATIVE
    }

    public enum Side {
        BUY, SELL
    }

    private String     tradeId;
    private String     instrumentId;
    private AssetClass assetClass;
    private Side       side;
    private BigDecimal quantity;
    private BigDecimal price;
    private BigDecimal notional;
    private String     currency;
    private String     traderId;
    private String     bookId;
    private String     counterpartyId;
    private String     sourceSystem;
    private Instant    tradeDate;
    private Instant    settlementDate;
}
