package com.trading.processor.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UuidGenerator;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "enriched_trades", schema = "trading")
public class EnrichedTrade {

    public enum TradeStatus {
        PROCESSED, REJECTED, DUPLICATE, PENDING
    }

    @Id
    @UuidGenerator
    @Column(columnDefinition = "uuid")
    private UUID id;

    @Column(name = "trade_id", nullable = false, unique = true, length = 100)
    private String tradeId;

    @Column(name = "instrument_id", nullable = false, length = 100)
    private String instrumentId;

    @Column(name = "instrument_name")
    private String instrumentName;

    @Enumerated(EnumType.STRING)
    @Column(name = "asset_class", nullable = false, length = 50)
    private TradeMessage.AssetClass assetClass;

    @Enumerated(EnumType.STRING)
    @Column(name = "side", nullable = false, length = 10)
    private TradeMessage.Side side;

    @Column(name = "quantity", nullable = false, precision = 28, scale = 10)
    private BigDecimal quantity;

    @Column(name = "price", nullable = false, precision = 28, scale = 10)
    private BigDecimal price;

    @Column(name = "notional", nullable = false, precision = 28, scale = 10)
    private BigDecimal notional;

    @Column(name = "currency", nullable = false, length = 3)
    private String currency;

    @Column(name = "usd_notional", precision = 28, scale = 10)
    private BigDecimal usdNotional;

    @Column(name = "fx_rate", precision = 20, scale = 10)
    private BigDecimal fxRate;

    @Column(name = "trader_id", nullable = false, length = 100)
    private String traderId;

    @Column(name = "trader_name")
    private String traderName;

    @Column(name = "book_id", nullable = false, length = 100)
    private String bookId;

    @Column(name = "counterparty_id", nullable = false, length = 100)
    private String counterpartyId;

    @Column(name = "counterparty_name")
    private String counterpartyName;

    @Column(name = "trade_date", nullable = false)
    private Instant tradeDate;

    @Column(name = "settlement_date", nullable = false)
    private Instant settlementDate;

    @Column(name = "source_system", nullable = false, length = 100)
    private String sourceSystem;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 30)
    private TradeStatus status;

    @Column(name = "risk_score")
    private Double riskScore;

    @Column(name = "processing_latency_ms")
    private Integer processingLatencyMs;

    @CreationTimestamp
    @Column(name = "processed_at", nullable = false, updatable = false)
    private Instant processedAt;

    @Column(name = "kafka_offset")
    private Long kafkaOffset;

    @Column(name = "kafka_partition")
    private Integer kafkaPartition;

    @Column(name = "kafka_topic")
    private String kafkaTopic;
}
