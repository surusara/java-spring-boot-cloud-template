package com.trading.processor.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class TradeEvent {

    private String                  tradeId;
    private String                  enrichedTradeId;
    private EnrichedTrade.TradeStatus status;
    private TradeMessage.AssetClass assetClass;
    private BigDecimal              notional;
    private String                  currency;
    private BigDecimal              usdNotional;
    private Double                  riskScore;
    private String                  sourceSystem;
    private Integer                 processingLatencyMs;
}
