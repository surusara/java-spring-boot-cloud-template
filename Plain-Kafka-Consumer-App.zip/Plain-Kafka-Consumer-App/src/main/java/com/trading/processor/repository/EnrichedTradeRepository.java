package com.trading.processor.repository;

import com.trading.processor.model.EnrichedTrade;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.UUID;

@Repository
public interface EnrichedTradeRepository extends JpaRepository<EnrichedTrade, UUID> {

    boolean existsByTradeId(String tradeId);
}
