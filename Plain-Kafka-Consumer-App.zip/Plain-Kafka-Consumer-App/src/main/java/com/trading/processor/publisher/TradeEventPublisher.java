package com.trading.processor.publisher;

import com.trading.processor.model.TradeEvent;
import com.trading.processor.model.TradeMessage;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

@Slf4j
@Component
@RequiredArgsConstructor
public class TradeEventPublisher {

    private final KafkaTemplate<String, TradeEvent> tradeEventKafkaTemplate;
    private final KafkaTemplate<String, Object>     dlqKafkaTemplate;

    @Value("${kafka.topics.output:trades.processed}")
    private String outputTopic;

    @Value("${kafka.topics.dlq:trades.dlq}")
    private String dlqTopic;

    /**
     * Publish enriched trade event to the output topic.
     * Key = tradeId ensures same-trade events land on the same partition (ordering).
     */
    public void publishProcessed(TradeEvent event) {
        CompletableFuture<SendResult<String, TradeEvent>> future =
            tradeEventKafkaTemplate.send(outputTopic, event.getTradeId(), event);

        future.whenComplete((result, ex) -> {
            if (ex != null) {
                log.error("Failed to publish TradeEvent for tradeId={}: {}",
                          event.getTradeId(), ex.getMessage(), ex);
            } else {
                log.debug("Published TradeEvent | tradeId={} | partition={} | offset={}",
                          event.getTradeId(),
                          result.getRecordMetadata().partition(),
                          result.getRecordMetadata().offset());
            }
        });
    }

    /**
     * Route failed / invalid trade to the DLQ.
     */
    public void publishToDlq(TradeMessage trade, String reason) {
        Map<String, Object> dlqPayload = Map.of(
            "trade_id",       trade.getTradeId(),
            "source_system",  trade.getSourceSystem(),
            "failure_reason", reason,
            "failed_at",      Instant.now().toString()
        );

        CompletableFuture<SendResult<String, Object>> future =
            dlqKafkaTemplate.send(dlqTopic, trade.getTradeId(), dlqPayload);

        future.whenComplete((result, ex) -> {
            if (ex != null) {
                log.error("CRITICAL: DLQ publish failed for tradeId={}: {}",
                          trade.getTradeId(), ex.getMessage(), ex);
            } else {
                log.warn("Trade sent to DLQ | tradeId={} | reason={}",
                         trade.getTradeId(), reason);
            }
        });
    }
}
