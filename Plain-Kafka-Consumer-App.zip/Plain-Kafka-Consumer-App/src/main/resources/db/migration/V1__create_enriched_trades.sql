-- ===========================================================================
--  V1__create_enriched_trades.sql
--  Flyway migration — initial schema for trade-kafka-processor
-- ===========================================================================
CREATE SCHEMA IF NOT EXISTS trading;

CREATE TABLE IF NOT EXISTS trading.enriched_trades (
    id                    UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
    trade_id              VARCHAR(100)  NOT NULL UNIQUE,
    instrument_id         VARCHAR(100)  NOT NULL,
    instrument_name       VARCHAR(255),
    asset_class           VARCHAR(50)   NOT NULL,
    side                  VARCHAR(10)   NOT NULL,
    quantity              NUMERIC(28,10) NOT NULL,
    price                 NUMERIC(28,10) NOT NULL,
    notional              NUMERIC(28,10) NOT NULL,
    currency              CHAR(3)       NOT NULL,
    usd_notional          NUMERIC(28,10),
    fx_rate               NUMERIC(20,10),
    trader_id             VARCHAR(100)  NOT NULL,
    trader_name           VARCHAR(255),
    book_id               VARCHAR(100)  NOT NULL,
    counterparty_id       VARCHAR(100)  NOT NULL,
    counterparty_name     VARCHAR(255),
    trade_date            TIMESTAMPTZ   NOT NULL,
    settlement_date       TIMESTAMPTZ   NOT NULL,
    source_system         VARCHAR(100)  NOT NULL,
    status                VARCHAR(30)   NOT NULL DEFAULT 'PROCESSED',
    risk_score            DOUBLE PRECISION,
    processing_latency_ms INTEGER,
    processed_at          TIMESTAMPTZ   NOT NULL DEFAULT NOW(),
    kafka_offset          BIGINT,
    kafka_partition       INTEGER,
    kafka_topic           VARCHAR(255)
);

-- Performance indexes
CREATE INDEX idx_et_trade_date   ON trading.enriched_trades (trade_date DESC);
CREATE INDEX idx_et_asset_class  ON trading.enriched_trades (asset_class);
CREATE INDEX idx_et_book_id      ON trading.enriched_trades (book_id);
CREATE INDEX idx_et_trader_id    ON trading.enriched_trades (trader_id);
CREATE INDEX idx_et_status       ON trading.enriched_trades (status);
CREATE INDEX idx_et_processed_at ON trading.enriched_trades (processed_at DESC);
