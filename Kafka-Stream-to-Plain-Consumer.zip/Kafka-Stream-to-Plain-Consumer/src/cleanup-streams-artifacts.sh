#!/bin/bash
# ===========================================================================
#  STEP 5 OF MIGRATION — Cleanup Kafka Streams artifacts
#
#  Kafka Streams creates several persistent artifacts that must be cleaned
#  up after migration. Run this ONCE after deploying the new Spring Kafka code.
# ===========================================================================

set -e

BOOTSTRAP="$KAFKA_BOOTSTRAP_SERVERS"
API_KEY="$KAFKA_API_KEY"
API_SECRET="$KAFKA_API_SECRET"

STREAMS_APP_ID="trade-processor-streams"  # your old APPLICATION_ID_CONFIG

echo "=== Step 5a: Delete Streams internal changelog topics ==="
# Streams auto-creates changelog topics for every state store.
# Even if you had no explicit state stores, Streams creates internal
# repartition and changelog topics with the pattern:
#   <application-id>-<processor-name>-changelog
#   <application-id>-<processor-name>-repartition

INTERNAL_TOPICS=$(kafka-topics \
  --bootstrap-server "$BOOTSTRAP" \
  --command-config <(echo "security.protocol=SASL_SSL
sasl.mechanism=PLAIN
sasl.jaas.config=org.apache.kafka.common.security.plain.PlainLoginModule required username=\"$API_KEY\" password=\"$API_SECRET\";") \
  --list | grep "^${STREAMS_APP_ID}-")

if [ -n "$INTERNAL_TOPICS" ]; then
    echo "Deleting internal topics:"
    echo "$INTERNAL_TOPICS"
    for topic in $INTERNAL_TOPICS; do
        kafka-topics \
          --bootstrap-server "$BOOTSTRAP" \
          --command-config <(echo "security.protocol=SASL_SSL
sasl.mechanism=PLAIN
sasl.jaas.config=org.apache.kafka.common.security.plain.PlainLoginModule required username=\"$API_KEY\" password=\"$API_SECRET\";") \
          --delete --topic "$topic"
        echo "Deleted: $topic"
    done
else
    echo "No internal Streams topics found (already clean)."
fi

echo ""
echo "=== Step 5b: Delete local RocksDB state store directories ==="
# On each pod, Streams wrote state to a local directory (state.dir).
# Since pods are ephemeral in Kubernetes this is cleaned automatically
# when pods restart. But if you used a PersistentVolume for state.dir,
# delete those PVCs now.

echo "Checking for Streams state store PVCs..."
kubectl get pvc -n trade-processing | grep "streams-state" || echo "No state store PVCs found."

echo ""
echo "=== Step 5c: Delete old Streams consumer group offsets ==="
# Streams registered its own internal consumer group: <application-id>
# This is different from your new group.id = trade-processor-group.
# The offsets for the old Streams group still exist in Kafka.
# You can either:
#   Option A: Delete the old group (recommended — clean slate)
#   Option B: Leave it (harmless but clutters consumer group list)

echo "Resetting Streams consumer group: ${STREAMS_APP_ID}"
kafka-consumer-groups \
  --bootstrap-server "$BOOTSTRAP" \
  --command-config <(echo "security.protocol=SASL_SSL
sasl.mechanism=PLAIN
sasl.jaas.config=org.apache.kafka.common.security.plain.PlainLoginModule required username=\"$API_KEY\" password=\"$API_SECRET\";") \
  --group "${STREAMS_APP_ID}" \
  --delete 2>/dev/null || echo "Group ${STREAMS_APP_ID} already deleted or not found."

echo ""
echo "=== Step 5d: Verify new consumer group is being monitored by KEDA ==="
kafka-consumer-groups \
  --bootstrap-server "$BOOTSTRAP" \
  --command-config <(echo "security.protocol=SASL_SSL
sasl.mechanism=PLAIN
sasl.jaas.config=org.apache.kafka.common.security.plain.PlainLoginModule required username=\"$API_KEY\" password=\"$API_SECRET\";") \
  --group "trade-processor-group" \
  --describe

echo ""
echo "=== Migration cleanup complete ==="
echo "KEDA ScaledObject is monitoring: trade-processor-group"
echo "Streams group deleted:           ${STREAMS_APP_ID}"
