package com.trading.processor.stream;

import com.trading.processor.model.TradeMessage;
import com.trading.processor.service.TradeProcessingService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.kstream.Consumed;
import org.apache.kafka.streams.kstream.KStream;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafkaStreams;
import org.springframework.kafka.config.KafkaStreamsConfiguration;
import org.springframework.kafka.support.serializer.JsonSerde;

import java.util.HashMap;
import java.util.Map;

import static org.apache.kafka.streams.StreamsConfig.*;

// ============================================================
//  BEFORE: Kafka Streams topology
//
//  Problems with this approach for your use case:
//
//  1. num.stream.threads does NOT give more parallelism than
//     partition count. Same rule applies — wasted threads.
//
//  2. Every KEDA scale event triggers a STATE STORE rebalance.
//     RocksDB data must migrate between pods. This causes
//     10–60s pause across the ENTIRE consumer group while
//     state is rebuilt — far worse than KafkaConsumer rebalance.
//
//  3. Streams wraps your processor inside its own lifecycle.
//     DB writes, HTTP calls, @Transactional — all awkward
//     because KStream.foreach() runs inside Streams' managed
//     thread, not Spring's managed thread pool.
//
//  4. Error handling is weaker. StreamsUncaughtExceptionHandler
//     only supports REPLACE_THREAD or SHUTDOWN_CLIENT — no
//     per-record retry with exponential backoff to DLQ.
//
//  5. Changelog topics are created automatically for any
//     stateful op. Even if you don't use state, the overhead
//     of the Streams protocol (StreamsPartitionAssignor,
//     rebalance protocol v2) remains.
// ============================================================

@Slf4j
@Configuration
@EnableKafkaStreams
@RequiredArgsConstructor
public class TradeStreamsTopology {

    private final TradeProcessingService processingService;

    @Value("${kafka.topics.input}")  private String inputTopic;
    @Value("${kafka.topics.output}") private String outputTopic;
    @Value("${kafka.topics.dlq}")    private String dlqTopic;

    @Bean(name = KafkaStreamsDefaultConfiguration.DEFAULT_STREAMS_CONFIG_BEAN_NAME)
    public KafkaStreamsConfiguration streamsConfig() {
        Map<String, Object> props = new HashMap<>();
        props.put(APPLICATION_ID_CONFIG,        "trade-processor-streams");
        props.put(BOOTSTRAP_SERVERS_CONFIG,      "${KAFKA_BOOTSTRAP_SERVERS}");
        props.put(DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.String().getClass());
        props.put(DEFAULT_VALUE_SERDE_CLASS_CONFIG, Serdes.String().getClass());

        // This does NOT give you more parallelism than partition count.
        // Beyond partition count these threads sit idle — same problem
        // as setConcurrency() in Spring Kafka.
        props.put(NUM_STREAM_THREADS_CONFIG, 10);

        // PROBLEM: Streams creates an internal consumer group
        // "trade-processor-streams-{host}-{uuid}" per instance.
        // KEDA cannot monitor lag on this internal group reliably.
        // You must use a separate monitoring consumer group.

        return new KafkaStreamsConfiguration(props);
    }

    @Bean
    public KStream<String, TradeMessage> tradeStream(StreamsBuilder builder) {
        KStream<String, TradeMessage> stream = builder.stream(
            inputTopic,
            Consumed.with(Serdes.String(), new JsonSerde<>(TradeMessage.class))
        );

        stream.foreach((key, trade) -> {
            // PROBLEM: No access to Acknowledgment — Streams manages offsets
            // internally. If processing fails after partial DB write, you
            // cannot selectively commit or retry. Your only options are:
            //   REPLACE_THREAD → skips the record (data loss risk)
            //   SHUTDOWN_CLIENT → kills the entire stream instance

            // PROBLEM: @Transactional does not work here.
            // Streams' thread is not managed by Spring's transaction
            // interceptor. You must manually manage transactions.
            try {
                processingService.process(trade, 0, 0, inputTopic, System.currentTimeMillis());
            } catch (Exception e) {
                log.error("Failed to process trade {}: {}", trade.getTradeId(), e.getMessage());
                // Can't do per-record DLQ routing here without building
                // a separate producer — Streams' built-in error handling
                // does not support record-level routing.
            }
        });

        return stream;
    }
}
