package com.trading.processor;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.CooperativeStickyAssignor;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.test.context.ActiveProfiles;

import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Run this test after migration to verify:
 *
 *  ✅ No kafka-streams classes on classpath
 *  ✅ ConsumerFactory has correct config
 *  ✅ CooperativeStickyAssignor is set (not StreamsPartitionAssignor)
 *  ✅ Auto commit is disabled
 *  ✅ Static group membership (group.instance.id) is set
 *  ✅ Concurrency is 10
 *  ✅ No RocksDB dependency
 *
 * MIGRATION CHECKLIST (verify each manually):
 *
 *  [ ] 1. Deleted TradeStreamsTopology.java
 *  [ ] 2. Deleted @EnableKafkaStreams from any @Configuration class
 *  [ ] 3. Removed kafka-streams dependency from pom.xml
 *  [ ] 4. Added KafkaConsumerConfig.java (this PR)
 *  [ ] 5. Added TradeMessageConsumer.java (this PR)
 *  [ ] 6. Removed spring.kafka.streams block from application.yml
 *  [ ] 7. Added kafka.consumer block to application.yml
 *  [ ] 8. Ran cleanup-streams-artifacts.sh against staging cluster
 *  [ ] 9. Verified KEDA ScaledObject monitors group: trade-processor-group
 *  [ ] 10. TradeProcessingService — confirmed ZERO changes were made
 *  [ ] 11. ValidationService — confirmed ZERO changes were made
 *  [ ] 12. EnrichedTradeRepository — confirmed ZERO changes were made
 *  [ ] 13. TradeEventPublisher — confirmed ZERO changes were made
 *  [ ] 14. All domain model classes — confirmed ZERO changes were made
 */
@SpringBootTest
@ActiveProfiles("test")
class MigrationVerificationTest {

    @Autowired
    private ConsumerFactory<String, ?> consumerFactory;

    @Autowired
    private ConcurrentKafkaListenerContainerFactory<?, ?> kafkaListenerContainerFactory;

    @Test
    void streamsClassesMustNotBeOnClasspath() {
        // If kafka-streams is still a dependency, this will find the class.
        // It must NOT be present after migration.
        boolean streamsOnClasspath;
        try {
            Class.forName("org.apache.kafka.streams.KafkaStreams");
            streamsOnClasspath = true;
        } catch (ClassNotFoundException e) {
            streamsOnClasspath = false;
        }
        assertThat(streamsOnClasspath)
            .as("kafka-streams must be removed from pom.xml")
            .isFalse();
    }

    @Test
    void rocksDbMustNotBeOnClasspath() {
        boolean rocksDbOnClasspath;
        try {
            Class.forName("org.rocksdb.RocksDB");
            rocksDbOnClasspath = true;
        } catch (ClassNotFoundException e) {
            rocksDbOnClasspath = false;
        }
        assertThat(rocksDbOnClasspath)
            .as("RocksDB (state store) must be removed after migration")
            .isFalse();
    }

    @Test
    void consumerConfigMustUseCooperativeStickyAssignor() {
        Map<String, Object> configs = consumerFactory.getConfigurationProperties();
        assertThat(configs.get(ConsumerConfig.PARTITION_ASSIGNMENT_STRATEGY_CONFIG))
            .as("Must use CooperativeStickyAssignor, not StreamsPartitionAssignor")
            .isEqualTo(CooperativeStickyAssignor.class.getName());
    }

    @Test
    void autoCommitMustBeDisabled() {
        Map<String, Object> configs = consumerFactory.getConfigurationProperties();
        assertThat(configs.get(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG))
            .as("Manual ack mode requires auto-commit disabled")
            .isEqualTo(false);
    }

    @Test
    void staticGroupMembershipMustBeSet() {
        Map<String, Object> configs = consumerFactory.getConfigurationProperties();
        Object instanceId = configs.get(ConsumerConfig.GROUP_INSTANCE_ID_CONFIG);
        assertThat(instanceId)
            .as("group.instance.id must be set for static membership (zero-rebalance rolling restarts)")
            .isNotNull()
            .isNotEqualTo("");
    }

    @Test
    void concurrencyMustBeTen() {
        int concurrency = kafkaListenerContainerFactory.getConcurrency();
        assertThat(concurrency)
            .as("concurrency=10 covers all 20 partitions at minReplicas=2")
            .isEqualTo(10);
    }
}
