package com.trading.processor.consumer;

import com.trading.processor.model.ProcessingResult;
import com.trading.processor.model.TradeMessage;
import com.trading.processor.service.TradeProcessingService;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.stereotype.Component;

import java.time.Instant;

/**
 * STEP 2 OF MIGRATION
 *
 * Delete:  TradeStreamsTopology.java  (the @Bean KStream<> method)
 * Add:     This class
 *
 * The @KafkaListener replaces KStream.foreach() exactly.
 * Your TradeProcessingService.process() call is IDENTICAL —
 * copy it from foreach() body directly into consume().
 *
 * What you gain over Streams.foreach():
 *
 * 1. Acknowledgment — explicit per-record offset commit.
 *    You commit AFTER DLQ routing, never before. In Streams,
 *    commit.interval.ms could commit before your DB write completed.
 *
 * 2. Full Spring context — @Transactional, @Retryable, MDC logging,
 *    dependency injection all work correctly inside this method.
 *    In Streams.foreach() these required workarounds.
 *
 * 3. Per-record error handling — DefaultErrorHandler gives you
 *    exponential backoff + DLQ per record. Streams gave you
 *    REPLACE_THREAD (skip silently) or SHUTDOWN_CLIENT (kill pod).
 *
 * 4. Kafka headers — KafkaHeaders.RECEIVED_PARTITION, OFFSET, TIMESTAMP
 *    are directly injectable. In Streams you needed ProcessorContext.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class TradeMessageConsumer {

    private final TradeProcessingService processingService;
    private final MeterRegistry          meterRegistry;

    @Value("${POD_NAME:local}")
    private String podName;

    /**
     * Direct replacement for:
     *
     *   stream.foreach((key, trade) -> {
     *       processingService.process(trade, ...);
     *   });
     *
     * The method body is identical. Only the surrounding infrastructure changes.
     */
    @KafkaListener(
        topics           = "${kafka.topics.input:trades.raw}",
        groupId          = "${kafka.consumer.group-id:trade-processor-group}",
        containerFactory = "kafkaListenerContainerFactory"
    )
    public void consume(
            ConsumerRecord<String, TradeMessage> record,
            Acknowledgment ack,
            @Header(KafkaHeaders.RECEIVED_PARTITION) int    partition,
            @Header(KafkaHeaders.OFFSET)             long   offset,
            @Header(KafkaHeaders.RECEIVED_TOPIC)     String topic,
            @Header(KafkaHeaders.RECEIVED_TIMESTAMP) long   timestamp) {

        TradeMessage trade  = record.value();
        long         startMs = Instant.now().toEpochMilli();

        // MDC context — was not available inside Streams.foreach()
        MDC.put("tradeId",   trade.getTradeId());
        MDC.put("podName",   podName);
        MDC.put("partition", String.valueOf(partition));
        MDC.put("offset",    String.valueOf(offset));

        Timer.Sample timer = Timer.start(meterRegistry);
        try {
            log.info("Consuming | partition={} | offset={} | tradeId={} | source={}",
                     partition, offset, trade.getTradeId(), trade.getSourceSystem());

            // THIS LINE IS IDENTICAL TO YOUR STREAMS foreach() BODY.
            // Copy it verbatim. Zero changes to TradeProcessingService.
            ProcessingResult result = processingService.process(
                    trade, offset, partition, topic, startMs);

            if (result.isSuccess()) {
                log.info("Processed | tradeId={} | latencyMs={}",
                         trade.getTradeId(),
                         result.getEnrichedTrade() != null
                             ? result.getEnrichedTrade().getProcessingLatencyMs() : "N/A");
                meterRegistry.counter("trade.consumer.success",
                        "asset_class", trade.getAssetClass().name()).increment();
            } else {
                log.warn("Failed | tradeId={} | error={}", trade.getTradeId(), result.getError());
                meterRegistry.counter("trade.consumer.failure",
                        "reason", result.getError()).increment();
            }

            // Explicit offset commit — happens AFTER DLQ routing inside processingService.
            // In Streams, commit was timer-based and could happen before DB write finished.
            ack.acknowledge();

        } catch (Exception ex) {
            log.error("Unhandled exception | tradeId={} | error={}",
                      trade.getTradeId(), ex.getMessage(), ex);
            meterRegistry.counter("trade.consumer.error").increment();
            // Re-throw → DefaultErrorHandler applies exponential backoff → DLQ after 3 attempts.
            // Streams could only REPLACE_THREAD or SHUTDOWN_CLIENT here.
            throw ex;
        } finally {
            timer.stop(meterRegistry.timer("trade.consumer.duration",
                    "partition", String.valueOf(partition)));
            MDC.clear();
        }
    }
}
