package com.trading.processor.config;

import com.trading.processor.model.TradeMessage;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.CooperativeStickyAssignor;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.listener.ContainerProperties;
import org.springframework.kafka.listener.DefaultErrorHandler;
import org.springframework.kafka.support.serializer.ErrorHandlingDeserializer;
import org.springframework.kafka.support.serializer.JsonDeserializer;
import org.springframework.util.backoff.ExponentialBackOff;

import java.util.HashMap;
import java.util.Map;

/**
 * STEP 1 OF MIGRATION
 *
 * Replace this class with your existing KafkaStreamsConfiguration bean.
 * Delete:  @EnableKafkaStreams
 *          KafkaStreamsConfiguration bean
 *          KafkaStreamsDefaultConfiguration.DEFAULT_STREAMS_CONFIG_BEAN_NAME
 * Add:     @EnableKafka (already present if you have any @KafkaListener)
 *          This KafkaConsumerConfig class
 *
 * Your TradeProcessingService, ValidationService, EnrichedTradeRepository,
 * TradeEventPublisher — NONE of those change. Zero edits required there.
 *
 * The concurrency formula for your use case:
 *   concurrency = partitions / minReplicas = 20 / 2 = 10
 *
 *   At 2 pods:  2 × 10 = 20 threads = 20 partitions → 0 idle
 *   At 10 pods: 10 × 10 = 100 threads > 20 partitions → 80 idle (harmless, ~160MB RAM)
 *   At 20 pods: 20 × 10 = 200 threads > 20 partitions → 180 idle (harmless, ~360MB RAM)
 *
 *   Trade-off: slight RAM overhead at peak vs guaranteed full throughput at low scale.
 *   For 5M trades/day this is the correct choice.
 */
@Slf4j
@Configuration
@EnableKafka  // replaces @EnableKafkaStreams
public class KafkaConsumerConfig {

    @Value("${kafka.bootstrap-servers}")           private String bootstrapServers;
    @Value("${kafka.security.protocol}")           private String securityProtocol;
    @Value("${kafka.sasl.mechanism}")              private String saslMechanism;
    @Value("${kafka.sasl.jaas-config}")            private String saslJaasConfig;
    @Value("${kafka.schema-registry.url}")         private String schemaRegistryUrl;
    @Value("${kafka.schema-registry.api-key}")     private String schemaRegistryApiKey;
    @Value("${kafka.schema-registry.api-secret}")  private String schemaRegistryApiSecret;
    @Value("${kafka.consumer.group-id}")           private String groupId;
    @Value("${kafka.consumer.concurrency:10}")     private int    concurrency;

    // Injected via Kubernetes Downward API (fieldRef: metadata.name)
    // Enables static group membership → zero rebalance on rolling restarts
    @Value("${POD_NAME:trade-processor-default}")
    private String podName;

    @Bean
    public Map<String, Object> consumerConfigs() {
        Map<String, Object> props = new HashMap<>();

        // Confluent Cloud SASL_SSL — same values you had in StreamsConfig
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        props.put("security.protocol", securityProtocol);
        props.put("sasl.mechanism",    saslMechanism);
        props.put("sasl.jaas.config",  saslJaasConfig);

        props.put("schema.registry.url",           schemaRegistryUrl);
        props.put("basic.auth.credentials.source", "USER_INFO");
        props.put("basic.auth.user.info",
                  schemaRegistryApiKey + ":" + schemaRegistryApiSecret);

        // Consumer group — use the SAME group ID your Streams app used.
        // This ensures KEDA can monitor the exact same group for lag.
        // In Streams, APPLICATION_ID_CONFIG became the group.id internally.
        // Now you control it explicitly.
        props.put(ConsumerConfig.GROUP_ID_CONFIG,          groupId);
        props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");

        // Static group membership — replaces Streams' internal host-based ID.
        // Pod restarts within session.timeout.ms cause ZERO rebalance.
        props.put(ConsumerConfig.GROUP_INSTANCE_ID_CONFIG, podName);

        // CooperativeStickyAssignor — replaces Streams' StreamsPartitionAssignor.
        // Incremental rebalance: only moved partitions pause, others keep consuming.
        // This is a direct improvement over Streams' all-or-nothing rebalance.
        props.put(ConsumerConfig.PARTITION_ASSIGNMENT_STRATEGY_CONFIG,
                  CooperativeStickyAssignor.class.getName());

        // Manual commit — you now control exactly when offsets are committed.
        // In Streams, commit.interval.ms controlled this asynchronously.
        // Now: commit happens after each record is successfully processed + DLQ routed.
        props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false);

        // Poll tuning — identical logic to what Streams used internally
        // max-poll-records × avg-processing-time must be << max-poll-interval
        props.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG,        10);
        props.put(ConsumerConfig.MAX_POLL_INTERVAL_MS_CONFIG,    300_000);
        props.put(ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG,      45_000);
        props.put(ConsumerConfig.HEARTBEAT_INTERVAL_MS_CONFIG,   10_000);
        props.put(ConsumerConfig.FETCH_MIN_BYTES_CONFIG,         1_024);
        props.put(ConsumerConfig.FETCH_MAX_WAIT_MS_CONFIG,       500);

        // Deserializers with error handling wrapper
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,
                  StringDeserializer.class);
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,
                  ErrorHandlingDeserializer.class);
        props.put(ErrorHandlingDeserializer.VALUE_DESERIALIZER_CLASS,
                  JsonDeserializer.class.getName());
        props.put(JsonDeserializer.VALUE_DEFAULT_TYPE,
                  TradeMessage.class.getName());
        props.put(JsonDeserializer.TRUSTED_PACKAGES,
                  "com.trading.processor.model");
        props.put(JsonDeserializer.USE_TYPE_INFO_HEADERS, false);

        log.info("Consumer config ready | group={} | instanceId={} | concurrency={}",
                 groupId, podName, concurrency);
        return props;
    }

    @Bean
    public ConsumerFactory<String, TradeMessage> consumerFactory() {
        return new DefaultKafkaConsumerFactory<>(consumerConfigs());
    }

    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, TradeMessage>
    kafkaListenerContainerFactory(ConsumerFactory<String, TradeMessage> cf) {

        var factory = new ConcurrentKafkaListenerContainerFactory<String, TradeMessage>();
        factory.setConsumerFactory(cf);

        // concurrency = 10 (partitions=20 / minReplicas=2)
        // Each listener thread owns a KafkaConsumer instance that polls
        // its assigned partitions. This is exactly what Streams' StreamThread did,
        // but now with full Spring @Transactional and DLQ support.
        factory.setConcurrency(concurrency);

        // RECORD ack mode: commit after every record.
        // Replaces Streams' commit.interval.ms (timer-based, less precise).
        factory.getContainerProperties().setAckMode(
            ContainerProperties.AckMode.RECORD);

        // 60s graceful shutdown: in-flight records finish before pod stops.
        // Replaces Streams' close(Duration) call.
        factory.getContainerProperties().setShutdownTimeout(60_000L);

        // Per-record exponential backoff → DLQ after 3 attempts.
        // THIS IS THE KEY IMPROVEMENT over Streams.
        // Streams had only REPLACE_THREAD (skip) or SHUTDOWN_CLIENT (kill pod).
        // Now you get: attempt 1 → wait 1s → attempt 2 → wait 2s → attempt 3 → DLQ.
        ExponentialBackOff backOff = new ExponentialBackOff(1_000L, 2.0);
        backOff.setMaxAttempts(3);
        backOff.setMaxInterval(10_000L);

        DefaultErrorHandler errorHandler = new DefaultErrorHandler(backOff);
        errorHandler.addNotRetryableExceptions(
            IllegalArgumentException.class,
            com.fasterxml.jackson.core.JsonProcessingException.class,
            jakarta.validation.ValidationException.class
        );
        errorHandler.setCommitRecovered(true);
        factory.setCommonErrorHandler(errorHandler);

        return factory;
    }
}
